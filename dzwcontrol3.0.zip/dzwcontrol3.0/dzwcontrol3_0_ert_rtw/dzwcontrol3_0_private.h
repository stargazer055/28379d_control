/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: dzwcontrol3_0_private.h
 *
 * Code generated for Simulink model 'dzwcontrol3_0'.
 *
 * Model version                  : 1.41
 * Simulink Coder version         : 9.4 (R2020b) 29-Jul-2020
 * C/C++ source code generated on : Fri Feb  7 17:21:12 2025
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Texas Instruments->C2000
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_dzwcontrol3_0_private_h_
#define RTW_HEADER_dzwcontrol3_0_private_h_
#include "rtwtypes.h"
#include "dzwcontrol3_0.h"
#ifndef UCHAR_MAX
#include <limits.h>
#endif

#if ( UCHAR_MAX != (0xFFFFU) ) || ( SCHAR_MAX != (0x7FFF) )
#error Code was generated for compiler with different sized uchar/char. \
Consider adjusting Test hardware word size settings on the \
Hardware Implementation pane to match your compiler word sizes as \
defined in limits.h of the compiler. Alternatively, you can \
select the Test hardware is the same as production hardware option and \
select the Enable portable word sizes option on the Code Generation > \
Verification pane for ERT based targets, which will disable the \
preprocessor word size checks.
#endif

#if ( USHRT_MAX != (0xFFFFU) ) || ( SHRT_MAX != (0x7FFF) )
#error Code was generated for compiler with different sized ushort/short. \
Consider adjusting Test hardware word size settings on the \
Hardware Implementation pane to match your compiler word sizes as \
defined in limits.h of the compiler. Alternatively, you can \
select the Test hardware is the same as production hardware option and \
select the Enable portable word sizes option on the Code Generation > \
Verification pane for ERT based targets, which will disable the \
preprocessor word size checks.
#endif

#if ( UINT_MAX != (0xFFFFU) ) || ( INT_MAX != (0x7FFF) )
#error Code was generated for compiler with different sized uint/int. \
Consider adjusting Test hardware word size settings on the \
Hardware Implementation pane to match your compiler word sizes as \
defined in limits.h of the compiler. Alternatively, you can \
select the Test hardware is the same as production hardware option and \
select the Enable portable word sizes option on the Code Generation > \
Verification pane for ERT based targets, which will disable the \
preprocessor word size checks.
#endif

#if ( ULONG_MAX != (0xFFFFFFFFUL) ) || ( LONG_MAX != (0x7FFFFFFFL) )
#error Code was generated for compiler with different sized ulong/long. \
Consider adjusting Test hardware word size settings on the \
Hardware Implementation pane to match your compiler word sizes as \
defined in limits.h of the compiler. Alternatively, you can \
select the Test hardware is the same as production hardware option and \
select the Enable portable word sizes option on the Code Generation > \
Verification pane for ERT based targets, which will disable the \
preprocessor word size checks.
#endif

/* Skipping ulong_long/long_long check: insufficient preprocessor integer range. */
void InitAdcD (void);
void config_ADCD_SOC4 (void);
void InitAdcC (void);
void config_ADCC_SOC1 (void);
void InitAdcA (void);
void config_ADCA_SOC2 (void);
void InitAdcB (void);
void config_ADCB_SOC3 (void);
void config_ADCA_SOC0 (void);
void config_ADCC_SOC4 (void);
void config_ADCA_SOC4 (void);
void config_ADCB_SOC4 (void);
extern uint16_T MW_adcDInitFlag;
extern uint16_T MW_adcCInitFlag;
extern uint16_T MW_adcAInitFlag;
extern uint16_T MW_adcBInitFlag;
extern real32_T rt_modf_snf(real32_T u0, real32_T u1);
void isr_int1pie1_task_fcn(void);
extern void configureGPIOExtInterrupt(void);
void idle_num1_task_fcn(void);
extern void dzwcontr_Subsystempi2delay_Init(real32_T *rty_dq, real32_T *rty_dq_h,
  P_Subsystempi2delay_dzwcontro_T *localP);
extern void dzwcontrol3_0_Subsystempi2delay(uint16_T rtu_Enable, real32_T
  rtu_alpha_beta, real32_T rtu_alpha_beta_p, real32_T rtu_wt, real32_T *rty_dq,
  real32_T *rty_dq_h);
extern void dzwcontrol3_0_Subsystem1_Init(real32_T *rty_dq, real32_T *rty_dq_m,
  P_Subsystem1_dzwcontrol3_0_T *localP);
extern void dzwcontrol3_0_Subsystem1(uint16_T rtu_Enable, real32_T
  rtu_alpha_beta, real32_T rtu_alpha_beta_o, real32_T rtu_wt, real32_T *rty_dq,
  real32_T *rty_dq_m);
extern void dzwcontr_EmbeddedMATLABFunction(int32_T *rty_y);
extern void dzwcon_Subsystempi2delay_e_Init(real32_T *rty_alpha_beta, real32_T
  *rty_alpha_beta_a, P_Subsystempi2delay_dzwcont_o_T *localP);
extern void dzwcontrol3_Subsystempi2delay_l(uint16_T rtu_Enable, real32_T rtu_dq,
  real32_T rtu_dq_g, real32_T rtu_wt, real32_T *rty_alpha_beta, real32_T
  *rty_alpha_beta_a);
extern void dzwcontrol3_0_Subsystem1_c_Init(real32_T *rty_alpha_beta, real32_T
  *rty_alpha_beta_j, P_Subsystem1_dzwcontrol3_0_e_T *localP);
extern void dzwcontrol3_0_Subsystem1_l(uint16_T rtu_Enable, real32_T rtu_dq,
  real32_T rtu_dq_f, real32_T rtu_wt, real32_T *rty_alpha_beta, real32_T
  *rty_alpha_beta_j);
void isr_int1pie1_task_fcn(void);

#endif                                 /* RTW_HEADER_dzwcontrol3_0_private_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
