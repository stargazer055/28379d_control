/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: dzwcontrol3_0_types.h
 *
 * Code generated for Simulink model 'dzwcontrol3_0'.
 *
 * Model version                  : 1.41
 * Simulink Coder version         : 9.4 (R2020b) 29-Jul-2020
 * C/C++ source code generated on : Fri Feb  7 17:21:12 2025
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Texas Instruments->C2000
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_dzwcontrol3_0_types_h_
#define RTW_HEADER_dzwcontrol3_0_types_h_
#include "rtwtypes.h"

/* Model Code Variants */

/* Parameters for system: '<S53>/Subsystem - pi//2 delay' */
typedef struct P_Subsystempi2delay_dzwcontro_T_ P_Subsystempi2delay_dzwcontro_T;

/* Parameters for system: '<S53>/Subsystem1' */
typedef struct P_Subsystem1_dzwcontrol3_0_T_ P_Subsystem1_dzwcontrol3_0_T;

/* Parameters for system: '<S55>/Subsystem - pi//2 delay' */
typedef struct P_Subsystempi2delay_dzwcont_o_T_ P_Subsystempi2delay_dzwcont_o_T;

/* Parameters for system: '<S55>/Subsystem1' */
typedef struct P_Subsystem1_dzwcontrol3_0_e_T_ P_Subsystem1_dzwcontrol3_0_e_T;

/* Parameters (default storage) */
typedef struct P_dzwcontrol3_0_T_ P_dzwcontrol3_0_T;

/* Forward declaration for rtModel */
typedef struct tag_RTM_dzwcontrol3_0_T RT_MODEL_dzwcontrol3_0_T;

#endif                                 /* RTW_HEADER_dzwcontrol3_0_types_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
