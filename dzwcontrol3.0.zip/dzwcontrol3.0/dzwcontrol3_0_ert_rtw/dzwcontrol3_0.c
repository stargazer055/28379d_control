/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: dzwcontrol3_0.c
 *
 * Code generated for Simulink model 'dzwcontrol3_0'.
 *
 * Model version                  : 1.41
 * Simulink Coder version         : 9.4 (R2020b) 29-Jul-2020
 * C/C++ source code generated on : Fri Feb  7 17:21:12 2025
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Texas Instruments->C2000
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "dzwcontrol3_0.h"
#include "dzwcontrol3_0_private.h"

/* Exported block states */
real_T B;                              /* '<Root>/Data Store Memory' */
real_T dutycycle;                      /* '<Root>/Data Store Memory14' */
real_T C;                              /* '<Root>/Data Store Memory3' */
real_T A;                              /* '<Root>/Data Store Memory1' */
real_T STOP;                           /* '<Root>/Data Store Memory13' */
real_T RST;                            /* '<Root>/Data Store Memory23' */
real32_T tran_parameter;               /* '<Root>/Data Store Memory16' */
real32_T IE_ref;                       /* '<Root>/Data Store Memory20' */
real32_T IntegralE;                    /* '<Root>/Data Store Memory26' */
real32_T UE;                           /* '<Root>/Data Store Memory27' */
real32_T PLL_rou;                      /* '<Root>/Data Store Memory52' */
real32_T DC_Bus;                       /* '<Root>/Data Store Memory15' */
real32_T Current_F;                    /* '<Root>/Data Store Memory17' */
real32_T Current_E;                    /* '<Root>/Data Store Memory18' */
real32_T Current_D;                    /* '<Root>/Data Store Memory19' */
real32_T KpE;                          /* '<Root>/Data Store Memory24' */
real32_T KiE;                          /* '<Root>/Data Store Memory25' */
real32_T Current_alpha;                /* '<Root>/Data Store Memory28' */
real32_T Current_beta;                 /* '<Root>/Data Store Memory29' */
real32_T VF_Frq;                       /* '<Root>/Data Store Memory30' */
real32_T Theta;                        /* '<Root>/Data Store Memory31' */
real32_T Idfbk;                        /* '<Root>/Data Store Memory32' */
real32_T Iqfbk;                        /* '<Root>/Data Store Memory33' */
real32_T Idref;                        /* '<Root>/Data Store Memory34' */
real32_T Iqref;                        /* '<Root>/Data Store Memory35' */
real32_T Integrald;                    /* '<Root>/Data Store Memory36' */
real32_T Integralq;                    /* '<Root>/Data Store Memory37' */
real32_T Uq;                           /* '<Root>/Data Store Memory38' */
real32_T Ud;                           /* '<Root>/Data Store Memory39' */
real32_T Ubeta;                        /* '<Root>/Data Store Memory40' */
real32_T Ualpha;                       /* '<Root>/Data Store Memory41' */
real32_T Uqref;                        /* '<Root>/Data Store Memory42' */
real32_T Udref;                        /* '<Root>/Data Store Memory43' */
real32_T T2;                           /* '<Root>/Data Store Memory44' */
real32_T T1;                           /* '<Root>/Data Store Memory45' */
real32_T T3;                           /* '<Root>/Data Store Memory46' */
real32_T threephase_Theta;             /* '<Root>/Data Store Memory50' */
real32_T threephase_Frq;               /* '<Root>/Data Store Memory51' */
real32_T Bus_Data;                     /* '<Root>/Data Store Memory8' */
uint16_T E_offset;                     /* '<Root>/Data Store Memory10' */
uint16_T F_offset;                     /* '<Root>/Data Store Memory11' */
uint16_T A_Data;                       /* '<Root>/Data Store Memory12' */
uint16_T Enable;                       /* '<Root>/Data Store Memory2' */
uint16_T ControlMode;                  /* '<Root>/Data Store Memory21' */
uint16_T Stop;                         /* '<Root>/Data Store Memory22' */
uint16_T D_Data;                       /* '<Root>/Data Store Memory4' */
uint16_T D_V_Data;                     /* '<Root>/Data Store Memory47' */
uint16_T E_V_Data;                     /* '<Root>/Data Store Memory48' */
uint16_T F_V_Data;                     /* '<Root>/Data Store Memory49' */
uint16_T E_Data;                       /* '<Root>/Data Store Memory5' */
uint16_T F_Data;                       /* '<Root>/Data Store Memory6' */
uint16_T Bus_offset;                   /* '<Root>/Data Store Memory7' */
uint16_T D_offset;                     /* '<Root>/Data Store Memory9' */

/* Block signals (default storage) */
B_dzwcontrol3_0_T dzwcontrol3_0_B;

/* Block states (default storage) */
DW_dzwcontrol3_0_T dzwcontrol3_0_DW;

/* Real-time model */
static RT_MODEL_dzwcontrol3_0_T dzwcontrol3_0_M_;
RT_MODEL_dzwcontrol3_0_T *const dzwcontrol3_0_M = &dzwcontrol3_0_M_;
uint16_T MW_adcDInitFlag = 0;
uint16_T MW_adcCInitFlag = 0;
uint16_T MW_adcAInitFlag = 0;
uint16_T MW_adcBInitFlag = 0;

/* Hardware Interrupt Block: '<Root>/C28x Hardware Interrupt' */
void isr_int1pie1_task_fcn(void)
{
  if (1 == runModel) {
    /* Call the system: <Root>/ADC interrupt */
    {
      /* S-Function (c28xisr_c2000): '<Root>/C28x Hardware Interrupt' */

      /* Output and update for function-call system: '<Root>/ADC interrupt' */
      {
        /* local block i/o variables */
        real32_T rtb_MultiportSwitch2;
        real32_T rtb_MultiportSwitch1;
        real32_T rtb_MultiportSwitch;
        uint16_T rtb_SFA;
        uint16_T rtb_SFB;
        real_T rtb_Add1;
        real_T rtb_Add2;
        real_T rtb_Add3;
        real_T rtb_Add6;
        real_T rtb_Square;
        real_T tmp;
        int32_T rtb_Product2_p;
        int32_T rtb_y_o;
        real32_T rtb_Gain1_p[3];
        real32_T rtb_Add1_l;
        real32_T rtb_Product;
        real32_T rtb_Product_g;
        uint32_T rtb_Saturation;
        int16_T rtb_Compare_l;
        uint16_T rtb_MultiportSwitch1_a;
        uint16_T tmp_e;
        uint16_T tmp_p;

        /* MATLAB Function: '<S1>/MATLAB Function2' incorporates:
         *  Constant: '<S1>/Constant2'
         */
        dzwcontrol3_0_DW.count++;
        if (dzwcontrol3_0_DW.count > dzwcontrol3_0_P.Constant2_Value_a) {
          /* Outputs for Function Call SubSystem: '<S1>/Adctransfer_and_protect' */
          /* DataStoreWrite: '<S5>/Data Store Write2' incorporates:
           *  Constant: '<S5>/Constant'
           */
          A = dzwcontrol3_0_P.Constant_Value_n;

          /* Product: '<S5>/Product1' incorporates:
           *  Constant: '<S5>/Constant1'
           *  DataStoreRead: '<S5>/Data Store Read3'
           *  DataStoreRead: '<S5>/Data Store Read4'
           *  DataStoreWrite: '<S5>/Data Store Write1'
           *  DataTypeConversion: '<S5>/Data Type Conversion1'
           *  DataTypeConversion: '<S5>/Data Type Conversion2'
           *  Sum: '<S5>/Minus1'
           */
          Current_F = (real32_T)((int32_T)F_Data - F_offset) *
            dzwcontrol3_0_P.Constant1_Value_g;

          /* Product: '<S5>/Product2' incorporates:
           *  Constant: '<S5>/Constant3'
           *  DataStoreRead: '<S5>/Data Store Read6'
           *  DataStoreRead: '<S5>/Data Store Read7'
           *  DataStoreWrite: '<S5>/Data Store Write3'
           *  DataTypeConversion: '<S5>/Data Type Conversion3'
           *  DataTypeConversion: '<S5>/Data Type Conversion4'
           *  Sum: '<S5>/Minus2'
           */
          Current_E = (real32_T)((int32_T)E_Data - E_offset) *
            dzwcontrol3_0_P.Constant3_Value_n;

          /* Product: '<S5>/Product3' incorporates:
           *  Constant: '<S5>/Constant2'
           *  DataStoreRead: '<S5>/Data Store Read5'
           *  DataStoreRead: '<S5>/Data Store Read9'
           *  DataStoreWrite: '<S5>/Data Store Write4'
           *  DataTypeConversion: '<S5>/Data Type Conversion5'
           *  DataTypeConversion: '<S5>/Data Type Conversion6'
           *  Sum: '<S5>/Minus3'
           */
          Current_D = (real32_T)((int32_T)D_Data - D_offset) *
            dzwcontrol3_0_P.Constant2_Value_o;
          for (rtb_Compare_l = 0; rtb_Compare_l < 3; rtb_Compare_l++) {
            /* Gain: '<S13>/Gain1' incorporates:
             *  DataStoreWrite: '<S5>/Data Store Write1'
             *  DataStoreWrite: '<S5>/Data Store Write3'
             *  DataStoreWrite: '<S5>/Data Store Write4'
             *  Gain: '<S13>/Gain3'
             *  SignalConversion generated from: '<S13>/Gain3'
             */
            rtb_Gain1_p[rtb_Compare_l] = dzwcontrol3_0_P.Gain1_Gain_d *
              (dzwcontrol3_0_P.Gain3_Gain_m[rtb_Compare_l + 6] * Current_F +
               (dzwcontrol3_0_P.Gain3_Gain_m[rtb_Compare_l + 3] * Current_E +
                dzwcontrol3_0_P.Gain3_Gain_m[rtb_Compare_l] * Current_D));
          }

          /* DataStoreWrite: '<S5>/Data Store Write5' */
          Current_alpha = rtb_Gain1_p[0];

          /* DataStoreWrite: '<S5>/Data Store Write6' */
          Current_beta = rtb_Gain1_p[1];

          /* Product: '<S5>/Product' incorporates:
           *  Constant: '<S5>/Constant4'
           *  DataStoreRead: '<S5>/Data Store Read'
           *  DataStoreRead: '<S5>/Data Store Read1'
           *  DataStoreWrite: '<S5>/Data Store Write'
           *  Sum: '<S5>/Minus'
           */
          DC_Bus = (Bus_Data - (real32_T)Bus_offset) *
            dzwcontrol3_0_P.Constant4_Value;

          /* MATLAB Function: '<S5>/MATLAB Function1' incorporates:
           *  DataStoreWrite: '<S5>/Data Store Write4'
           */
          if ((fabsf(Current_D) > 8.0F) || (fabsf(Current_E) > 8.0F) || (fabsf
               (Current_F) > 8.0F)) {
            Stop = 1U;
            ControlMode = 0U;
          }

          /* End of MATLAB Function: '<S5>/MATLAB Function1' */
          /* End of Outputs for SubSystem: '<S1>/Adctransfer_and_protect' */

          /* Outputs for Function Call SubSystem: '<S1>/Mode control' */
          /* SwitchCase: '<S8>/Switch Case' incorporates:
           *  Constant: '<S18>/Constant'
           *  Constant: '<S23>/Constant'
           *  Constant: '<S25>/Constant'
           *  Constant: '<S32>/Constant'
           *  Constant: '<S35>/Constant'
           *  Constant: '<S39>/Constant'
           *  Constant: '<S41>/Constant'
           *  Constant: '<S50>/Constant'
           *  Constant: '<S53>/Constant'
           *  Constant: '<S55>/Constant'
           *  Constant: '<S57>/Constant'
           *  Constant: '<S66>/Constant'
           *  DataStoreRead: '<S14>/Data Store Read1'
           *  DataStoreRead: '<S14>/Data Store Read10'
           *  DataStoreRead: '<S14>/Data Store Read11'
           *  DataStoreRead: '<S14>/Data Store Read2'
           *  DataStoreRead: '<S14>/Data Store Read3'
           *  DataStoreRead: '<S14>/Data Store Read9'
           *  DataStoreRead: '<S16>/Data Store Read1'
           *  DataStoreRead: '<S16>/Data Store Read10'
           *  DataStoreRead: '<S16>/Data Store Read11'
           *  DataStoreRead: '<S16>/Data Store Read2'
           *  DataStoreRead: '<S16>/Data Store Read3'
           *  DataStoreRead: '<S16>/Data Store Read9'
           *  DataStoreRead: '<S17>/Data Store Read1'
           *  DataStoreRead: '<S17>/Data Store Read10'
           *  DataStoreRead: '<S17>/Data Store Read11'
           *  DataStoreRead: '<S17>/Data Store Read2'
           *  DataStoreRead: '<S17>/Data Store Read3'
           *  DataStoreRead: '<S17>/Data Store Read9'
           *  DataStoreRead: '<S8>/Data Store Read4'
           *  RelationalOperator: '<S25>/Compare'
           *  RelationalOperator: '<S32>/Compare'
           *  RelationalOperator: '<S41>/Compare'
           *  RelationalOperator: '<S50>/Compare'
           *  RelationalOperator: '<S57>/Compare'
           *  RelationalOperator: '<S66>/Compare'
           */
          switch ((int32_T)ControlMode) {
           case 0L:
            /* Outputs for IfAction SubSystem: '<S8>/Standby&Protect' incorporates:
             *  ActionPort: '<S15>/Action Port'
             */
            /* DataStoreWrite: '<S15>/Data Store Write' incorporates:
             *  Constant: '<S15>/Constant'
             */
            Enable = dzwcontrol3_0_P.Constant_Value_by;

            /* End of Outputs for SubSystem: '<S8>/Standby&Protect' */
            break;

           case 1L:
            /* Outputs for IfAction SubSystem: '<S8>/VF-mode' incorporates:
             *  ActionPort: '<S17>/Action Port'
             */
            /* RelationalOperator: '<S56>/Compare' incorporates:
             *  Constant: '<S53>/Constant'
             *  Constant: '<S56>/Constant'
             */
            rtb_Compare_l = (dzwcontrol3_0_P.AlphaBetaZerotodq0_Alignment ==
                             dzwcontrol3_0_P.CompareToConstant_const);

            /* Outputs for Enabled SubSystem: '<S53>/Subsystem1' */
            dzwcontrol3_0_Subsystem1((uint16_T)rtb_Compare_l, Current_alpha,
              Current_beta, Theta, &dzwcontrol3_0_B.Fcn_bd,
              &dzwcontrol3_0_B.Fcn1_j);

            /* End of Outputs for SubSystem: '<S53>/Subsystem1' */

            /* Outputs for Enabled SubSystem: '<S53>/Subsystem - pi//2 delay' */
            dzwcontrol3_0_Subsystempi2delay((uint16_T)
              (dzwcontrol3_0_P.AlphaBetaZerotodq0_Alignment ==
               dzwcontrol3_0_P.CompareToConstant1_const), Current_alpha,
              Current_beta, Theta, &dzwcontrol3_0_B.Fcn_i0,
              &dzwcontrol3_0_B.Fcn1_ng);

            /* End of Outputs for SubSystem: '<S53>/Subsystem - pi//2 delay' */

            /* Switch: '<S53>/Switch' incorporates:
             *  Constant: '<S53>/Constant'
             *  Constant: '<S57>/Constant'
             *  DataStoreRead: '<S17>/Data Store Read1'
             *  DataStoreRead: '<S17>/Data Store Read2'
             *  DataStoreRead: '<S17>/Data Store Read3'
             *  RelationalOperator: '<S56>/Compare'
             *  RelationalOperator: '<S57>/Compare'
             */
            if ((uint16_T)rtb_Compare_l != 0U) {
              /* DataStoreWrite: '<S17>/Data Store Write5' */
              Idfbk = dzwcontrol3_0_B.Fcn_bd;

              /* DataStoreWrite: '<S17>/Data Store Write6' */
              Iqfbk = dzwcontrol3_0_B.Fcn1_j;
            } else {
              /* DataStoreWrite: '<S17>/Data Store Write5' */
              Idfbk = dzwcontrol3_0_B.Fcn_i0;

              /* DataStoreWrite: '<S17>/Data Store Write6' */
              Iqfbk = dzwcontrol3_0_B.Fcn1_ng;
            }

            /* End of Switch: '<S53>/Switch' */

            /* DataTypeConversion: '<S17>/Data Type Conversion' incorporates:
             *  DataStoreRead: '<S17>/Data Store Read5'
             *  Product: '<S54>/Product2'
             */
            rtb_Add1_l = (real32_T)floor(VF_Frq * 5.36870912E+8F);
            if (rtIsNaNF(rtb_Add1_l) || rtIsInfF(rtb_Add1_l)) {
              rtb_Add1_l = 0.0F;
            } else {
              rtb_Add1_l = (real32_T)fmod(rtb_Add1_l, 4.294967296E+9);
            }

            rtb_Product2_p = rtb_Add1_l < 0.0F ? -(int32_T)(uint32_T)-rtb_Add1_l
              : (int32_T)(uint32_T)rtb_Add1_l;

            /* End of DataTypeConversion: '<S17>/Data Type Conversion' */

            /* S-Function (tidmcrampcntl): '<S17>/Ramp Control' */

            /* C28x DMC Library (tidmcrampcntl) - '<S17>/Ramp Control' */
            {
              int32_T* ptrrampDlyCntl =
                &dzwcontrol3_0_DW.RampControl_RAMP_DLY_CNTL_k;
              int32_T* ptrOldSetPoint =
                &dzwcontrol3_0_DW.RampControl_PREV_SETPOINT_b;
              if (rtb_Product2_p != *ptrOldSetPoint ) {
                /* Original location of the update, now moved after the "if" branch */
                if (*ptrrampDlyCntl >= (long) 1) {
                  if (rtb_Product2_p >= *ptrOldSetPoint) {
                    dzwcontrol3_0_B.RampControl_o1_h = *ptrOldSetPoint + _IQ29
                      (0.0000305);
                    if (dzwcontrol3_0_B.RampControl_o1_h > _IQ29(1.0F))
                      dzwcontrol3_0_B.RampControl_o1_h = _IQ29(1.0F);
                    *ptrrampDlyCntl = 0;
                  } else {
                    dzwcontrol3_0_B.RampControl_o1_h = *ptrOldSetPoint - _IQ29
                      (0.0000305);
                    if (dzwcontrol3_0_B.RampControl_o1_h < _IQ29(0.0F))
                      dzwcontrol3_0_B.RampControl_o1_h = _IQ29(0.0F);
                    *ptrrampDlyCntl = 0;
                  }

                  *ptrOldSetPoint++ = dzwcontrol3_0_B.RampControl_o1_h;
                }

                /* Moved the update here to get more consistent Simulink time change */
                *ptrrampDlyCntl += 1;
              } else {
                dzwcontrol3_0_B.RampControl_o1_h = *ptrOldSetPoint;
                dzwcontrol3_0_B.RampControl_o2_a = 0x7FFFFFFF;
              }

              ptrrampDlyCntl++;
            }

            /* MATLAB Function: '<S60>/Embedded MATLAB Function' */
            dzwcontr_EmbeddedMATLABFunction(&rtb_y_o);

            /* S-Function (scheckfractionlength): '<S54>/ ' incorporates:
             *  Product: '<S54>/Product2'
             *  S-Function (tidmcrampcntl): '<S17>/Ramp Control'
             */
            rtb_Product2_p = dzwcontrol3_0_B.RampControl_o1_h;

            /* Sum: '<S54>/Sum2' incorporates:
             *  Product: '<S54>/Product1'
             *  Product: '<S54>/Product2'
             *  UnitDelay: '<S54>/Unit Delay'
             */
            dzwcontrol3_0_DW.UnitDelay_DSTATE_ot += __IQmpy(rtb_y_o,
              rtb_Product2_p, 29);

            /* Switch: '<S61>/Switch' incorporates:
             *  Constant: '<S61>/1'
             *  RelationalOperator: '<S61>/Relational Operator'
             *  Sum: '<S54>/Sum2'
             *  Sum: '<S61>/Sum2'
             */
            if (dzwcontrol3_0_DW.UnitDelay_DSTATE_ot > dzwcontrol3_0_P.u_Value)
            {
              dzwcontrol3_0_DW.UnitDelay_DSTATE_ot -= dzwcontrol3_0_P.u_Value;
            }

            /* End of Switch: '<S61>/Switch' */

            /* Switch: '<S61>/Switch1' incorporates:
             *  Constant: '<S61>/-1'
             *  RelationalOperator: '<S61>/Relational Operator1'
             *  Switch: '<S61>/Switch'
             */
            if (dzwcontrol3_0_DW.UnitDelay_DSTATE_ot < dzwcontrol3_0_P.u_Value_j)
            {
              /* Sum: '<S54>/Sum2' incorporates:
               *  Constant: '<S61>/1'
               *  Sum: '<S61>/Sum1'
               *  Switch: '<S61>/Switch1'
               */
              dzwcontrol3_0_DW.UnitDelay_DSTATE_ot += dzwcontrol3_0_P.u_Value;
            }

            /* End of Switch: '<S61>/Switch1' */

            /* Product: '<S54>/Product2' incorporates:
             *  Constant: '<S17>/Constant'
             *  Switch: '<S61>/Switch1'
             */
            rtb_Product2_p = __IQmpy(dzwcontrol3_0_DW.UnitDelay_DSTATE_ot,
              dzwcontrol3_0_P.Constant_Value_f, 29);

            /* Sum: '<S54>/Sum1' incorporates:
             *  Constant: '<S17>/Constant1'
             *  Product: '<S54>/Product2'
             */
            rtb_Product2_p += dzwcontrol3_0_P.Constant1_Value_f;

            /* Switch: '<S62>/Switch2' incorporates:
             *  Constant: '<S62>/1'
             *  RelationalOperator: '<S62>/Relational Operator2'
             *  Sum: '<S54>/Sum1'
             *  Sum: '<S62>/Sum4'
             */
            if (rtb_Product2_p > dzwcontrol3_0_P.u_Value_a) {
              rtb_Product2_p -= dzwcontrol3_0_P.u_Value_a;
            }

            /* End of Switch: '<S62>/Switch2' */

            /* Switch: '<S62>/Switch3' incorporates:
             *  Constant: '<S62>/-1'
             *  Constant: '<S62>/1'
             *  RelationalOperator: '<S62>/Relational Operator3'
             *  Sum: '<S62>/Sum3'
             *  Switch: '<S62>/Switch2'
             */
            if (rtb_Product2_p < dzwcontrol3_0_P.u_Value_g) {
              rtb_Product2_p += dzwcontrol3_0_P.u_Value_a;
            }

            /* End of Switch: '<S62>/Switch3' */

            /* Gain: '<S17>/Gain' incorporates:
             *  DataStoreWrite: '<S17>/Data Store Write4'
             *  DataTypeConversion: '<S17>/Data Type Conversion1'
             */
            Theta = (real32_T)rtb_Product2_p * 1.86264515E-9F *
              dzwcontrol3_0_P.Gain_Gain_e;

            /* DataStoreWrite: '<S17>/Data Store Write7' incorporates:
             *  Constant: '<S17>/Constant2'
             */
            Enable = dzwcontrol3_0_P.Constant2_Value_d;

            /* RelationalOperator: '<S65>/Compare' incorporates:
             *  Constant: '<S55>/Constant'
             *  Constant: '<S65>/Constant'
             */
            rtb_Compare_l = (dzwcontrol3_0_P.dq0toAlphaBetaZero_Alignment ==
                             dzwcontrol3_0_P.CompareToConstant_const_i);

            /* Outputs for Enabled SubSystem: '<S55>/Subsystem1' */
            dzwcontrol3_0_Subsystem1_l((uint16_T)rtb_Compare_l, Udref, Uqref,
              Theta, &dzwcontrol3_0_B.Fcn_dz, &dzwcontrol3_0_B.Fcn1_d);

            /* End of Outputs for SubSystem: '<S55>/Subsystem1' */

            /* Outputs for Enabled SubSystem: '<S55>/Subsystem - pi//2 delay' */
            dzwcontrol3_Subsystempi2delay_l((uint16_T)
              (dzwcontrol3_0_P.dq0toAlphaBetaZero_Alignment ==
               dzwcontrol3_0_P.CompareToConstant1_const_c), Udref, Uqref, Theta,
              &dzwcontrol3_0_B.Fcn_c, &dzwcontrol3_0_B.Fcn1_ep);

            /* End of Outputs for SubSystem: '<S55>/Subsystem - pi//2 delay' */

            /* Switch: '<S55>/Switch' incorporates:
             *  Constant: '<S55>/Constant'
             *  Constant: '<S66>/Constant'
             *  DataStoreRead: '<S17>/Data Store Read10'
             *  DataStoreRead: '<S17>/Data Store Read11'
             *  DataStoreRead: '<S17>/Data Store Read9'
             *  RelationalOperator: '<S65>/Compare'
             *  RelationalOperator: '<S66>/Compare'
             */
            if ((uint16_T)rtb_Compare_l != 0U) {
              /* DataStoreWrite: '<S17>/Data Store Write2' */
              Ualpha = dzwcontrol3_0_B.Fcn_dz;

              /* DataStoreWrite: '<S17>/Data Store Write3' */
              Ubeta = dzwcontrol3_0_B.Fcn1_d;
            } else {
              /* DataStoreWrite: '<S17>/Data Store Write2' */
              Ualpha = dzwcontrol3_0_B.Fcn_c;

              /* DataStoreWrite: '<S17>/Data Store Write3' */
              Ubeta = dzwcontrol3_0_B.Fcn1_ep;
            }

            /* End of Switch: '<S55>/Switch' */
            /* End of Outputs for SubSystem: '<S8>/VF-mode' */
            break;

           case 2L:
            /* Outputs for IfAction SubSystem: '<S8>/Three-phase current loop test' incorporates:
             *  ActionPort: '<S16>/Action Port'
             */
            /* RelationalOperator: '<S40>/Compare' incorporates:
             *  Constant: '<S35>/Constant'
             *  Constant: '<S40>/Constant'
             */
            rtb_Compare_l = (dzwcontrol3_0_P.AlphaBetaZerotodq0_Alignment_j ==
                             dzwcontrol3_0_P.CompareToConstant_const_o);

            /* Outputs for Enabled SubSystem: '<S35>/Subsystem1' */
            dzwcontrol3_0_Subsystem1((uint16_T)rtb_Compare_l, Current_alpha,
              Current_beta, Theta, &dzwcontrol3_0_B.Fcn_i,
              &dzwcontrol3_0_B.Fcn1_n);

            /* End of Outputs for SubSystem: '<S35>/Subsystem1' */

            /* Outputs for Enabled SubSystem: '<S35>/Subsystem - pi//2 delay' */
            dzwcontrol3_0_Subsystempi2delay((uint16_T)
              (dzwcontrol3_0_P.AlphaBetaZerotodq0_Alignment_j ==
               dzwcontrol3_0_P.CompareToConstant1_const_d), Current_alpha,
              Current_beta, Theta, &dzwcontrol3_0_B.Fcn_g,
              &dzwcontrol3_0_B.Fcn1_h);

            /* End of Outputs for SubSystem: '<S35>/Subsystem - pi//2 delay' */

            /* Switch: '<S35>/Switch' incorporates:
             *  Constant: '<S35>/Constant'
             *  Constant: '<S41>/Constant'
             *  DataStoreRead: '<S16>/Data Store Read1'
             *  DataStoreRead: '<S16>/Data Store Read2'
             *  DataStoreRead: '<S16>/Data Store Read3'
             *  RelationalOperator: '<S40>/Compare'
             *  RelationalOperator: '<S41>/Compare'
             */
            if ((uint16_T)rtb_Compare_l != 0U) {
              /* DataStoreWrite: '<S16>/Data Store Write5' */
              Idfbk = dzwcontrol3_0_B.Fcn_i;

              /* DataStoreWrite: '<S16>/Data Store Write6' */
              Iqfbk = dzwcontrol3_0_B.Fcn1_n;
            } else {
              /* DataStoreWrite: '<S16>/Data Store Write5' */
              Idfbk = dzwcontrol3_0_B.Fcn_g;

              /* DataStoreWrite: '<S16>/Data Store Write6' */
              Iqfbk = dzwcontrol3_0_B.Fcn1_h;
            }

            /* End of Switch: '<S35>/Switch' */

            /* DataTypeConversion: '<S16>/Data Type Conversion' incorporates:
             *  DataStoreRead: '<S16>/Data Store Read5'
             *  Product: '<S38>/Product2'
             */
            rtb_Add1_l = (real32_T)floor(VF_Frq * 5.36870912E+8F);
            if (rtIsNaNF(rtb_Add1_l) || rtIsInfF(rtb_Add1_l)) {
              rtb_Add1_l = 0.0F;
            } else {
              rtb_Add1_l = (real32_T)fmod(rtb_Add1_l, 4.294967296E+9);
            }

            rtb_Product2_p = rtb_Add1_l < 0.0F ? -(int32_T)(uint32_T)-rtb_Add1_l
              : (int32_T)(uint32_T)rtb_Add1_l;

            /* End of DataTypeConversion: '<S16>/Data Type Conversion' */

            /* S-Function (tidmcrampcntl): '<S16>/Ramp Control' */

            /* C28x DMC Library (tidmcrampcntl) - '<S16>/Ramp Control' */
            {
              int32_T* ptrrampDlyCntl =
                &dzwcontrol3_0_DW.RampControl_RAMP_DLY_CNTL;
              int32_T* ptrOldSetPoint =
                &dzwcontrol3_0_DW.RampControl_PREV_SETPOINT;
              if (rtb_Product2_p != *ptrOldSetPoint ) {
                /* Original location of the update, now moved after the "if" branch */
                if (*ptrrampDlyCntl >= (long) 1) {
                  if (rtb_Product2_p >= *ptrOldSetPoint) {
                    dzwcontrol3_0_B.RampControl_o1 = *ptrOldSetPoint + _IQ29
                      (0.0000305);
                    if (dzwcontrol3_0_B.RampControl_o1 > _IQ29(1.0F))
                      dzwcontrol3_0_B.RampControl_o1 = _IQ29(1.0F);
                    *ptrrampDlyCntl = 0;
                  } else {
                    dzwcontrol3_0_B.RampControl_o1 = *ptrOldSetPoint - _IQ29
                      (0.0000305);
                    if (dzwcontrol3_0_B.RampControl_o1 < _IQ29(0.0F))
                      dzwcontrol3_0_B.RampControl_o1 = _IQ29(0.0F);
                    *ptrrampDlyCntl = 0;
                  }

                  *ptrOldSetPoint++ = dzwcontrol3_0_B.RampControl_o1;
                }

                /* Moved the update here to get more consistent Simulink time change */
                *ptrrampDlyCntl += 1;
              } else {
                dzwcontrol3_0_B.RampControl_o1 = *ptrOldSetPoint;
                dzwcontrol3_0_B.RampControl_o2 = 0x7FFFFFFF;
              }

              ptrrampDlyCntl++;
            }

            /* MATLAB Function: '<S44>/Embedded MATLAB Function' */
            dzwcontr_EmbeddedMATLABFunction(&rtb_y_o);

            /* S-Function (scheckfractionlength): '<S38>/ ' incorporates:
             *  Product: '<S38>/Product2'
             *  S-Function (tidmcrampcntl): '<S16>/Ramp Control'
             */
            rtb_Product2_p = dzwcontrol3_0_B.RampControl_o1;

            /* Sum: '<S38>/Sum2' incorporates:
             *  Product: '<S38>/Product1'
             *  Product: '<S38>/Product2'
             *  UnitDelay: '<S38>/Unit Delay'
             */
            dzwcontrol3_0_DW.UnitDelay_DSTATE_o += __IQmpy(rtb_y_o,
              rtb_Product2_p, 29);

            /* Switch: '<S45>/Switch' incorporates:
             *  Constant: '<S45>/1'
             *  RelationalOperator: '<S45>/Relational Operator'
             *  Sum: '<S38>/Sum2'
             *  Sum: '<S45>/Sum2'
             */
            if (dzwcontrol3_0_DW.UnitDelay_DSTATE_o > dzwcontrol3_0_P.u_Value_n)
            {
              dzwcontrol3_0_DW.UnitDelay_DSTATE_o -= dzwcontrol3_0_P.u_Value_n;
            }

            /* End of Switch: '<S45>/Switch' */

            /* Switch: '<S45>/Switch1' incorporates:
             *  Constant: '<S45>/-1'
             *  RelationalOperator: '<S45>/Relational Operator1'
             *  Switch: '<S45>/Switch'
             */
            if (dzwcontrol3_0_DW.UnitDelay_DSTATE_o < dzwcontrol3_0_P.u_Value_e)
            {
              /* Sum: '<S38>/Sum2' incorporates:
               *  Constant: '<S45>/1'
               *  Sum: '<S45>/Sum1'
               *  Switch: '<S45>/Switch1'
               */
              dzwcontrol3_0_DW.UnitDelay_DSTATE_o += dzwcontrol3_0_P.u_Value_n;
            }

            /* End of Switch: '<S45>/Switch1' */

            /* Product: '<S38>/Product2' incorporates:
             *  Constant: '<S16>/Constant'
             *  Switch: '<S45>/Switch1'
             */
            rtb_Product2_p = __IQmpy(dzwcontrol3_0_DW.UnitDelay_DSTATE_o,
              dzwcontrol3_0_P.Constant_Value_b, 29);

            /* Sum: '<S38>/Sum1' incorporates:
             *  Constant: '<S16>/Constant1'
             *  Product: '<S38>/Product2'
             */
            rtb_Product2_p += dzwcontrol3_0_P.Constant1_Value_e;

            /* Switch: '<S46>/Switch2' incorporates:
             *  Constant: '<S46>/1'
             *  RelationalOperator: '<S46>/Relational Operator2'
             *  Sum: '<S38>/Sum1'
             *  Sum: '<S46>/Sum4'
             */
            if (rtb_Product2_p > dzwcontrol3_0_P.u_Value_i) {
              rtb_Product2_p -= dzwcontrol3_0_P.u_Value_i;
            }

            /* End of Switch: '<S46>/Switch2' */

            /* Switch: '<S46>/Switch3' incorporates:
             *  Constant: '<S46>/-1'
             *  Constant: '<S46>/1'
             *  RelationalOperator: '<S46>/Relational Operator3'
             *  Sum: '<S46>/Sum3'
             *  Switch: '<S46>/Switch2'
             */
            if (rtb_Product2_p < dzwcontrol3_0_P.u_Value_nq) {
              rtb_Product2_p += dzwcontrol3_0_P.u_Value_i;
            }

            /* End of Switch: '<S46>/Switch3' */

            /* Gain: '<S16>/Gain' incorporates:
             *  DataStoreWrite: '<S16>/Data Store Write4'
             *  DataTypeConversion: '<S16>/Data Type Conversion1'
             */
            Theta = (real32_T)rtb_Product2_p * 1.86264515E-9F *
              dzwcontrol3_0_P.Gain_Gain_f;

            /* DataStoreWrite: '<S16>/Data Store Write7' incorporates:
             *  Constant: '<S16>/Constant2'
             */
            Enable = dzwcontrol3_0_P.Constant2_Value_l;

            /* RelationalOperator: '<S49>/Compare' incorporates:
             *  Constant: '<S39>/Constant'
             *  Constant: '<S49>/Constant'
             */
            rtb_Compare_l = (dzwcontrol3_0_P.dq0toAlphaBetaZero_Alignment_o ==
                             dzwcontrol3_0_P.CompareToConstant_const_k);

            /* Outputs for Enabled SubSystem: '<S39>/Subsystem1' */
            dzwcontrol3_0_Subsystem1_l((uint16_T)rtb_Compare_l, Ud, Uq, Theta,
              &dzwcontrol3_0_B.Fcn_h, &dzwcontrol3_0_B.Fcn1_b);

            /* End of Outputs for SubSystem: '<S39>/Subsystem1' */

            /* Outputs for Enabled SubSystem: '<S39>/Subsystem - pi//2 delay' */
            dzwcontrol3_Subsystempi2delay_l((uint16_T)
              (dzwcontrol3_0_P.dq0toAlphaBetaZero_Alignment_o ==
               dzwcontrol3_0_P.CompareToConstant1_const_g), Ud, Uq, Theta,
              &dzwcontrol3_0_B.Fcn_b, &dzwcontrol3_0_B.Fcn1_g);

            /* End of Outputs for SubSystem: '<S39>/Subsystem - pi//2 delay' */

            /* Switch: '<S39>/Switch' incorporates:
             *  Constant: '<S39>/Constant'
             *  Constant: '<S50>/Constant'
             *  DataStoreRead: '<S16>/Data Store Read10'
             *  DataStoreRead: '<S16>/Data Store Read11'
             *  DataStoreRead: '<S16>/Data Store Read9'
             *  RelationalOperator: '<S49>/Compare'
             *  RelationalOperator: '<S50>/Compare'
             */
            if ((uint16_T)rtb_Compare_l != 0U) {
              /* DataStoreWrite: '<S16>/Data Store Write2' */
              Ualpha = dzwcontrol3_0_B.Fcn_h;

              /* DataStoreWrite: '<S16>/Data Store Write3' */
              Ubeta = dzwcontrol3_0_B.Fcn1_b;
            } else {
              /* DataStoreWrite: '<S16>/Data Store Write2' */
              Ualpha = dzwcontrol3_0_B.Fcn_b;

              /* DataStoreWrite: '<S16>/Data Store Write3' */
              Ubeta = dzwcontrol3_0_B.Fcn1_g;
            }

            /* End of Switch: '<S39>/Switch' */

            /* Sum: '<S36>/Sum2' incorporates:
             *  DataStoreRead: '<S16>/Data Store Read4'
             *  DataStoreRead: '<S16>/Data Store Read6'
             */
            rtb_Add1_l = Idref - Idfbk;

            /* Product: '<S36>/Product' incorporates:
             *  DataStoreRead: '<S36>/Data Store Read'
             */
            rtb_Product_g = rtb_Add1_l * KpE;

            /* Sum: '<S36>/Add' incorporates:
             *  DataStoreRead: '<S36>/Data Store Read1'
             *  DataStoreRead: '<S36>/Data Store Read2'
             *  Gain: '<S36>/Gain'
             *  Product: '<S36>/Product1'
             */
            rtb_Add1_l = rtb_Add1_l * KiE * dzwcontrol3_0_P.Ts + Integrald;

            /* Sum: '<S36>/Add1' */
            Ud = rtb_Product_g + rtb_Add1_l;

            /* Saturate: '<S36>/Saturation' */
            if (Ud > dzwcontrol3_0_P.Udc) {
              /* Sum: '<S36>/Add1' */
              Ud = dzwcontrol3_0_P.Udc;
            } else {
              if (Ud < dzwcontrol3_0_P.Saturation_LowerSat) {
                /* Sum: '<S36>/Add1' incorporates:
                 *  Saturate: '<S36>/Saturation'
                 */
                Ud = dzwcontrol3_0_P.Saturation_LowerSat;
              }
            }

            /* End of Saturate: '<S36>/Saturation' */

            /* Saturate: '<S36>/Saturation1' */
            if (rtb_Add1_l > dzwcontrol3_0_P.Udc) {
              Integrald = dzwcontrol3_0_P.Udc;
            } else if (rtb_Add1_l < dzwcontrol3_0_P.Saturation1_LowerSat_p) {
              Integrald = dzwcontrol3_0_P.Saturation1_LowerSat_p;
            } else {
              Integrald = rtb_Add1_l;
            }

            /* End of Saturate: '<S36>/Saturation1' */

            /* Sum: '<S37>/Sum2' incorporates:
             *  DataStoreRead: '<S16>/Data Store Read7'
             *  DataStoreRead: '<S16>/Data Store Read8'
             */
            rtb_Add1_l = Iqref - Iqfbk;

            /* Product: '<S37>/Product' incorporates:
             *  DataStoreRead: '<S37>/Data Store Read'
             */
            rtb_Product_g = rtb_Add1_l * KpE;

            /* Sum: '<S37>/Add' incorporates:
             *  DataStoreRead: '<S37>/Data Store Read1'
             *  DataStoreRead: '<S37>/Data Store Read2'
             *  Gain: '<S37>/Gain'
             *  Product: '<S37>/Product1'
             */
            rtb_Add1_l = rtb_Add1_l * KiE * dzwcontrol3_0_P.Ts + Integralq;

            /* Sum: '<S37>/Add1' */
            Uq = rtb_Product_g + rtb_Add1_l;

            /* Saturate: '<S37>/Saturation' */
            if (Uq > dzwcontrol3_0_P.Udc) {
              /* Sum: '<S37>/Add1' */
              Uq = dzwcontrol3_0_P.Udc;
            } else {
              if (Uq < dzwcontrol3_0_P.Saturation_LowerSat_n) {
                /* Sum: '<S37>/Add1' incorporates:
                 *  Saturate: '<S37>/Saturation'
                 */
                Uq = dzwcontrol3_0_P.Saturation_LowerSat_n;
              }
            }

            /* End of Saturate: '<S37>/Saturation' */

            /* Saturate: '<S37>/Saturation1' */
            if (rtb_Add1_l > dzwcontrol3_0_P.Udc) {
              Integralq = dzwcontrol3_0_P.Udc;
            } else if (rtb_Add1_l < dzwcontrol3_0_P.Saturation1_LowerSat_a) {
              Integralq = dzwcontrol3_0_P.Saturation1_LowerSat_a;
            } else {
              Integralq = rtb_Add1_l;
            }

            /* End of Saturate: '<S37>/Saturation1' */
            /* End of Outputs for SubSystem: '<S8>/Three-phase current loop test' */
            break;

           case 3L:
            /* Outputs for IfAction SubSystem: '<S8>/DC-bus control mode' incorporates:
             *  ActionPort: '<S14>/Action Port'
             */
            for (rtb_Compare_l = 0; rtb_Compare_l < 3; rtb_Compare_l++) {
              /* Gain: '<S22>/Gain1' incorporates:
               *  DataStoreRead: '<S14>/Data Store Read12'
               *  DataStoreRead: '<S14>/Data Store Read13'
               *  DataStoreRead: '<S14>/Data Store Read5'
               *  Gain: '<S22>/Gain3'
               *  SignalConversion generated from: '<S22>/Gain3'
               */
              rtb_Gain1_p[rtb_Compare_l] = dzwcontrol3_0_P.Gain1_Gain_h *
                (dzwcontrol3_0_P.Gain3_Gain_g[rtb_Compare_l + 6] * Current_F +
                 (dzwcontrol3_0_P.Gain3_Gain_g[rtb_Compare_l + 3] * Current_E +
                  dzwcontrol3_0_P.Gain3_Gain_g[rtb_Compare_l] * Current_D));
            }

            /* MATLAB Function: '<S21>/MATLAB Function' */
            rtb_Add1_l = rtb_Gain1_p[0] * rtb_Gain1_p[0] + rtb_Gain1_p[1] *
              rtb_Gain1_p[1];
            if (rtb_Add1_l == 0.0F) {
              rtb_Add1_l = 1.0F;
            } else {
              rtb_Add1_l = (real32_T)sqrt(rtb_Add1_l);
            }

            /* End of MATLAB Function: '<S21>/MATLAB Function' */

            /* Product: '<S21>/Divide' incorporates:
             *  Product: '<S21>/Product'
             *  Product: '<S21>/Product1'
             *  Sum: '<S21>/Add'
             *  Trigonometry: '<S21>/Cos'
             *  Trigonometry: '<S21>/Sin'
             *  UnitDelay: '<S21>/Unit Delay1'
             */
            rtb_Add1_l = ((0.0F - (real32_T)sin
                           (dzwcontrol3_0_DW.UnitDelay1_DSTATE_e) * rtb_Gain1_p
                           [1]) - (real32_T)cos
                          (dzwcontrol3_0_DW.UnitDelay1_DSTATE_e) * rtb_Gain1_p[0])
              / rtb_Add1_l;

            /* Math: '<S30>/Square' incorporates:
             *  DataStoreRead: '<S30>/Data Store Read'
             */
            rtb_Square = A * A;

            /* Saturate: '<S30>/Saturation3' incorporates:
             *  Gain: '<S30>/Gain1'
             *  Gain: '<S30>/Gain2'
             *  Gain: '<S30>/Gain3'
             *  Gain: '<S30>/Gain4'
             *  Product: '<S30>/Product3'
             *  Product: '<S30>/Product4'
             *  Sum: '<S30>/Add2'
             *  UnitDelay: '<S30>/Unit Delay1'
             *  UnitDelay: '<S30>/Unit Delay2'
             */
            dzwcontrol3_0_DW.UnitDelay2_DSTATE_c = (((real32_T)(rtb_Add1_l *
              rtb_Square) * dzwcontrol3_0_P.Gain1_Gain_p + rtb_Square *
              dzwcontrol3_0_DW.UnitDelay1_DSTATE_o * dzwcontrol3_0_P.Gain2_Gain)
              + dzwcontrol3_0_P.Gain3_Gain *
              dzwcontrol3_0_DW.UnitDelay2_DSTATE_c) * dzwcontrol3_0_P.Gain4_Gain;

            /* Saturate: '<S30>/Saturation3' */
            if (dzwcontrol3_0_DW.UnitDelay2_DSTATE_c >
                dzwcontrol3_0_P.Saturation3_UpperSat) {
              /* Saturate: '<S30>/Saturation3' */
              dzwcontrol3_0_DW.UnitDelay2_DSTATE_c =
                dzwcontrol3_0_P.Saturation3_UpperSat;
            } else {
              if (dzwcontrol3_0_DW.UnitDelay2_DSTATE_c <
                  dzwcontrol3_0_P.Saturation3_LowerSat) {
                /* Saturate: '<S30>/Saturation3' */
                dzwcontrol3_0_DW.UnitDelay2_DSTATE_c =
                  dzwcontrol3_0_P.Saturation3_LowerSat;
              }
            }

            /* End of Saturate: '<S30>/Saturation3' */

            /* Sum: '<S30>/Add3' incorporates:
             *  DataStoreRead: '<S30>/Data Store Read'
             *  Gain: '<S30>/Gain'
             *  Product: '<S30>/Product2'
             */
            rtb_Square = (real32_T)(dzwcontrol3_0_P.Gain_Gain * A * rtb_Add1_l)
              + dzwcontrol3_0_DW.UnitDelay2_DSTATE_c;

            /* Saturate: '<S30>/Saturation1' */
            if (rtb_Square > dzwcontrol3_0_P.Saturation1_UpperSat) {
              rtb_Square = dzwcontrol3_0_P.Saturation1_UpperSat;
            } else {
              if (rtb_Square < dzwcontrol3_0_P.Saturation1_LowerSat) {
                rtb_Square = dzwcontrol3_0_P.Saturation1_LowerSat;
              }
            }

            /* End of Saturate: '<S30>/Saturation1' */

            /* Gain: '<S14>/Gain' incorporates:
             *  DataStoreWrite: '<S14>/Data Store Write4'
             */
            threephase_Frq = (real32_T)(dzwcontrol3_0_P.Gain_Gain_d * rtb_Square);

            /* Math: '<S28>/Math Function' incorporates:
             *  Constant: '<S28>/Constant1'
             *  DataStoreWrite: '<S14>/Data Store Write8'
             *  Gain: '<S28>/Gain1'
             *  Gain: '<S28>/Gain2'
             *  Gain: '<S28>/Gain3'
             *  Gain: '<S28>/Gain4'
             *  Sum: '<S28>/Add2'
             *  UnitDelay: '<S28>/Unit Delay1'
             *  UnitDelay: '<S28>/Unit Delay2'
             */
            threephase_Theta = rt_modf_snf((((real32_T)
              (dzwcontrol3_0_P.Gain1_Gain * rtb_Square) + (real32_T)
              (dzwcontrol3_0_P.Gain2_Gain_m *
               dzwcontrol3_0_DW.UnitDelay1_DSTATE_j)) +
              dzwcontrol3_0_P.Gain3_Gain_c *
              dzwcontrol3_0_DW.UnitDelay2_DSTATE_k) *
              dzwcontrol3_0_P.Gain4_Gain_b, dzwcontrol3_0_P.Constant1_Value_n);

            /* RelationalOperator: '<S24>/Compare' incorporates:
             *  Constant: '<S18>/Constant'
             *  Constant: '<S24>/Constant'
             */
            rtb_Compare_l = (dzwcontrol3_0_P.AlphaBetaZerotodq0_Alignment_m ==
                             dzwcontrol3_0_P.CompareToConstant_const_l);

            /* Outputs for Enabled SubSystem: '<S18>/Subsystem1' */
            dzwcontrol3_0_Subsystem1((uint16_T)rtb_Compare_l, Current_alpha,
              Current_beta, Theta, &dzwcontrol3_0_B.Fcn_d,
              &dzwcontrol3_0_B.Fcn1_e);

            /* End of Outputs for SubSystem: '<S18>/Subsystem1' */

            /* Outputs for Enabled SubSystem: '<S18>/Subsystem - pi//2 delay' */
            dzwcontrol3_0_Subsystempi2delay((uint16_T)
              (dzwcontrol3_0_P.AlphaBetaZerotodq0_Alignment_m ==
               dzwcontrol3_0_P.CompareToConstant1_const_cv), Current_alpha,
              Current_beta, Theta, &dzwcontrol3_0_B.Fcn_f,
              &dzwcontrol3_0_B.Fcn1_o);

            /* End of Outputs for SubSystem: '<S18>/Subsystem - pi//2 delay' */

            /* Switch: '<S18>/Switch' incorporates:
             *  Constant: '<S18>/Constant'
             *  Constant: '<S25>/Constant'
             *  DataStoreRead: '<S14>/Data Store Read1'
             *  DataStoreRead: '<S14>/Data Store Read2'
             *  DataStoreRead: '<S14>/Data Store Read3'
             *  RelationalOperator: '<S24>/Compare'
             *  RelationalOperator: '<S25>/Compare'
             */
            if ((uint16_T)rtb_Compare_l != 0U) {
              /* DataStoreWrite: '<S14>/Data Store Write5' */
              Idfbk = dzwcontrol3_0_B.Fcn_d;

              /* DataStoreWrite: '<S14>/Data Store Write6' */
              Iqfbk = dzwcontrol3_0_B.Fcn1_e;
            } else {
              /* DataStoreWrite: '<S14>/Data Store Write5' */
              Idfbk = dzwcontrol3_0_B.Fcn_f;

              /* DataStoreWrite: '<S14>/Data Store Write6' */
              Iqfbk = dzwcontrol3_0_B.Fcn1_o;
            }

            /* End of Switch: '<S18>/Switch' */

            /* DataStoreWrite: '<S14>/Data Store Write7' incorporates:
             *  Constant: '<S14>/Constant2'
             */
            Enable = dzwcontrol3_0_P.Constant2_Value_f;

            /* RelationalOperator: '<S31>/Compare' incorporates:
             *  Constant: '<S23>/Constant'
             *  Constant: '<S31>/Constant'
             */
            rtb_Compare_l = (dzwcontrol3_0_P.dq0toAlphaBetaZero_Alignment_a ==
                             dzwcontrol3_0_P.CompareToConstant_const_c);

            /* Outputs for Enabled SubSystem: '<S23>/Subsystem1' */
            dzwcontrol3_0_Subsystem1_l((uint16_T)rtb_Compare_l, Ud, Uq, Theta,
              &dzwcontrol3_0_B.Fcn, &dzwcontrol3_0_B.Fcn1);

            /* End of Outputs for SubSystem: '<S23>/Subsystem1' */

            /* Outputs for Enabled SubSystem: '<S23>/Subsystem - pi//2 delay' */
            dzwcontrol3_Subsystempi2delay_l((uint16_T)
              (dzwcontrol3_0_P.dq0toAlphaBetaZero_Alignment_a ==
               dzwcontrol3_0_P.CompareToConstant1_const_l), Ud, Uq, Theta,
              &dzwcontrol3_0_B.Fcn_e, &dzwcontrol3_0_B.Fcn1_m);

            /* End of Outputs for SubSystem: '<S23>/Subsystem - pi//2 delay' */

            /* Switch: '<S23>/Switch' incorporates:
             *  Constant: '<S23>/Constant'
             *  Constant: '<S32>/Constant'
             *  DataStoreRead: '<S14>/Data Store Read10'
             *  DataStoreRead: '<S14>/Data Store Read11'
             *  DataStoreRead: '<S14>/Data Store Read9'
             *  RelationalOperator: '<S31>/Compare'
             *  RelationalOperator: '<S32>/Compare'
             */
            if ((uint16_T)rtb_Compare_l != 0U) {
              /* DataStoreWrite: '<S14>/Data Store Write2' */
              Ualpha = dzwcontrol3_0_B.Fcn;

              /* DataStoreWrite: '<S14>/Data Store Write3' */
              Ubeta = dzwcontrol3_0_B.Fcn1;
            } else {
              /* DataStoreWrite: '<S14>/Data Store Write2' */
              Ualpha = dzwcontrol3_0_B.Fcn_e;

              /* DataStoreWrite: '<S14>/Data Store Write3' */
              Ubeta = dzwcontrol3_0_B.Fcn1_m;
            }

            /* End of Switch: '<S23>/Switch' */

            /* Sum: '<S19>/Sum2' incorporates:
             *  DataStoreRead: '<S14>/Data Store Read4'
             *  DataStoreRead: '<S14>/Data Store Read6'
             */
            rtb_Product_g = Idref - Idfbk;

            /* Product: '<S19>/Product' incorporates:
             *  DataStoreRead: '<S19>/Data Store Read'
             */
            rtb_Product = rtb_Product_g * KpE;

            /* Sum: '<S19>/Add' incorporates:
             *  DataStoreRead: '<S19>/Data Store Read1'
             *  DataStoreRead: '<S19>/Data Store Read2'
             *  Gain: '<S19>/Gain'
             *  Product: '<S19>/Product1'
             */
            rtb_Product_g = rtb_Product_g * KiE * dzwcontrol3_0_P.Ts + Integrald;

            /* Sum: '<S36>/Add1' incorporates:
             *  Sum: '<S19>/Add1'
             */
            Ud = rtb_Product + rtb_Product_g;

            /* Saturate: '<S19>/Saturation' */
            if (Ud > dzwcontrol3_0_P.Udc) {
              /* Sum: '<S36>/Add1' */
              Ud = dzwcontrol3_0_P.Udc;
            } else {
              if (Ud < dzwcontrol3_0_P.Saturation_LowerSat_e) {
                /* Sum: '<S36>/Add1' incorporates:
                 *  Saturate: '<S19>/Saturation'
                 */
                Ud = dzwcontrol3_0_P.Saturation_LowerSat_e;
              }
            }

            /* End of Saturate: '<S19>/Saturation' */

            /* Saturate: '<S19>/Saturation1' */
            if (rtb_Product_g > dzwcontrol3_0_P.Udc) {
              Integrald = dzwcontrol3_0_P.Udc;
            } else if (rtb_Product_g < dzwcontrol3_0_P.Saturation1_LowerSat_k) {
              Integrald = dzwcontrol3_0_P.Saturation1_LowerSat_k;
            } else {
              Integrald = rtb_Product_g;
            }

            /* End of Saturate: '<S19>/Saturation1' */

            /* Sum: '<S20>/Sum2' incorporates:
             *  DataStoreRead: '<S14>/Data Store Read7'
             *  DataStoreRead: '<S14>/Data Store Read8'
             */
            rtb_Product_g = Iqref - Iqfbk;

            /* Product: '<S20>/Product' incorporates:
             *  DataStoreRead: '<S20>/Data Store Read'
             */
            rtb_Product = rtb_Product_g * KpE;

            /* Sum: '<S20>/Add' incorporates:
             *  DataStoreRead: '<S20>/Data Store Read1'
             *  DataStoreRead: '<S20>/Data Store Read2'
             *  Gain: '<S20>/Gain'
             *  Product: '<S20>/Product1'
             */
            rtb_Product_g = rtb_Product_g * KiE * dzwcontrol3_0_P.Ts + Integralq;

            /* Sum: '<S37>/Add1' incorporates:
             *  Sum: '<S20>/Add1'
             */
            Uq = rtb_Product + rtb_Product_g;

            /* Saturate: '<S20>/Saturation' */
            if (Uq > dzwcontrol3_0_P.Udc) {
              /* Sum: '<S37>/Add1' */
              Uq = dzwcontrol3_0_P.Udc;
            } else {
              if (Uq < dzwcontrol3_0_P.Saturation_LowerSat_o) {
                /* Sum: '<S37>/Add1' incorporates:
                 *  Saturate: '<S20>/Saturation'
                 */
                Uq = dzwcontrol3_0_P.Saturation_LowerSat_o;
              }
            }

            /* End of Saturate: '<S20>/Saturation' */

            /* Saturate: '<S20>/Saturation1' */
            if (rtb_Product_g > dzwcontrol3_0_P.Udc) {
              Integralq = dzwcontrol3_0_P.Udc;
            } else if (rtb_Product_g < dzwcontrol3_0_P.Saturation1_LowerSat_f) {
              Integralq = dzwcontrol3_0_P.Saturation1_LowerSat_f;
            } else {
              Integralq = rtb_Product_g;
            }

            /* End of Saturate: '<S20>/Saturation1' */

            /* Update for UnitDelay: '<S21>/Unit Delay1' incorporates:
             *  DataStoreWrite: '<S14>/Data Store Write8'
             */
            dzwcontrol3_0_DW.UnitDelay1_DSTATE_e = threephase_Theta;

            /* Update for UnitDelay: '<S30>/Unit Delay1' */
            dzwcontrol3_0_DW.UnitDelay1_DSTATE_o = rtb_Add1_l;

            /* Update for UnitDelay: '<S28>/Unit Delay1' */
            dzwcontrol3_0_DW.UnitDelay1_DSTATE_j = rtb_Square;

            /* Update for UnitDelay: '<S28>/Unit Delay2' incorporates:
             *  DataStoreWrite: '<S14>/Data Store Write8'
             */
            dzwcontrol3_0_DW.UnitDelay2_DSTATE_k = threephase_Theta;

            /* End of Outputs for SubSystem: '<S8>/DC-bus control mode' */
            break;

           case 4L:
            break;
          }

          /* End of SwitchCase: '<S8>/Switch Case' */
          /* End of Outputs for SubSystem: '<S1>/Mode control' */

          /* Outputs for Function Call SubSystem: '<S1>/Enable' */
          /* DataStoreRead: '<S6>/Data Store Read2' incorporates:
           *  DataStoreRead: '<S6>/Data Store Read'
           */
          dzwcontrol3_0_B.DataStoreRead2 = Enable;

          /* S-Function (c280xgpio_do): '<S6>/Low EN' */
          {
            if (dzwcontrol3_0_B.DataStoreRead2)
              GpioDataRegs.GPCSET.bit.GPIO88 = 1;
            else
              GpioDataRegs.GPCCLEAR.bit.GPIO88 = 1;
          }

          /* S-Function (c280xgpio_do): '<S6>/Up EN' */
          {
            if (dzwcontrol3_0_B.DataStoreRead2)
              GpioDataRegs.GPCSET.bit.GPIO86 = 1;
            else
              GpioDataRegs.GPCCLEAR.bit.GPIO86 = 1;
          }

          /* DataStoreRead: '<S6>/Data Store Read2' incorporates:
           *  DataStoreRead: '<S6>/Data Store Read1'
           */
          dzwcontrol3_0_B.DataStoreRead2 = Enable;

          /* S-Function (c280xgpio_do): '<S6>/Low EN2' */
          {
            if (dzwcontrol3_0_B.DataStoreRead2)
              GpioDataRegs.GPCSET.bit.GPIO92 = 1;
            else
              GpioDataRegs.GPCCLEAR.bit.GPIO92 = 1;
          }

          /* S-Function (c280xgpio_do): '<S6>/Up EN2' */
          {
            if (dzwcontrol3_0_B.DataStoreRead2)
              GpioDataRegs.GPCSET.bit.GPIO90 = 1;
            else
              GpioDataRegs.GPCCLEAR.bit.GPIO90 = 1;
          }

          /* DataStoreRead: '<S6>/Data Store Read2' */
          dzwcontrol3_0_B.DataStoreRead2 = Enable;

          /* S-Function (c280xgpio_do): '<S6>/Low EN3' */
          {
            if (dzwcontrol3_0_B.DataStoreRead2)
              GpioDataRegs.GPDSET.bit.GPIO120 = 1;
            else
              GpioDataRegs.GPDCLEAR.bit.GPIO120 = 1;
          }

          /* S-Function (c280xgpio_do): '<S6>/Up EN3' */
          {
            if (dzwcontrol3_0_B.DataStoreRead2)
              GpioDataRegs.GPCSET.bit.GPIO94 = 1;
            else
              GpioDataRegs.GPCCLEAR.bit.GPIO94 = 1;
          }

          /* End of Outputs for SubSystem: '<S1>/Enable' */

          /* Outputs for Function Call SubSystem: '<S1>/Triggered Subsystem' */
          /* MultiPortSwitch: '<S71>/Multiport Switch1' incorporates:
           *  DataStoreRead: '<S9>/Data Store Read3'
           *  Gain: '<S75>/Gain'
           */
          rtb_MultiportSwitch1 = dzwcontrol3_0_P.Gain_Gain_fd * Ualpha;

          /* MultiPortSwitch: '<S71>/Multiport Switch' incorporates:
           *  DataStoreRead: '<S9>/Data Store Read4'
           *  Gain: '<S75>/Gain3'
           */
          rtb_MultiportSwitch = dzwcontrol3_0_P.Gain3_Gain_p * Ubeta;

          /* Switch: '<S75>/A' incorporates:
           *  Constant: '<S75>/Constant'
           *  Constant: '<S75>/Constant1'
           *  DataStoreRead: '<S9>/Data Store Read4'
           */
          if (Ubeta > dzwcontrol3_0_P.A_Threshold) {
            rtb_MultiportSwitch1_a = dzwcontrol3_0_P.Constant_Value_h;
          } else {
            rtb_MultiportSwitch1_a = dzwcontrol3_0_P.Constant1_Value_i;
          }

          /* End of Switch: '<S75>/A' */

          /* Switch: '<S75>/B' incorporates:
           *  Constant: '<S75>/Constant'
           *  Constant: '<S75>/Constant1'
           *  Sum: '<S75>/Add'
           */
          if (rtb_MultiportSwitch1 - rtb_MultiportSwitch >
              dzwcontrol3_0_P.B_Threshold) {
            tmp_p = dzwcontrol3_0_P.Constant_Value_h;
          } else {
            tmp_p = dzwcontrol3_0_P.Constant1_Value_i;
          }

          /* End of Switch: '<S75>/B' */

          /* Switch: '<S75>/C' incorporates:
           *  Constant: '<S75>/Constant'
           *  Constant: '<S75>/Constant1'
           *  Sum: '<S75>/Add1'
           */
          if ((0.0F - rtb_MultiportSwitch) - rtb_MultiportSwitch1 >
              dzwcontrol3_0_P.C_Threshold) {
            tmp_e = dzwcontrol3_0_P.Constant_Value_h;
          } else {
            tmp_e = dzwcontrol3_0_P.Constant1_Value_i;
          }

          /* End of Switch: '<S75>/C' */

          /* Sum: '<S75>/Add2' incorporates:
           *  Gain: '<S75>/Gain1'
           *  Gain: '<S75>/Gain2'
           *  Saturate: '<S75>/Saturation'
           */
          rtb_Saturation = ((((uint32_T)dzwcontrol3_0_P.Gain1_Gain_l * tmp_p) >>
                             1U) + ((uint32_T)rtb_MultiportSwitch1_a << 13U)) +
            (uint32_T)dzwcontrol3_0_P.Gain2_Gain_a * tmp_e;

          /* Saturate: '<S75>/Saturation' */
          if (rtb_Saturation > dzwcontrol3_0_P.Saturation_UpperSat) {
            rtb_Saturation = dzwcontrol3_0_P.Saturation_UpperSat;
          } else {
            if (rtb_Saturation < dzwcontrol3_0_P.Saturation_LowerSat_ov) {
              rtb_Saturation = dzwcontrol3_0_P.Saturation_LowerSat_ov;
            }
          }

          /* End of Saturate: '<S75>/Saturation' */

          /* MultiPortSwitch: '<S75>/Multiport Switch1' incorporates:
           *  Constant: '<S75>/Constant2'
           *  Constant: '<S75>/Constant3'
           *  Constant: '<S75>/Constant4'
           *  Constant: '<S75>/Constant5'
           *  Constant: '<S75>/Constant6'
           *  Constant: '<S75>/Constant7'
           *  Saturate: '<S75>/Saturation'
           */
          switch (rtb_Saturation >> 13U) {
           case 1:
            rtb_MultiportSwitch1_a = dzwcontrol3_0_P.Constant2_Value_m;
            break;

           case 2:
            rtb_MultiportSwitch1_a = dzwcontrol3_0_P.Constant3_Value_h;
            break;

           case 3:
            rtb_MultiportSwitch1_a = dzwcontrol3_0_P.Constant4_Value_d;
            break;

           case 4:
            rtb_MultiportSwitch1_a = dzwcontrol3_0_P.Constant5_Value;
            break;

           case 5:
            rtb_MultiportSwitch1_a = dzwcontrol3_0_P.Constant6_Value;
            break;

           default:
            rtb_MultiportSwitch1_a = dzwcontrol3_0_P.Constant7_Value;
            break;
          }

          /* End of MultiPortSwitch: '<S75>/Multiport Switch1' */

          /* MultiPortSwitch: '<S73>/TL' incorporates:
           *  Constant: '<S70>/Constant'
           *  Constant: '<S70>/Constant4'
           *  DataStoreRead: '<S9>/Data Store Read3'
           *  DataStoreRead: '<S9>/Data Store Read4'
           *  Fcn: '<S74>/Fcn'
           *  Fcn: '<S74>/Fcn1'
           *  Fcn: '<S74>/Fcn2'
           *  Gain: '<S73>/Gain'
           *  Gain: '<S73>/Gain1'
           *  Gain: '<S73>/Gain2'
           */
          switch (rtb_MultiportSwitch1_a) {
           case 1:
            rtb_Add1_l = (-1.73205078F * Ubeta + 3.0F * Ualpha) *
              dzwcontrol3_0_P.Constant_Value_i / (2.0F * dzwcontrol3_0_P.Udc);

            /* MultiPortSwitch: '<S73>/TH' incorporates:
             *  Constant: '<S70>/Constant'
             *  Constant: '<S70>/Constant4'
             *  DataStoreRead: '<S9>/Data Store Read3'
             *  DataStoreRead: '<S9>/Data Store Read4'
             *  Fcn: '<S74>/Fcn'
             *  Fcn: '<S74>/Fcn1'
             */
            rtb_Product_g = 1.73205078F * dzwcontrol3_0_P.Constant_Value_i *
              Ubeta / dzwcontrol3_0_P.Udc;
            break;

           case 2:
            rtb_Add1_l = (-1.73205078F * Ubeta + 3.0F * Ualpha) *
              dzwcontrol3_0_P.Constant_Value_i / (2.0F * dzwcontrol3_0_P.Udc) *
              dzwcontrol3_0_P.Gain_Gain_a;

            /* MultiPortSwitch: '<S73>/TH' incorporates:
             *  Constant: '<S70>/Constant'
             *  Constant: '<S70>/Constant4'
             *  DataStoreRead: '<S9>/Data Store Read3'
             *  DataStoreRead: '<S9>/Data Store Read4'
             *  Fcn: '<S74>/Fcn1'
             *  Fcn: '<S74>/Fcn2'
             *  Gain: '<S73>/Gain'
             *  Gain: '<S73>/Gain1'
             */
            rtb_Product_g = (-1.73205078F * Ubeta - 3.0F * Ualpha) *
              dzwcontrol3_0_P.Constant_Value_i / (2.0F * dzwcontrol3_0_P.Udc) *
              dzwcontrol3_0_P.Gain1_Gain_j;
            break;

           case 3:
            rtb_Add1_l = 1.73205078F * dzwcontrol3_0_P.Constant_Value_i * Ubeta /
              dzwcontrol3_0_P.Udc;

            /* MultiPortSwitch: '<S73>/TH' incorporates:
             *  Constant: '<S70>/Constant'
             *  Constant: '<S70>/Constant4'
             *  DataStoreRead: '<S9>/Data Store Read3'
             *  DataStoreRead: '<S9>/Data Store Read4'
             *  Fcn: '<S74>/Fcn'
             *  Fcn: '<S74>/Fcn2'
             */
            rtb_Product_g = (-1.73205078F * Ubeta - 3.0F * Ualpha) *
              dzwcontrol3_0_P.Constant_Value_i / (2.0F * dzwcontrol3_0_P.Udc);
            break;

           case 4:
            rtb_Add1_l = 1.73205078F * dzwcontrol3_0_P.Constant_Value_i * Ubeta /
              dzwcontrol3_0_P.Udc * dzwcontrol3_0_P.Gain2_Gain_n;

            /* MultiPortSwitch: '<S73>/TH' incorporates:
             *  Constant: '<S70>/Constant'
             *  Constant: '<S70>/Constant4'
             *  DataStoreRead: '<S9>/Data Store Read3'
             *  DataStoreRead: '<S9>/Data Store Read4'
             *  Fcn: '<S74>/Fcn'
             *  Fcn: '<S74>/Fcn1'
             *  Gain: '<S73>/Gain'
             *  Gain: '<S73>/Gain2'
             */
            rtb_Product_g = (-1.73205078F * Ubeta + 3.0F * Ualpha) *
              dzwcontrol3_0_P.Constant_Value_i / (2.0F * dzwcontrol3_0_P.Udc) *
              dzwcontrol3_0_P.Gain_Gain_a;
            break;

           case 5:
            rtb_Add1_l = (-1.73205078F * Ubeta - 3.0F * Ualpha) *
              dzwcontrol3_0_P.Constant_Value_i / (2.0F * dzwcontrol3_0_P.Udc);

            /* MultiPortSwitch: '<S73>/TH' incorporates:
             *  Constant: '<S70>/Constant'
             *  Constant: '<S70>/Constant4'
             *  DataStoreRead: '<S9>/Data Store Read3'
             *  DataStoreRead: '<S9>/Data Store Read4'
             *  Fcn: '<S74>/Fcn1'
             *  Fcn: '<S74>/Fcn2'
             */
            rtb_Product_g = (-1.73205078F * Ubeta + 3.0F * Ualpha) *
              dzwcontrol3_0_P.Constant_Value_i / (2.0F * dzwcontrol3_0_P.Udc);
            break;

           default:
            rtb_Add1_l = (-1.73205078F * Ubeta - 3.0F * Ualpha) *
              dzwcontrol3_0_P.Constant_Value_i / (2.0F * dzwcontrol3_0_P.Udc) *
              dzwcontrol3_0_P.Gain1_Gain_j;

            /* MultiPortSwitch: '<S73>/TH' incorporates:
             *  Constant: '<S70>/Constant'
             *  Constant: '<S70>/Constant4'
             *  DataStoreRead: '<S9>/Data Store Read3'
             *  DataStoreRead: '<S9>/Data Store Read4'
             *  Fcn: '<S74>/Fcn'
             *  Fcn: '<S74>/Fcn2'
             *  Gain: '<S73>/Gain1'
             *  Gain: '<S73>/Gain2'
             */
            rtb_Product_g = 1.73205078F * dzwcontrol3_0_P.Constant_Value_i *
              Ubeta / dzwcontrol3_0_P.Udc * dzwcontrol3_0_P.Gain2_Gain_n;
            break;
          }

          /* End of MultiPortSwitch: '<S73>/TL' */

          /* MultiPortSwitch: '<S71>/Multiport Switch' incorporates:
           *  Constant: '<S70>/Constant'
           *  Fcn: '<S73>/Fcn3'
           */
          rtb_MultiportSwitch = (dzwcontrol3_0_P.Constant_Value_i - rtb_Add1_l)
            - rtb_Product_g;

          /* Switch: '<S73>/Switch3' */
          if (rtb_MultiportSwitch > dzwcontrol3_0_P.Switch3_Threshold) {
            /* MultiPortSwitch: '<S71>/Multiport Switch' incorporates:
             *  Constant: '<S73>/Constant2'
             */
            rtb_MultiportSwitch = dzwcontrol3_0_P.Constant2_Value_b;
          } else {
            /* MultiPortSwitch: '<S71>/Multiport Switch' incorporates:
             *  Constant: '<S73>/Constant3'
             */
            rtb_MultiportSwitch = dzwcontrol3_0_P.Constant3_Value_m;
          }

          /* End of Switch: '<S73>/Switch3' */

          /* Switch: '<S73>/Switch4' */
          if (rtb_MultiportSwitch > dzwcontrol3_0_P.Switch4_Threshold) {
            /* MultiPortSwitch: '<S71>/Multiport Switch1' */
            rtb_MultiportSwitch1 = rtb_Add1_l;
          } else {
            /* MultiPortSwitch: '<S71>/Multiport Switch1' incorporates:
             *  Constant: '<S70>/Constant'
             *  Fcn: '<S73>/Fcn4'
             */
            rtb_MultiportSwitch1 = rtb_Add1_l * dzwcontrol3_0_P.Constant_Value_i
              / (rtb_Add1_l + rtb_Product_g);
          }

          /* End of Switch: '<S73>/Switch4' */

          /* Switch: '<S73>/Switch5' */
          if (rtb_MultiportSwitch > dzwcontrol3_0_P.Switch5_Threshold) {
            /* MultiPortSwitch: '<S71>/Multiport Switch' */
            rtb_MultiportSwitch = rtb_Product_g;
          } else {
            /* MultiPortSwitch: '<S71>/Multiport Switch' incorporates:
             *  Constant: '<S70>/Constant'
             *  Fcn: '<S73>/Fcn5'
             */
            rtb_MultiportSwitch = rtb_Product_g *
              dzwcontrol3_0_P.Constant_Value_i / (rtb_Add1_l + rtb_Product_g);
          }

          /* End of Switch: '<S73>/Switch5' */

          /* Gain: '<S72>/Gain2' incorporates:
           *  Constant: '<S70>/Constant'
           *  Sum: '<S72>/Add'
           */
          rtb_Add1_l = ((dzwcontrol3_0_P.Constant_Value_i - rtb_MultiportSwitch1)
                        - rtb_MultiportSwitch) * dzwcontrol3_0_P.Gain2_Gain_d;

          /* Sum: '<S72>/Add1' incorporates:
           *  Gain: '<S72>/Gain'
           */
          rtb_MultiportSwitch2 = dzwcontrol3_0_P.Gain_Gain_l *
            rtb_MultiportSwitch1 + rtb_Add1_l;

          /* Sum: '<S72>/Add2' incorporates:
           *  Gain: '<S72>/Gain1'
           */
          rtb_Product_g = dzwcontrol3_0_P.Gain1_Gain_jd * rtb_MultiportSwitch +
            rtb_MultiportSwitch2;

          /* MultiPortSwitch: '<S71>/Multiport Switch' */
          switch (rtb_MultiportSwitch1_a) {
           case 1:
            /* MultiPortSwitch: '<S71>/Multiport Switch' */
            rtb_MultiportSwitch = rtb_Add1_l;
            break;

           case 2:
            /* MultiPortSwitch: '<S71>/Multiport Switch' */
            rtb_MultiportSwitch = rtb_MultiportSwitch2;
            break;

           case 3:
            /* MultiPortSwitch: '<S71>/Multiport Switch' */
            rtb_MultiportSwitch = rtb_Product_g;
            break;

           case 4:
            /* MultiPortSwitch: '<S71>/Multiport Switch' */
            rtb_MultiportSwitch = rtb_Product_g;
            break;

           case 5:
            /* MultiPortSwitch: '<S71>/Multiport Switch' */
            rtb_MultiportSwitch = rtb_MultiportSwitch2;
            break;

           default:
            /* MultiPortSwitch: '<S71>/Multiport Switch' */
            rtb_MultiportSwitch = rtb_Add1_l;
            break;
          }

          /* End of MultiPortSwitch: '<S71>/Multiport Switch' */

          /* DataStoreWrite: '<S9>/Data Store Write' */
          T1 = rtb_MultiportSwitch;

          /* MultiPortSwitch: '<S71>/Multiport Switch1' */
          switch (rtb_MultiportSwitch1_a) {
           case 1:
            /* MultiPortSwitch: '<S71>/Multiport Switch1' */
            rtb_MultiportSwitch1 = rtb_MultiportSwitch2;
            break;

           case 2:
            /* MultiPortSwitch: '<S71>/Multiport Switch1' */
            rtb_MultiportSwitch1 = rtb_Add1_l;
            break;

           case 3:
            /* MultiPortSwitch: '<S71>/Multiport Switch1' */
            rtb_MultiportSwitch1 = rtb_Add1_l;
            break;

           case 4:
            /* MultiPortSwitch: '<S71>/Multiport Switch1' */
            rtb_MultiportSwitch1 = rtb_MultiportSwitch2;
            break;

           case 5:
            /* MultiPortSwitch: '<S71>/Multiport Switch1' */
            rtb_MultiportSwitch1 = rtb_Product_g;
            break;

           default:
            /* MultiPortSwitch: '<S71>/Multiport Switch1' */
            rtb_MultiportSwitch1 = rtb_Product_g;
            break;
          }

          /* End of MultiPortSwitch: '<S71>/Multiport Switch1' */

          /* DataStoreWrite: '<S9>/Data Store Write1' */
          T2 = rtb_MultiportSwitch1;

          /* MultiPortSwitch: '<S71>/Multiport Switch2' */
          switch (rtb_MultiportSwitch1_a) {
           case 1:
            /* Sum: '<S72>/Add1' incorporates:
             *  MultiPortSwitch: '<S71>/Multiport Switch2'
             */
            rtb_MultiportSwitch2 = rtb_Product_g;
            break;

           case 2:
            /* Sum: '<S72>/Add1' incorporates:
             *  MultiPortSwitch: '<S71>/Multiport Switch2'
             */
            rtb_MultiportSwitch2 = rtb_Product_g;
            break;

           case 3:
            break;

           case 4:
            /* Sum: '<S72>/Add1' incorporates:
             *  MultiPortSwitch: '<S71>/Multiport Switch2'
             */
            rtb_MultiportSwitch2 = rtb_Add1_l;
            break;

           case 5:
            /* Sum: '<S72>/Add1' incorporates:
             *  MultiPortSwitch: '<S71>/Multiport Switch2'
             */
            rtb_MultiportSwitch2 = rtb_Add1_l;
            break;
          }

          /* End of MultiPortSwitch: '<S71>/Multiport Switch2' */

          /* DataStoreWrite: '<S9>/Data Store Write2' */
          T3 = rtb_MultiportSwitch2;

          /* MATLAB Function: '<S9>/MATLAB Function1' incorporates:
           *  DataStoreRead: '<S9>/Data Store Read'
           */
          if (STOP == 0.0) {
            rtb_SFA = 0U;
            rtb_SFB = 0U;
          } else {
            rtb_SFA = 1U;
            rtb_SFB = 2U;
          }

          /* End of MATLAB Function: '<S9>/MATLAB Function1' */

          /* S-Function (c2802xpwm): '<S9>/D' */

          /*-- Update CMPA value for ePWM4 --*/
          {
            EPwm4Regs.CMPA.bit.CMPA = (uint16_T)(rtb_MultiportSwitch);
          }

          EPwm4Regs.AQCSFRC.bit.CSFA = rtb_SFA;
          EPwm4Regs.AQCSFRC.bit.CSFB = rtb_SFB;

          /* S-Function (c2802xpwm): '<S9>/E' */

          /*-- Update CMPA value for ePWM5 --*/
          {
            EPwm5Regs.CMPA.bit.CMPA = (uint16_T)(rtb_MultiportSwitch1);
          }

          EPwm5Regs.AQCSFRC.bit.CSFA = rtb_SFA;
          EPwm5Regs.AQCSFRC.bit.CSFB = rtb_SFB;

          /* S-Function (c2802xpwm): '<S9>/F' */

          /*-- Update CMPA value for ePWM6 --*/
          {
            EPwm6Regs.CMPA.bit.CMPA = (uint16_T)(rtb_MultiportSwitch2);
          }

          EPwm6Regs.AQCSFRC.bit.CSFA = rtb_SFA;
          EPwm6Regs.AQCSFRC.bit.CSFB = rtb_SFB;
        } else if (dzwcontrol3_0_DW.count > dzwcontrol3_0_P.Constant2_Value_a /
                   2.0F) {
          /* Outputs for Function Call SubSystem: '<S1>/offset mode' */
          /* Gain: '<S10>/Gain1' incorporates:
           *  Gain: '<S10>/Gain12'
           *  Gain: '<S10>/Gain2'
           *  Gain: '<S10>/Gain4'
           *  Gain: '<S10>/Gain5'
           */
          rtb_Square = 6.2831853071795862 * dzwcontrol3_0_P.sample * 200.0;

          /* Sum: '<S10>/Add1' incorporates:
           *  DataStoreRead: '<S10>/Data Store Read2'
           *  Gain: '<S10>/Gain1'
           *  UnitDelay: '<S10>/Unit Delay1'
           */
          rtb_Add1 = rtb_Square * (real_T)E_Data +
            dzwcontrol3_0_DW.UnitDelay1_DSTATE;

          /* DataTypeConversion: '<S10>/Data Type Conversion4' incorporates:
           *  DataStoreWrite: '<S10>/Data Store Write1'
           */
          tmp = floor(rtb_Add1);
          if (rtIsNaN(tmp) || rtIsInf(tmp)) {
            tmp = 0.0;
          } else {
            tmp = fmod(tmp, 65536.0);
          }

          E_offset = tmp < 0.0 ? (uint16_T)-(int16_T)(uint16_T)-tmp : (uint16_T)
            tmp;

          /* End of DataTypeConversion: '<S10>/Data Type Conversion4' */

          /* Sum: '<S10>/Add2' incorporates:
           *  DataStoreRead: '<S10>/Data Store Read3'
           *  Gain: '<S10>/Gain4'
           *  UnitDelay: '<S10>/Unit Delay2'
           */
          rtb_Add2 = rtb_Square * Bus_Data + dzwcontrol3_0_DW.UnitDelay2_DSTATE;

          /* DataTypeConversion: '<S10>/Data Type Conversion1' incorporates:
           *  DataStoreWrite: '<S10>/Data Store Write3'
           */
          tmp = floor(rtb_Add2);
          if (rtIsNaN(tmp) || rtIsInf(tmp)) {
            tmp = 0.0;
          } else {
            tmp = fmod(tmp, 65536.0);
          }

          Bus_offset = tmp < 0.0 ? (uint16_T)-(int16_T)(uint16_T)-tmp :
            (uint16_T)tmp;

          /* End of DataTypeConversion: '<S10>/Data Type Conversion1' */

          /* Sum: '<S10>/Add3' incorporates:
           *  DataStoreRead: '<S10>/Data Store Read'
           *  Gain: '<S10>/Gain5'
           *  UnitDelay: '<S10>/Unit Delay3'
           */
          rtb_Add3 = rtb_Square * (real_T)F_Data +
            dzwcontrol3_0_DW.UnitDelay3_DSTATE;

          /* DataTypeConversion: '<S10>/Data Type Conversion3' incorporates:
           *  DataStoreWrite: '<S10>/Data Store Write2'
           */
          tmp = floor(rtb_Add3);
          if (rtIsNaN(tmp) || rtIsInf(tmp)) {
            tmp = 0.0;
          } else {
            tmp = fmod(tmp, 65536.0);
          }

          F_offset = tmp < 0.0 ? (uint16_T)-(int16_T)(uint16_T)-tmp : (uint16_T)
            tmp;

          /* End of DataTypeConversion: '<S10>/Data Type Conversion3' */

          /* Sum: '<S10>/Add6' incorporates:
           *  DataStoreRead: '<S10>/Data Store Read1'
           *  Gain: '<S10>/Gain12'
           *  UnitDelay: '<S10>/Unit Delay6'
           */
          rtb_Add6 = rtb_Square * (real_T)D_Data +
            dzwcontrol3_0_DW.UnitDelay6_DSTATE;

          /* DataTypeConversion: '<S10>/Data Type Conversion5' incorporates:
           *  DataStoreWrite: '<S10>/Data Store Write'
           */
          tmp = floor(rtb_Add6);
          if (rtIsNaN(tmp) || rtIsInf(tmp)) {
            tmp = 0.0;
          } else {
            tmp = fmod(tmp, 65536.0);
          }

          D_offset = tmp < 0.0 ? (uint16_T)-(int16_T)(uint16_T)-tmp : (uint16_T)
            tmp;

          /* End of DataTypeConversion: '<S10>/Data Type Conversion5' */

          /* DataStoreWrite: '<S10>/Data Store Write4' incorporates:
           *  Constant: '<S10>/Constant'
           */
          A = dzwcontrol3_0_P.Constant_Value_l;

          /* Update for UnitDelay: '<S10>/Unit Delay1' incorporates:
           *  Gain: '<S10>/Gain2'
           */
          dzwcontrol3_0_DW.UnitDelay1_DSTATE = (1.0 - rtb_Square) * rtb_Add1;

          /* Update for UnitDelay: '<S10>/Unit Delay2' incorporates:
           *  Gain: '<S10>/Gain6'
           */
          dzwcontrol3_0_DW.UnitDelay2_DSTATE = (1.0 - 6.2831853071795862 *
            dzwcontrol3_0_P.sample * 200.0) * rtb_Add2;

          /* Update for UnitDelay: '<S10>/Unit Delay3' incorporates:
           *  Gain: '<S10>/Gain7'
           */
          dzwcontrol3_0_DW.UnitDelay3_DSTATE = (1.0 - 6.2831853071795862 *
            dzwcontrol3_0_P.sample * 200.0) * rtb_Add3;

          /* Update for UnitDelay: '<S10>/Unit Delay6' incorporates:
           *  Gain: '<S10>/Gain3'
           */
          dzwcontrol3_0_DW.UnitDelay6_DSTATE = (1.0 - 6.2831853071795862 *
            dzwcontrol3_0_P.sample * 200.0) * rtb_Add6;

          /* End of Outputs for SubSystem: '<S1>/offset mode' */
        } else {
          /* Outputs for Function Call SubSystem: '<S1>/pwm=0' */
          /* DataStoreWrite: '<S11>/Data Store Write' incorporates:
           *  Constant: '<S11>/Constant'
           */
          A = dzwcontrol3_0_P.Constant_Value_m;

          /* End of Outputs for SubSystem: '<S1>/pwm=0' */
        }

        /* End of MATLAB Function: '<S1>/MATLAB Function2' */

        /* S-Function (c2802xadc): '<S1>/ADC4' */
        {
          /*  Internal Reference Voltage : Fixed scale 0 to 3.3 V range.  */
          /*  External Reference Voltage : Allowable ranges of VREFHI(ADCINA0) = 3.3 and VREFLO(tied to ground) = 0  */
          dzwcontrol3_0_B.ADC4 = (AdcdResultRegs.ADCRESULT4);
        }

        /* Outputs for Atomic SubSystem: '<S1>/1-phase LPF2' */
        /* Product: '<S4>/Divide1' incorporates:
         *  Constant: '<S1>/Constant'
         *  Constant: '<S1>/Constant1'
         *  Constant: '<S4>/Constant'
         *  Product: '<S4>/Divide'
         */
        rtb_Square = dzwcontrol3_0_P.Constant_Value /
          (dzwcontrol3_0_P.Constant1_Value_f1 * dzwcontrol3_0_P.Constant_Value_c);

        /* Sum: '<S4>/Denominator' incorporates:
         *  Constant: '<S4>/Constant1'
         */
        rtb_Add1 = rtb_Square + dzwcontrol3_0_P.Constant1_Value;

        /* Sum: '<S4>/Plus2' incorporates:
         *  Constant: '<S4>/Constant1'
         */
        rtb_Square = dzwcontrol3_0_P.Constant1_Value - rtb_Square;

        /* Product: '<S4>/Divide3' incorporates:
         *  DataStoreWrite: '<S1>/Data Store Write4'
         *  DataTypeConversion: '<S1>/Data Type Conversion'
         *  Product: '<S4>/Divide2'
         *  Sum: '<S4>/Plus'
         *  UnitDelay: '<S4>/Unit Delay'
         *  UnitDelay: '<S4>/Unit Delay1'
         */
        Bus_Data = (real32_T)((((real_T)dzwcontrol3_0_B.ADC4 +
          dzwcontrol3_0_DW.UnitDelay_DSTATE) - rtb_Square *
          dzwcontrol3_0_DW.UnitDelay1_DSTATE_k) / rtb_Add1);

        /* Update for UnitDelay: '<S4>/Unit Delay1' incorporates:
         *  DataStoreWrite: '<S1>/Data Store Write4'
         */
        dzwcontrol3_0_DW.UnitDelay1_DSTATE_k = Bus_Data;

        /* Update for UnitDelay: '<S4>/Unit Delay' incorporates:
         *  DataTypeConversion: '<S1>/Data Type Conversion'
         */
        dzwcontrol3_0_DW.UnitDelay_DSTATE = dzwcontrol3_0_B.ADC4;

        /* End of Outputs for SubSystem: '<S1>/1-phase LPF2' */

        /* S-Function (c2802xadc): '<S1>/ADC' */
        {
          /*  Internal Reference Voltage : Fixed scale 0 to 3.3 V range.  */
          /*  External Reference Voltage : Allowable ranges of VREFHI(ADCINA0) = 3.3 and VREFLO(tied to ground) = 0  */
          dzwcontrol3_0_B.ADC = (AdccResultRegs.ADCRESULT1);
        }

        /* DataStoreWrite: '<S1>/Data Store Write' */
        D_Data = dzwcontrol3_0_B.ADC;

        /* S-Function (c2802xadc): '<S1>/ADC1' */
        {
          /*  Internal Reference Voltage : Fixed scale 0 to 3.3 V range.  */
          /*  External Reference Voltage : Allowable ranges of VREFHI(ADCINA0) = 3.3 and VREFLO(tied to ground) = 0  */
          dzwcontrol3_0_B.ADC1 = (AdcaResultRegs.ADCRESULT2);
        }

        /* DataStoreWrite: '<S1>/Data Store Write1' */
        E_Data = dzwcontrol3_0_B.ADC1;

        /* S-Function (c2802xadc): '<S1>/ADC2' */
        {
          /*  Internal Reference Voltage : Fixed scale 0 to 3.3 V range.  */
          /*  External Reference Voltage : Allowable ranges of VREFHI(ADCINA0) = 3.3 and VREFLO(tied to ground) = 0  */
          dzwcontrol3_0_B.ADC2 = (AdcbResultRegs.ADCRESULT3);
        }

        /* DataStoreWrite: '<S1>/Data Store Write2' */
        F_Data = dzwcontrol3_0_B.ADC2;

        /* S-Function (c2802xadc): '<S1>/ADC3' */
        {
          /*  Internal Reference Voltage : Fixed scale 0 to 3.3 V range.  */
          /*  External Reference Voltage : Allowable ranges of VREFHI(ADCINA0) = 3.3 and VREFLO(tied to ground) = 0  */
          dzwcontrol3_0_B.ADC3 = (AdcaResultRegs.ADCRESULT0);
        }

        /* DataStoreWrite: '<S1>/Data Store Write3' */
        A_Data = dzwcontrol3_0_B.ADC3;

        /* S-Function (c2802xadc): '<S1>/ADC5' */
        {
          /*  Internal Reference Voltage : Fixed scale 0 to 3.3 V range.  */
          /*  External Reference Voltage : Allowable ranges of VREFHI(ADCINA0) = 3.3 and VREFLO(tied to ground) = 0  */
          dzwcontrol3_0_B.ADC5 = (AdccResultRegs.ADCRESULT4);
        }

        /* DataStoreWrite: '<S1>/Data Store Write5' */
        D_V_Data = dzwcontrol3_0_B.ADC5;

        /* S-Function (c2802xadc): '<S1>/ADC6' */
        {
          /*  Internal Reference Voltage : Fixed scale 0 to 3.3 V range.  */
          /*  External Reference Voltage : Allowable ranges of VREFHI(ADCINA0) = 3.3 and VREFLO(tied to ground) = 0  */
          dzwcontrol3_0_B.ADC6 = (AdcaResultRegs.ADCRESULT4);
        }

        /* DataStoreWrite: '<S1>/Data Store Write6' */
        E_V_Data = dzwcontrol3_0_B.ADC6;

        /* S-Function (c2802xadc): '<S1>/ADC7' */
        {
          /*  Internal Reference Voltage : Fixed scale 0 to 3.3 V range.  */
          /*  External Reference Voltage : Allowable ranges of VREFHI(ADCINA0) = 3.3 and VREFLO(tied to ground) = 0  */
          dzwcontrol3_0_B.ADC7 = (AdcbResultRegs.ADCRESULT4);
        }

        /* DataStoreWrite: '<S1>/Data Store Write7' */
        F_V_Data = dzwcontrol3_0_B.ADC7;
      }

      /* End of Outputs for S-Function (c28xisr_c2000): '<Root>/C28x Hardware Interrupt' */
    }
  }
}

/* Idle Task Block: '<Root>/Idle Task' */
void idle_num1_task_fcn(void)
{
  /* Call the system: <Root>/Function-Call Subsystem */
  {
  }
}

/*
 * System initialize for enable system:
 *    '<S53>/Subsystem - pi//2 delay'
 *    '<S35>/Subsystem - pi//2 delay'
 *    '<S18>/Subsystem - pi//2 delay'
 */
void dzwcontr_Subsystempi2delay_Init(real32_T *rty_dq, real32_T *rty_dq_h,
  P_Subsystempi2delay_dzwcontro_T *localP)
{
  /* SystemInitialize for Outport: '<S58>/dq' */
  *rty_dq = localP->dq_Y0[0];
  *rty_dq_h = localP->dq_Y0[1];
}

/*
 * Output and update for enable system:
 *    '<S53>/Subsystem - pi//2 delay'
 *    '<S35>/Subsystem - pi//2 delay'
 *    '<S18>/Subsystem - pi//2 delay'
 */
void dzwcontrol3_0_Subsystempi2delay(uint16_T rtu_Enable, real32_T
  rtu_alpha_beta, real32_T rtu_alpha_beta_p, real32_T rtu_wt, real32_T *rty_dq,
  real32_T *rty_dq_h)
{
  real32_T tmp;
  real32_T tmp_0;

  /* Outputs for Enabled SubSystem: '<S53>/Subsystem - pi//2 delay' incorporates:
   *  EnablePort: '<S58>/Enable'
   */
  if (rtu_Enable > 0U) {
    /* Fcn: '<S58>/Fcn' incorporates:
     *  Fcn: '<S58>/Fcn1'
     */
    tmp = (real32_T)cos(rtu_wt);
    tmp_0 = (real32_T)sin(rtu_wt);
    *rty_dq = rtu_alpha_beta * tmp_0 - rtu_alpha_beta_p * tmp;

    /* Fcn: '<S58>/Fcn1' */
    *rty_dq_h = rtu_alpha_beta * tmp + rtu_alpha_beta_p * tmp_0;
  }

  /* End of Outputs for SubSystem: '<S53>/Subsystem - pi//2 delay' */
}

/*
 * System initialize for enable system:
 *    '<S53>/Subsystem1'
 *    '<S35>/Subsystem1'
 *    '<S18>/Subsystem1'
 */
void dzwcontrol3_0_Subsystem1_Init(real32_T *rty_dq, real32_T *rty_dq_m,
  P_Subsystem1_dzwcontrol3_0_T *localP)
{
  /* SystemInitialize for Outport: '<S59>/dq' */
  *rty_dq = localP->dq_Y0[0];
  *rty_dq_m = localP->dq_Y0[1];
}

/*
 * Output and update for enable system:
 *    '<S53>/Subsystem1'
 *    '<S35>/Subsystem1'
 *    '<S18>/Subsystem1'
 */
void dzwcontrol3_0_Subsystem1(uint16_T rtu_Enable, real32_T rtu_alpha_beta,
  real32_T rtu_alpha_beta_o, real32_T rtu_wt, real32_T *rty_dq, real32_T
  *rty_dq_m)
{
  real32_T tmp;
  real32_T tmp_0;

  /* Outputs for Enabled SubSystem: '<S53>/Subsystem1' incorporates:
   *  EnablePort: '<S59>/Enable'
   */
  if (rtu_Enable > 0U) {
    /* Fcn: '<S59>/Fcn' incorporates:
     *  Fcn: '<S59>/Fcn1'
     */
    tmp = (real32_T)sin(rtu_wt);
    tmp_0 = (real32_T)cos(rtu_wt);
    *rty_dq = rtu_alpha_beta * tmp_0 + rtu_alpha_beta_o * tmp;

    /* Fcn: '<S59>/Fcn1' */
    *rty_dq_m = -rtu_alpha_beta * tmp + rtu_alpha_beta_o * tmp_0;
  }

  /* End of Outputs for SubSystem: '<S53>/Subsystem1' */
}

/*
 * Output and update for atomic system:
 *    '<S60>/Embedded MATLAB Function'
 *    '<S44>/Embedded MATLAB Function'
 */
void dzwcontr_EmbeddedMATLABFunction(int32_T *rty_y)
{
  *rty_y = 5368709L;
}

/*
 * System initialize for enable system:
 *    '<S55>/Subsystem - pi//2 delay'
 *    '<S39>/Subsystem - pi//2 delay'
 *    '<S23>/Subsystem - pi//2 delay'
 */
void dzwcon_Subsystempi2delay_e_Init(real32_T *rty_alpha_beta, real32_T
  *rty_alpha_beta_a, P_Subsystempi2delay_dzwcont_o_T *localP)
{
  /* SystemInitialize for Outport: '<S67>/alpha_beta' */
  *rty_alpha_beta = localP->alpha_beta_Y0[0];
  *rty_alpha_beta_a = localP->alpha_beta_Y0[1];
}

/*
 * Output and update for enable system:
 *    '<S55>/Subsystem - pi//2 delay'
 *    '<S39>/Subsystem - pi//2 delay'
 *    '<S23>/Subsystem - pi//2 delay'
 */
void dzwcontrol3_Subsystempi2delay_l(uint16_T rtu_Enable, real32_T rtu_dq,
  real32_T rtu_dq_g, real32_T rtu_wt, real32_T *rty_alpha_beta, real32_T
  *rty_alpha_beta_a)
{
  real32_T tmp;
  real32_T tmp_0;

  /* Outputs for Enabled SubSystem: '<S55>/Subsystem - pi//2 delay' incorporates:
   *  EnablePort: '<S67>/Enable'
   */
  if (rtu_Enable > 0U) {
    /* Fcn: '<S67>/Fcn' incorporates:
     *  Fcn: '<S67>/Fcn1'
     */
    tmp = (real32_T)cos(rtu_wt);
    tmp_0 = (real32_T)sin(rtu_wt);
    *rty_alpha_beta = rtu_dq * tmp_0 + rtu_dq_g * tmp;

    /* Fcn: '<S67>/Fcn1' */
    *rty_alpha_beta_a = -rtu_dq * tmp + rtu_dq_g * tmp_0;
  }

  /* End of Outputs for SubSystem: '<S55>/Subsystem - pi//2 delay' */
}

/*
 * System initialize for enable system:
 *    '<S55>/Subsystem1'
 *    '<S39>/Subsystem1'
 *    '<S23>/Subsystem1'
 */
void dzwcontrol3_0_Subsystem1_c_Init(real32_T *rty_alpha_beta, real32_T
  *rty_alpha_beta_j, P_Subsystem1_dzwcontrol3_0_e_T *localP)
{
  /* SystemInitialize for Outport: '<S68>/alpha_beta' */
  *rty_alpha_beta = localP->alpha_beta_Y0[0];
  *rty_alpha_beta_j = localP->alpha_beta_Y0[1];
}

/*
 * Output and update for enable system:
 *    '<S55>/Subsystem1'
 *    '<S39>/Subsystem1'
 *    '<S23>/Subsystem1'
 */
void dzwcontrol3_0_Subsystem1_l(uint16_T rtu_Enable, real32_T rtu_dq, real32_T
  rtu_dq_f, real32_T rtu_wt, real32_T *rty_alpha_beta, real32_T
  *rty_alpha_beta_j)
{
  real32_T tmp;
  real32_T tmp_0;

  /* Outputs for Enabled SubSystem: '<S55>/Subsystem1' incorporates:
   *  EnablePort: '<S68>/Enable'
   */
  if (rtu_Enable > 0U) {
    /* Fcn: '<S68>/Fcn' incorporates:
     *  Fcn: '<S68>/Fcn1'
     */
    tmp = (real32_T)sin(rtu_wt);
    tmp_0 = (real32_T)cos(rtu_wt);
    *rty_alpha_beta = rtu_dq * tmp_0 - rtu_dq_f * tmp;

    /* Fcn: '<S68>/Fcn1' */
    *rty_alpha_beta_j = rtu_dq * tmp + rtu_dq_f * tmp_0;
  }

  /* End of Outputs for SubSystem: '<S55>/Subsystem1' */
}

real32_T rt_modf_snf(real32_T u0, real32_T u1)
{
  real32_T q;
  real32_T y;
  boolean_T yEq;
  y = u0;
  if (u1 == 0.0F) {
    if (u0 == 0.0F) {
      y = u1;
    }
  } else if (rtIsNaNF(u0) || rtIsNaNF(u1) || rtIsInfF(u0)) {
    y = (rtNaNF);
  } else if (u0 == 0.0F) {
    y = 0.0F / u1;
  } else if (rtIsInfF(u1)) {
    if ((u1 < 0.0F) != (u0 < 0.0F)) {
      y = u1;
    }
  } else {
    y = (real32_T)fmod(u0, u1);
    yEq = (y == 0.0F);
    if ((!yEq) && (u1 > (real32_T)floor(u1))) {
      q = fabsf(u0 / u1);
      yEq = !(fabsf(q - (real32_T)floor(q + 0.5F)) > FLT_EPSILON * q);
    }

    if (yEq) {
      y = u1 * 0.0F;
    } else {
      if ((u0 < 0.0F) != (u1 < 0.0F)) {
        y += u1;
      }
    }
  }

  return y;
}

/* Model step function */
void dzwcontrol3_0_step(void)
{
  /* (no output/update code required) */
}

/* Model initialize function */
void dzwcontrol3_0_initialize(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize error status */
  rtmSetErrorStatus(dzwcontrol3_0_M, (NULL));

  /* block I/O */
  (void) memset(((void *) &dzwcontrol3_0_B), 0,
                sizeof(B_dzwcontrol3_0_T));

  /* states (dwork) */
  (void) memset((void *)&dzwcontrol3_0_DW, 0,
                sizeof(DW_dzwcontrol3_0_T));

  /* exported global states */
  B = 0.0;
  dutycycle = 0.0;
  C = 0.0;
  A = 0.0;
  STOP = 0.0;
  RST = 0.0;
  tran_parameter = 0.0F;
  IE_ref = 0.0F;
  IntegralE = 0.0F;
  UE = 0.0F;
  PLL_rou = 0.0F;
  DC_Bus = 0.0F;
  Current_F = 0.0F;
  Current_E = 0.0F;
  Current_D = 0.0F;
  KpE = 0.0F;
  KiE = 0.0F;
  Current_alpha = 0.0F;
  Current_beta = 0.0F;
  VF_Frq = 0.0F;
  Theta = 0.0F;
  Idfbk = 0.0F;
  Iqfbk = 0.0F;
  Idref = 0.0F;
  Iqref = 0.0F;
  Integrald = 0.0F;
  Integralq = 0.0F;
  Uq = 0.0F;
  Ud = 0.0F;
  Ubeta = 0.0F;
  Ualpha = 0.0F;
  Uqref = 0.0F;
  Udref = 0.0F;
  T2 = 0.0F;
  T1 = 0.0F;
  T3 = 0.0F;
  threephase_Theta = 0.0F;
  threephase_Frq = 0.0F;
  Bus_Data = 0.0F;
  E_offset = 0U;
  F_offset = 0U;
  A_Data = 0U;
  Enable = 0U;
  ControlMode = 0U;
  Stop = 0U;
  D_Data = 0U;
  D_V_Data = 0U;
  E_V_Data = 0U;
  F_V_Data = 0U;
  E_Data = 0U;
  F_Data = 0U;
  Bus_offset = 0U;
  D_offset = 0U;

  /* Start for DataStoreMemory: '<Root>/Data Store Memory' */
  B = dzwcontrol3_0_P.DataStoreMemory_InitialValue;

  /* Start for DataStoreMemory: '<Root>/Data Store Memory14' */
  dutycycle = dzwcontrol3_0_P.DataStoreMemory14_InitialValue;

  /* Start for DataStoreMemory: '<Root>/Data Store Memory16' */
  tran_parameter = dzwcontrol3_0_P.DataStoreMemory16_InitialValue;

  /* Start for DataStoreMemory: '<Root>/Data Store Memory20' */
  IE_ref = dzwcontrol3_0_P.DataStoreMemory20_InitialValue;

  /* Start for DataStoreMemory: '<Root>/Data Store Memory26' */
  IntegralE = dzwcontrol3_0_P.DataStoreMemory26_InitialValue;

  /* Start for DataStoreMemory: '<Root>/Data Store Memory27' */
  UE = dzwcontrol3_0_P.DataStoreMemory27_InitialValue;

  /* Start for DataStoreMemory: '<Root>/Data Store Memory3' */
  C = dzwcontrol3_0_P.DataStoreMemory3_InitialValue;

  /* Start for DataStoreMemory: '<Root>/Data Store Memory52' */
  PLL_rou = dzwcontrol3_0_P.DataStoreMemory52_InitialValue;

  /* Start for DataStoreMemory: '<Root>/Data Store Memory1' */
  A = dzwcontrol3_0_P.DataStoreMemory1_InitialValue;

  /* Start for DataStoreMemory: '<Root>/Data Store Memory10' */
  E_offset = dzwcontrol3_0_P.DataStoreMemory10_InitialValue;

  /* Start for DataStoreMemory: '<Root>/Data Store Memory11' */
  F_offset = dzwcontrol3_0_P.DataStoreMemory11_InitialValue;

  /* Start for DataStoreMemory: '<Root>/Data Store Memory12' */
  A_Data = dzwcontrol3_0_P.DataStoreMemory12_InitialValue;

  /* Start for DataStoreMemory: '<Root>/Data Store Memory13' */
  STOP = dzwcontrol3_0_P.DataStoreMemory13_InitialValue;

  /* Start for DataStoreMemory: '<Root>/Data Store Memory15' */
  DC_Bus = dzwcontrol3_0_P.DataStoreMemory15_InitialValue;

  /* Start for DataStoreMemory: '<Root>/Data Store Memory17' */
  Current_F = dzwcontrol3_0_P.DataStoreMemory17_InitialValue;

  /* Start for DataStoreMemory: '<Root>/Data Store Memory18' */
  Current_E = dzwcontrol3_0_P.DataStoreMemory18_InitialValue;

  /* Start for DataStoreMemory: '<Root>/Data Store Memory19' */
  Current_D = dzwcontrol3_0_P.DataStoreMemory19_InitialValue;

  /* Start for DataStoreMemory: '<Root>/Data Store Memory2' */
  Enable = dzwcontrol3_0_P.DataStoreMemory2_InitialValue;

  /* Start for DataStoreMemory: '<Root>/Data Store Memory21' */
  ControlMode = dzwcontrol3_0_P.DataStoreMemory21_InitialValue;

  /* Start for DataStoreMemory: '<Root>/Data Store Memory22' */
  Stop = dzwcontrol3_0_P.DataStoreMemory22_InitialValue;

  /* Start for DataStoreMemory: '<Root>/Data Store Memory24' */
  KpE = dzwcontrol3_0_P.DataStoreMemory24_InitialValue;

  /* Start for DataStoreMemory: '<Root>/Data Store Memory25' */
  KiE = dzwcontrol3_0_P.DataStoreMemory25_InitialValue;

  /* Start for DataStoreMemory: '<Root>/Data Store Memory28' */
  Current_alpha = dzwcontrol3_0_P.DataStoreMemory28_InitialValue;

  /* Start for DataStoreMemory: '<Root>/Data Store Memory29' */
  Current_beta = dzwcontrol3_0_P.DataStoreMemory29_InitialValue;

  /* Start for DataStoreMemory: '<Root>/Data Store Memory30' */
  VF_Frq = dzwcontrol3_0_P.DataStoreMemory30_InitialValue;

  /* Start for DataStoreMemory: '<Root>/Data Store Memory31' */
  Theta = dzwcontrol3_0_P.DataStoreMemory31_InitialValue;

  /* Start for DataStoreMemory: '<Root>/Data Store Memory32' */
  Idfbk = dzwcontrol3_0_P.DataStoreMemory32_InitialValue;

  /* Start for DataStoreMemory: '<Root>/Data Store Memory33' */
  Iqfbk = dzwcontrol3_0_P.DataStoreMemory33_InitialValue;

  /* Start for DataStoreMemory: '<Root>/Data Store Memory34' */
  Idref = dzwcontrol3_0_P.DataStoreMemory34_InitialValue;

  /* Start for DataStoreMemory: '<Root>/Data Store Memory35' */
  Iqref = dzwcontrol3_0_P.DataStoreMemory35_InitialValue;

  /* Start for DataStoreMemory: '<Root>/Data Store Memory36' */
  Integrald = dzwcontrol3_0_P.DataStoreMemory36_InitialValue;

  /* Start for DataStoreMemory: '<Root>/Data Store Memory37' */
  Integralq = dzwcontrol3_0_P.DataStoreMemory37_InitialValue;

  /* Start for DataStoreMemory: '<Root>/Data Store Memory38' */
  Uq = dzwcontrol3_0_P.DataStoreMemory38_InitialValue;

  /* Start for DataStoreMemory: '<Root>/Data Store Memory39' */
  Ud = dzwcontrol3_0_P.DataStoreMemory39_InitialValue;

  /* Start for DataStoreMemory: '<Root>/Data Store Memory4' */
  D_Data = dzwcontrol3_0_P.DataStoreMemory4_InitialValue;

  /* Start for DataStoreMemory: '<Root>/Data Store Memory40' */
  Ubeta = dzwcontrol3_0_P.DataStoreMemory40_InitialValue;

  /* Start for DataStoreMemory: '<Root>/Data Store Memory41' */
  Ualpha = dzwcontrol3_0_P.DataStoreMemory41_InitialValue;

  /* Start for DataStoreMemory: '<Root>/Data Store Memory42' */
  Uqref = dzwcontrol3_0_P.DataStoreMemory42_InitialValue;

  /* Start for DataStoreMemory: '<Root>/Data Store Memory43' */
  Udref = dzwcontrol3_0_P.DataStoreMemory43_InitialValue;

  /* Start for DataStoreMemory: '<Root>/Data Store Memory44' */
  T2 = dzwcontrol3_0_P.DataStoreMemory44_InitialValue;

  /* Start for DataStoreMemory: '<Root>/Data Store Memory45' */
  T1 = dzwcontrol3_0_P.DataStoreMemory45_InitialValue;

  /* Start for DataStoreMemory: '<Root>/Data Store Memory46' */
  T3 = dzwcontrol3_0_P.DataStoreMemory46_InitialValue;

  /* Start for DataStoreMemory: '<Root>/Data Store Memory47' */
  D_V_Data = dzwcontrol3_0_P.DataStoreMemory47_InitialValue;

  /* Start for DataStoreMemory: '<Root>/Data Store Memory48' */
  E_V_Data = dzwcontrol3_0_P.DataStoreMemory48_InitialValue;

  /* Start for DataStoreMemory: '<Root>/Data Store Memory49' */
  F_V_Data = dzwcontrol3_0_P.DataStoreMemory49_InitialValue;

  /* Start for DataStoreMemory: '<Root>/Data Store Memory5' */
  E_Data = dzwcontrol3_0_P.DataStoreMemory5_InitialValue;

  /* Start for DataStoreMemory: '<Root>/Data Store Memory50' */
  threephase_Theta = dzwcontrol3_0_P.DataStoreMemory50_InitialValue;

  /* Start for DataStoreMemory: '<Root>/Data Store Memory51' */
  threephase_Frq = dzwcontrol3_0_P.DataStoreMemory51_InitialValue;

  /* Start for DataStoreMemory: '<Root>/Data Store Memory6' */
  F_Data = dzwcontrol3_0_P.DataStoreMemory6_InitialValue;

  /* Start for DataStoreMemory: '<Root>/Data Store Memory7' */
  Bus_offset = dzwcontrol3_0_P.DataStoreMemory7_InitialValue;

  /* Start for DataStoreMemory: '<Root>/Data Store Memory8' */
  Bus_Data = dzwcontrol3_0_P.DataStoreMemory8_InitialValue;

  /* Start for DataStoreMemory: '<Root>/Data Store Memory9' */
  D_offset = dzwcontrol3_0_P.DataStoreMemory9_InitialValue;

  /* Start for DataStoreMemory: '<Root>/Data Store Memory23' */
  RST = dzwcontrol3_0_P.DataStoreMemory23_InitialValue;

  /* SystemInitialize for S-Function (c28xisr_c2000): '<Root>/C28x Hardware Interrupt' incorporates:
   *  SubSystem: '<Root>/ADC interrupt'
   */

  /* System initialize for function-call system: '<Root>/ADC interrupt' */

  /* Start for S-Function (c2802xadc): '<S1>/ADC4' */
  if (MW_adcDInitFlag == 0) {
    InitAdcD();
    MW_adcDInitFlag = 1;
  }

  config_ADCD_SOC4 ();

  /* Start for S-Function (c2802xadc): '<S1>/ADC' */
  if (MW_adcCInitFlag == 0) {
    InitAdcC();
    MW_adcCInitFlag = 1;
  }

  config_ADCC_SOC1 ();

  /* Start for S-Function (c2802xadc): '<S1>/ADC1' */
  if (MW_adcAInitFlag == 0) {
    InitAdcA();
    MW_adcAInitFlag = 1;
  }

  config_ADCA_SOC2 ();

  /* Start for S-Function (c2802xadc): '<S1>/ADC2' */
  if (MW_adcBInitFlag == 0) {
    InitAdcB();
    MW_adcBInitFlag = 1;
  }

  config_ADCB_SOC3 ();

  /* Start for S-Function (c2802xadc): '<S1>/ADC3' */
  if (MW_adcAInitFlag == 0) {
    InitAdcA();
    MW_adcAInitFlag = 1;
  }

  config_ADCA_SOC0 ();

  /* Start for S-Function (c2802xadc): '<S1>/ADC5' */
  if (MW_adcCInitFlag == 0) {
    InitAdcC();
    MW_adcCInitFlag = 1;
  }

  config_ADCC_SOC4 ();

  /* Start for S-Function (c2802xadc): '<S1>/ADC6' */
  if (MW_adcAInitFlag == 0) {
    InitAdcA();
    MW_adcAInitFlag = 1;
  }

  config_ADCA_SOC4 ();

  /* Start for S-Function (c2802xadc): '<S1>/ADC7' */
  if (MW_adcBInitFlag == 0) {
    InitAdcB();
    MW_adcBInitFlag = 1;
  }

  config_ADCB_SOC4 ();
  dzwcontrol3_0_DW.count = 0.0;

  /* SystemInitialize for MATLAB Function: '<S1>/MATLAB Function2' incorporates:
   *  SubSystem: '<S1>/Mode control'
   */
  /* SystemInitialize for IfAction SubSystem: '<S8>/DC-bus control mode' */
  /* InitializeConditions for UnitDelay: '<S21>/Unit Delay1' */
  dzwcontrol3_0_DW.UnitDelay1_DSTATE_e =
    dzwcontrol3_0_P.UnitDelay1_InitialCondition_f;

  /* InitializeConditions for UnitDelay: '<S30>/Unit Delay1' */
  dzwcontrol3_0_DW.UnitDelay1_DSTATE_o =
    dzwcontrol3_0_P.UnitDelay1_InitialCondition_fb;

  /* InitializeConditions for Saturate: '<S30>/Saturation3' incorporates:
   *  UnitDelay: '<S30>/Unit Delay2'
   */
  dzwcontrol3_0_DW.UnitDelay2_DSTATE_c =
    dzwcontrol3_0_P.UnitDelay2_InitialCondition;

  /* InitializeConditions for UnitDelay: '<S28>/Unit Delay1' */
  dzwcontrol3_0_DW.UnitDelay1_DSTATE_j =
    dzwcontrol3_0_P.UnitDelay1_InitialCondition;

  /* InitializeConditions for UnitDelay: '<S28>/Unit Delay2' */
  dzwcontrol3_0_DW.UnitDelay2_DSTATE_k =
    dzwcontrol3_0_P.UnitDelay2_InitialCondition_j;

  /* SystemInitialize for Enabled SubSystem: '<S18>/Subsystem - pi//2 delay' */
  dzwcontr_Subsystempi2delay_Init(&dzwcontrol3_0_B.Fcn_f,
    &dzwcontrol3_0_B.Fcn1_o, &dzwcontrol3_0_P.Subsystempi2delay_m);

  /* End of SystemInitialize for SubSystem: '<S18>/Subsystem - pi//2 delay' */

  /* SystemInitialize for Enabled SubSystem: '<S18>/Subsystem1' */
  dzwcontrol3_0_Subsystem1_Init(&dzwcontrol3_0_B.Fcn_d, &dzwcontrol3_0_B.Fcn1_e,
    &dzwcontrol3_0_P.Subsystem1_c);

  /* End of SystemInitialize for SubSystem: '<S18>/Subsystem1' */

  /* SystemInitialize for Enabled SubSystem: '<S23>/Subsystem - pi//2 delay' */
  dzwcon_Subsystempi2delay_e_Init(&dzwcontrol3_0_B.Fcn_e,
    &dzwcontrol3_0_B.Fcn1_m, &dzwcontrol3_0_P.Subsystempi2delay_b);

  /* End of SystemInitialize for SubSystem: '<S23>/Subsystem - pi//2 delay' */

  /* SystemInitialize for Enabled SubSystem: '<S23>/Subsystem1' */
  dzwcontrol3_0_Subsystem1_c_Init(&dzwcontrol3_0_B.Fcn, &dzwcontrol3_0_B.Fcn1,
    &dzwcontrol3_0_P.Subsystem1_f);

  /* End of SystemInitialize for SubSystem: '<S23>/Subsystem1' */
  /* End of SystemInitialize for SubSystem: '<S8>/DC-bus control mode' */

  /* SystemInitialize for IfAction SubSystem: '<S8>/Three-phase current loop test' */
  /* InitializeConditions for Sum: '<S38>/Sum2' incorporates:
   *  UnitDelay: '<S38>/Unit Delay'
   */
  dzwcontrol3_0_DW.UnitDelay_DSTATE_o =
    dzwcontrol3_0_P.UnitDelay_InitialCondition_i;

  /* SystemInitialize for Enabled SubSystem: '<S35>/Subsystem - pi//2 delay' */
  dzwcontr_Subsystempi2delay_Init(&dzwcontrol3_0_B.Fcn_g,
    &dzwcontrol3_0_B.Fcn1_h, &dzwcontrol3_0_P.Subsystempi2delay_p);

  /* End of SystemInitialize for SubSystem: '<S35>/Subsystem - pi//2 delay' */

  /* SystemInitialize for Enabled SubSystem: '<S35>/Subsystem1' */
  dzwcontrol3_0_Subsystem1_Init(&dzwcontrol3_0_B.Fcn_i, &dzwcontrol3_0_B.Fcn1_n,
    &dzwcontrol3_0_P.Subsystem1_n);

  /* End of SystemInitialize for SubSystem: '<S35>/Subsystem1' */

  /* SystemInitialize for Enabled SubSystem: '<S39>/Subsystem - pi//2 delay' */
  dzwcon_Subsystempi2delay_e_Init(&dzwcontrol3_0_B.Fcn_b,
    &dzwcontrol3_0_B.Fcn1_g, &dzwcontrol3_0_P.Subsystempi2delay_i);

  /* End of SystemInitialize for SubSystem: '<S39>/Subsystem - pi//2 delay' */

  /* SystemInitialize for Enabled SubSystem: '<S39>/Subsystem1' */
  dzwcontrol3_0_Subsystem1_c_Init(&dzwcontrol3_0_B.Fcn_h,
    &dzwcontrol3_0_B.Fcn1_b, &dzwcontrol3_0_P.Subsystem1_m);

  /* End of SystemInitialize for SubSystem: '<S39>/Subsystem1' */
  /* End of SystemInitialize for SubSystem: '<S8>/Three-phase current loop test' */

  /* SystemInitialize for IfAction SubSystem: '<S8>/VF-mode' */
  /* InitializeConditions for Sum: '<S54>/Sum2' incorporates:
   *  UnitDelay: '<S54>/Unit Delay'
   */
  dzwcontrol3_0_DW.UnitDelay_DSTATE_ot =
    dzwcontrol3_0_P.UnitDelay_InitialCondition;

  /* SystemInitialize for Enabled SubSystem: '<S53>/Subsystem - pi//2 delay' */
  dzwcontr_Subsystempi2delay_Init(&dzwcontrol3_0_B.Fcn_i0,
    &dzwcontrol3_0_B.Fcn1_ng, &dzwcontrol3_0_P.Subsystempi2delay);

  /* End of SystemInitialize for SubSystem: '<S53>/Subsystem - pi//2 delay' */

  /* SystemInitialize for Enabled SubSystem: '<S53>/Subsystem1' */
  dzwcontrol3_0_Subsystem1_Init(&dzwcontrol3_0_B.Fcn_bd, &dzwcontrol3_0_B.Fcn1_j,
    &dzwcontrol3_0_P.Subsystem1);

  /* End of SystemInitialize for SubSystem: '<S53>/Subsystem1' */

  /* SystemInitialize for Enabled SubSystem: '<S55>/Subsystem - pi//2 delay' */
  dzwcon_Subsystempi2delay_e_Init(&dzwcontrol3_0_B.Fcn_c,
    &dzwcontrol3_0_B.Fcn1_ep, &dzwcontrol3_0_P.Subsystempi2delay_l);

  /* End of SystemInitialize for SubSystem: '<S55>/Subsystem - pi//2 delay' */

  /* SystemInitialize for Enabled SubSystem: '<S55>/Subsystem1' */
  dzwcontrol3_0_Subsystem1_c_Init(&dzwcontrol3_0_B.Fcn_dz,
    &dzwcontrol3_0_B.Fcn1_d, &dzwcontrol3_0_P.Subsystem1_l);

  /* End of SystemInitialize for SubSystem: '<S55>/Subsystem1' */
  /* End of SystemInitialize for SubSystem: '<S8>/VF-mode' */

  /* SystemInitialize for MATLAB Function: '<S1>/MATLAB Function2' incorporates:
   *  SubSystem: '<S1>/Enable'
   */
  /* Start for S-Function (c280xgpio_do): '<S6>/Low EN' */
  EALLOW;
  GpioCtrlRegs.GPCMUX2.all &= 0xFFFCFFFF;
  GpioCtrlRegs.GPCDIR.all |= 0x1000000;
  EDIS;

  /* Start for S-Function (c280xgpio_do): '<S6>/Up EN' */
  EALLOW;
  GpioCtrlRegs.GPCMUX2.all &= 0xFFFFCFFF;
  GpioCtrlRegs.GPCDIR.all |= 0x400000;
  EDIS;

  /* Start for S-Function (c280xgpio_do): '<S6>/Low EN2' */
  EALLOW;
  GpioCtrlRegs.GPCMUX2.all &= 0xFCFFFFFF;
  GpioCtrlRegs.GPCDIR.all |= 0x10000000;
  EDIS;

  /* Start for S-Function (c280xgpio_do): '<S6>/Up EN2' */
  EALLOW;
  GpioCtrlRegs.GPCMUX2.all &= 0xFFCFFFFF;
  GpioCtrlRegs.GPCDIR.all |= 0x4000000;
  EDIS;

  /* Start for S-Function (c280xgpio_do): '<S6>/Low EN3' */
  EALLOW;
  GpioCtrlRegs.GPDMUX2.all &= 0xFFFCFFFF;
  GpioCtrlRegs.GPDDIR.all |= 0x1000000;
  EDIS;

  /* Start for S-Function (c280xgpio_do): '<S6>/Up EN3' */
  EALLOW;
  GpioCtrlRegs.GPCMUX2.all &= 0xCFFFFFFF;
  GpioCtrlRegs.GPCDIR.all |= 0x40000000;
  EDIS;

  /* SystemInitialize for MATLAB Function: '<S1>/MATLAB Function2' incorporates:
   *  SubSystem: '<S1>/Triggered Subsystem'
   */
  /* Start for S-Function (c2802xpwm): '<S9>/D' */

  /*** Initialize ePWM4 modules ***/
  {
    /*  // Time Base Control Register
       EPwm4Regs.TBCTL.bit.CTRMODE              = 2;          // Counter Mode
       EPwm4Regs.TBCTL.bit.SYNCOSEL             = 3;          // Sync Output Select
       EPwm4Regs.TBCTL2.bit.SYNCOSELX           = 0;          // Sync Output Select - additional options

       EPwm4Regs.TBCTL.bit.PRDLD                = 0;          // Shadow select

       EPwm4Regs.TBCTL2.bit.PRDLDSYNC           = 0;          // Shadow select

       EPwm4Regs.TBCTL.bit.PHSEN                = 0;          // Phase Load Enable
       EPwm4Regs.TBCTL.bit.PHSDIR               = 0;          // Phase Direction Bit
       EPwm4Regs.TBCTL.bit.HSPCLKDIV            = 0;          // High Speed TBCLK Pre-scaler
       EPwm4Regs.TBCTL.bit.CLKDIV               = 0;          // Time Base Clock Pre-scaler
       EPwm4Regs.TBCTL.bit.SWFSYNC              = 0;          // Software Force Sync Pulse
     */
    EPwm4Regs.TBCTL.all = (EPwm4Regs.TBCTL.all & ~0x3FFF) | 0x32;
    EPwm4Regs.TBCTL2.all = (EPwm4Regs.TBCTL2.all & ~0xF000) | 0x0;

    /*-- Setup Time-Base (TB) Submodule --*/
    EPwm4Regs.TBPRD = 10000;           // Time Base Period Register

    /* // Time-Base Phase Register
       EPwm4Regs.TBPHS.bit.TBPHS               = 0;          // Phase offset register
     */
    EPwm4Regs.TBPHS.all = (EPwm4Regs.TBPHS.all & ~0xFFFF0000) | 0x0;

    // Time Base Counter Register
    EPwm4Regs.TBCTR = 0x0000;          /* Clear counter*/

    /*-- Setup Counter_Compare (CC) Submodule --*/
    /*	// Counter Compare Control Register

       EPwm4Regs.CMPCTL.bit.LOADASYNC           = 0U;          // Active Compare A Load SYNC Option
       EPwm4Regs.CMPCTL.bit.LOADBSYNC           = 0U;          // Active Compare B Load SYNC Option
       EPwm4Regs.CMPCTL.bit.LOADAMODE           = 0U;          // Active Compare A Load
       EPwm4Regs.CMPCTL.bit.LOADBMODE           = 0U;          // Active Compare B Load
       EPwm4Regs.CMPCTL.bit.SHDWAMODE           = 0;          // Compare A Register Block Operating Mode
       EPwm4Regs.CMPCTL.bit.SHDWBMODE           = 0;          // Compare B Register Block Operating Mode
     */
    EPwm4Regs.CMPCTL.all = (EPwm4Regs.CMPCTL.all & ~0x3C5F) | 0x0;

    /* EPwm4Regs.CMPCTL2.bit.SHDWCMODE           = 0;          // Compare C Register Block Operating Mode
       EPwm4Regs.CMPCTL2.bit.SHDWDMODE           = 0;          // Compare D Register Block Operating Mode
       EPwm4Regs.CMPCTL2.bit.LOADCSYNC           = 0U;          // Active Compare C Load SYNC Option
       EPwm4Regs.CMPCTL2.bit.LOADDSYNC           = 0U;          // Active Compare D Load SYNC Option
       EPwm4Regs.CMPCTL2.bit.LOADCMODE           = 0U;          // Active Compare C Load
       EPwm4Regs.CMPCTL2.bit.LOADDMODE           = 0U;          // Active Compare D Load
     */
    EPwm4Regs.CMPCTL2.all = (EPwm4Regs.CMPCTL2.all & ~0x3C5F) | 0x0;
    EPwm4Regs.CMPA.bit.CMPA = 32000;   // Counter Compare A Register
    EPwm4Regs.CMPB.bit.CMPB = 32000;   // Counter Compare B Register
    EPwm4Regs.CMPC = 32000;            // Counter Compare C Register
    EPwm4Regs.CMPD = 32000;            // Counter Compare D Register

    /*-- Setup Action-Qualifier (AQ) Submodule --*/
    EPwm4Regs.AQCTLA.all = 144;// Action Qualifier Control Register For Output A
    EPwm4Regs.AQCTLB.all = 96; // Action Qualifier Control Register For Output B

    /*	// Action Qualifier Software Force Register
       EPwm4Regs.AQSFRC.bit.RLDCSF              = 3;          // Reload from Shadow Options
     */
    EPwm4Regs.AQSFRC.all = (EPwm4Regs.AQSFRC.all & ~0xC0) | 0xC0;

    /*	// Action Qualifier Continuous S/W Force Register
       EPwm4Regs.AQCSFRC.bit.CSFA               = 0;          // Continuous Software Force on output A
       EPwm4Regs.AQCSFRC.bit.CSFB               = 0;          // Continuous Software Force on output B
     */
    EPwm4Regs.AQCSFRC.all = (EPwm4Regs.AQCSFRC.all & ~0xF) | 0x0;

    /*-- Setup Dead-Band Generator (DB) Submodule --*/
    /*	// Dead-Band Generator Control Register
       EPwm4Regs.DBCTL.bit.OUT_MODE             = 3;          // Dead Band Output Mode Control
       EPwm4Regs.DBCTL.bit.IN_MODE              = 0;          // Dead Band Input Select Mode Control
       EPwm4Regs.DBCTL.bit.POLSEL               = 2;          // Polarity Select Control
       EPwm4Regs.DBCTL.bit.HALFCYCLE            = 0;          // Half Cycle Clocking Enable
       EPwm4Regs.DBCTL.bit.SHDWDBREDMODE        = 0;          // DBRED shadow mode
       EPwm4Regs.DBCTL.bit.SHDWDBFEDMODE        = 0;          // DBFED shadow mode
       EPwm4Regs.DBCTL.bit.LOADREDMODE          = 4U;        // DBRED load
       EPwm4Regs.DBCTL.bit.LOADFEDMODE          = 4U;        // DBFED load
     */
    EPwm4Regs.DBCTL.all = (EPwm4Regs.DBCTL.all & ~0x8FFF) | 0xB;
    EPwm4Regs.DBRED.bit.DBRED = 200;
                         // Dead-Band Generator Rising Edge Delay Count Register
    EPwm4Regs.DBFED.bit.DBFED = 200;
                        // Dead-Band Generator Falling Edge Delay Count Register

    /*-- Setup Event-Trigger (ET) Submodule --*/
    /*	// Event Trigger Selection and Pre-Scale Register
       EPwm4Regs.ETSEL.bit.SOCAEN               = 0;          // Start of Conversion A Enable
       EPwm4Regs.ETSEL.bit.SOCASELCMP           = 0;
       EPwm4Regs.ETSEL.bit.SOCASEL              = 0;          // Start of Conversion A Select
       EPwm4Regs.ETPS.bit.SOCPSSEL              = 1;          // EPWM4SOC Period Select
       EPwm4Regs.ETSOCPS.bit.SOCAPRD2           = 1;
       EPwm4Regs.ETSEL.bit.SOCBEN               = 0;          // Start of Conversion B Enable
       EPwm4Regs.ETSEL.bit.SOCBSELCMP           = 0;
       EPwm4Regs.ETSEL.bit.SOCBSEL              = 1;          // Start of Conversion A Select
       EPwm4Regs.ETPS.bit.SOCPSSEL              = 1;          // EPWM4SOCB Period Select
       EPwm4Regs.ETSOCPS.bit.SOCBPRD2           = 1;
       EPwm4Regs.ETSEL.bit.INTEN                = 0;          // EPWM4INTn Enable
       EPwm4Regs.ETSEL.bit.INTSELCMP            = 0;
       EPwm4Regs.ETSEL.bit.INTSEL               = 1;          // Start of Conversion A Select
       EPwm4Regs.ETPS.bit.INTPSSEL              = 1;          // EPWM4INTn Period Select
       EPwm4Regs.ETINTPS.bit.INTPRD2            = 1;
     */
    EPwm4Regs.ETSEL.all = (EPwm4Regs.ETSEL.all & ~0xFF7F) | 0x1001;
    EPwm4Regs.ETPS.all = (EPwm4Regs.ETPS.all & ~0x30) | 0x30;
    EPwm4Regs.ETSOCPS.all = (EPwm4Regs.ETSOCPS.all & ~0xF0F) | 0x101;
    EPwm4Regs.ETINTPS.all = (EPwm4Regs.ETINTPS.all & ~0xF) | 0x1;

    /*-- Setup PWM-Chopper (PC) Submodule --*/
    /*	// PWM Chopper Control Register
       EPwm4Regs.PCCTL.bit.CHPEN                = 0;          // PWM chopping enable
       EPwm4Regs.PCCTL.bit.CHPFREQ              = 0;          // Chopping clock frequency
       EPwm4Regs.PCCTL.bit.OSHTWTH              = 0;          // One-shot pulse width
       EPwm4Regs.PCCTL.bit.CHPDUTY              = 0;          // Chopping clock Duty cycle
     */
    EPwm4Regs.PCCTL.all = (EPwm4Regs.PCCTL.all & ~0x7FF) | 0x0;

    /*-- Set up Trip-Zone (TZ) Submodule --*/
    EALLOW;
    EPwm4Regs.TZSEL.all = 0;           // Trip Zone Select Register

    /*	// Trip Zone Control Register
       EPwm4Regs.TZCTL.bit.TZA                  = 3;          // TZ1 to TZ6 Trip Action On EPWM4A
       EPwm4Regs.TZCTL.bit.TZB                  = 3;          // TZ1 to TZ6 Trip Action On EPWM4B
       EPwm4Regs.TZCTL.bit.DCAEVT1              = 3;          // EPWM4A action on DCAEVT1
       EPwm4Regs.TZCTL.bit.DCAEVT2              = 3;          // EPWM4A action on DCAEVT2
       EPwm4Regs.TZCTL.bit.DCBEVT1              = 3;          // EPWM4B action on DCBEVT1
       EPwm4Regs.TZCTL.bit.DCBEVT2              = 3;          // EPWM4B action on DCBEVT2
     */
    EPwm4Regs.TZCTL.all = (EPwm4Regs.TZCTL.all & ~0xFFF) | 0xFFF;

    /*	// Trip Zone Enable Interrupt Register
       EPwm4Regs.TZEINT.bit.OST                 = 0;          // Trip Zones One Shot Int Enable
       EPwm4Regs.TZEINT.bit.CBC                 = 0;          // Trip Zones Cycle By Cycle Int Enable
       EPwm4Regs.TZEINT.bit.DCAEVT1             = 0;          // Digital Compare A Event 1 Int Enable
       EPwm4Regs.TZEINT.bit.DCAEVT2             = 0;          // Digital Compare A Event 2 Int Enable
       EPwm4Regs.TZEINT.bit.DCBEVT1             = 0;          // Digital Compare B Event 1 Int Enable
       EPwm4Regs.TZEINT.bit.DCBEVT2             = 0;          // Digital Compare B Event 2 Int Enable
     */
    EPwm4Regs.TZEINT.all = (EPwm4Regs.TZEINT.all & ~0x7E) | 0x0;

    /*	// Digital Compare A Control Register
       EPwm4Regs.DCACTL.bit.EVT1SYNCE           = 0;          // DCAEVT1 SYNC Enable
       EPwm4Regs.DCACTL.bit.EVT1SOCE            = 1;          // DCAEVT1 SOC Enable
       EPwm4Regs.DCACTL.bit.EVT1FRCSYNCSEL      = 0;          // DCAEVT1 Force Sync Signal
       EPwm4Regs.DCACTL.bit.EVT1SRCSEL          = 0;          // DCAEVT1 Source Signal
       EPwm4Regs.DCACTL.bit.EVT2FRCSYNCSEL      = 0;          // DCAEVT2 Force Sync Signal
       EPwm4Regs.DCACTL.bit.EVT2SRCSEL          = 0;          // DCAEVT2 Source Signal
     */
    EPwm4Regs.DCACTL.all = (EPwm4Regs.DCACTL.all & ~0x30F) | 0x4;

    /*	// Digital Compare B Control Register
       EPwm4Regs.DCBCTL.bit.EVT1SYNCE           = 0;          // DCBEVT1 SYNC Enable
       EPwm4Regs.DCBCTL.bit.EVT1SOCE            = 0;          // DCBEVT1 SOC Enable
       EPwm4Regs.DCBCTL.bit.EVT1FRCSYNCSEL      = 0;          // DCBEVT1 Force Sync Signal
       EPwm4Regs.DCBCTL.bit.EVT1SRCSEL          = 0;          // DCBEVT1 Source Signal
       EPwm4Regs.DCBCTL.bit.EVT2FRCSYNCSEL      = 0;          // DCBEVT2 Force Sync Signal
       EPwm4Regs.DCBCTL.bit.EVT2SRCSEL          = 0;          // DCBEVT2 Source Signal
     */
    EPwm4Regs.DCBCTL.all = (EPwm4Regs.DCBCTL.all & ~0x30F) | 0x0;

    /*	// Digital Compare Trip Select Register
       EPwm4Regs.DCTRIPSEL.bit.DCAHCOMPSEL      = 0;          // Digital Compare A High COMP Input Select

       EPwm4Regs.DCTRIPSEL.bit.DCALCOMPSEL      = 1;          // Digital Compare A Low COMP Input Select
       EPwm4Regs.DCTRIPSEL.bit.DCBHCOMPSEL      = 0;          // Digital Compare B High COMP Input Select
       EPwm4Regs.DCTRIPSEL.bit.DCBLCOMPSEL      = 1;          // Digital Compare B Low COMP Input Select

     */
    EPwm4Regs.DCTRIPSEL.all = (EPwm4Regs.DCTRIPSEL.all & ~ 0xFFFF) | 0x1010;

    /*	// Trip Zone Digital Comparator Select Register
       EPwm4Regs.TZDCSEL.bit.DCAEVT1            = 0;          // Digital Compare Output A Event 1
       EPwm4Regs.TZDCSEL.bit.DCAEVT2            = 0;          // Digital Compare Output A Event 2
       EPwm4Regs.TZDCSEL.bit.DCBEVT1            = 0;          // Digital Compare Output B Event 1
       EPwm4Regs.TZDCSEL.bit.DCBEVT2            = 0;          // Digital Compare Output B Event 2
     */
    EPwm4Regs.TZDCSEL.all = (EPwm4Regs.TZDCSEL.all & ~0xFFF) | 0x0;

    /*	// Digital Compare Filter Control Register
       EPwm4Regs.DCFCTL.bit.BLANKE              = 0;          // Blanking Enable/Disable
       EPwm4Regs.DCFCTL.bit.PULSESEL            = 1;          // Pulse Select for Blanking & Capture Alignment
       EPwm4Regs.DCFCTL.bit.BLANKINV            = 0;          // Blanking Window Inversion
       EPwm4Regs.DCFCTL.bit.SRCSEL              = 0;          // Filter Block Signal Source Select
     */
    EPwm4Regs.DCFCTL.all = (EPwm4Regs.DCFCTL.all & ~0x3F) | 0x10;
    EPwm4Regs.DCFOFFSET = 0;           // Digital Compare Filter Offset Register
    EPwm4Regs.DCFWINDOW = 0;           // Digital Compare Filter Window Register

    /*	// Digital Compare Capture Control Register
       EPwm4Regs.DCCAPCTL.bit.CAPE              = 0;          // Counter Capture Enable
     */
    EPwm4Regs.DCCAPCTL.all = (EPwm4Regs.DCCAPCTL.all & ~0x1) | 0x0;

    /*	// HRPWM Configuration Register
       EPwm4Regs.HRCNFG.bit.SWAPAB              = 0;          // Swap EPWMA and EPWMB Outputs Bit
       EPwm4Regs.HRCNFG.bit.SELOUTB             = 0;          // EPWMB Output Selection Bit
     */
    EPwm4Regs.HRCNFG.all = (EPwm4Regs.HRCNFG.all & ~0xA0) | 0x0;

    /* Update the Link Registers with the link value for all the Compare values and TBPRD */
    /* No error is thrown if the ePWM register exists in the model or not */
    EPwm4Regs.EPWMXLINK.bit.TBPRDLINK = 3;
    EPwm4Regs.EPWMXLINK.bit.CMPALINK = 3;
    EPwm4Regs.EPWMXLINK.bit.CMPBLINK = 3;
    EPwm4Regs.EPWMXLINK.bit.CMPCLINK = 3;
    EPwm4Regs.EPWMXLINK.bit.CMPDLINK = 3;

    /* SYNCPER - Peripheral synchronization output event
       EPwm4Regs.HRPCTL.bit.PWMSYNCSEL            = 0;          // EPWMSYNCPER selection
       EPwm4Regs.HRPCTL.bit.PWMSYNCSELX           = 0;          //  EPWMSYNCPER selection
     */
    EPwm4Regs.HRPCTL.all = (EPwm4Regs.HRPCTL.all & ~0x72) | 0x0;
    EDIS;
  }

  /* Start for S-Function (c2802xpwm): '<S9>/E' */

  /*** Initialize ePWM5 modules ***/
  {
    /*  // Time Base Control Register
       EPwm5Regs.TBCTL.bit.CTRMODE              = 2;          // Counter Mode
       EPwm5Regs.TBCTL.bit.SYNCOSEL             = 3;          // Sync Output Select
       EPwm5Regs.TBCTL2.bit.SYNCOSELX           = 0;          // Sync Output Select - additional options

       EPwm5Regs.TBCTL.bit.PRDLD                = 0;          // Shadow select

       EPwm5Regs.TBCTL2.bit.PRDLDSYNC           = 0;          // Shadow select

       EPwm5Regs.TBCTL.bit.PHSEN                = 0;          // Phase Load Enable
       EPwm5Regs.TBCTL.bit.PHSDIR               = 0;          // Phase Direction Bit
       EPwm5Regs.TBCTL.bit.HSPCLKDIV            = 0;          // High Speed TBCLK Pre-scaler
       EPwm5Regs.TBCTL.bit.CLKDIV               = 0;          // Time Base Clock Pre-scaler
       EPwm5Regs.TBCTL.bit.SWFSYNC              = 0;          // Software Force Sync Pulse
     */
    EPwm5Regs.TBCTL.all = (EPwm5Regs.TBCTL.all & ~0x3FFF) | 0x32;
    EPwm5Regs.TBCTL2.all = (EPwm5Regs.TBCTL2.all & ~0xF000) | 0x0;

    /*-- Setup Time-Base (TB) Submodule --*/
    EPwm5Regs.TBPRD = 10000;           // Time Base Period Register

    /* // Time-Base Phase Register
       EPwm5Regs.TBPHS.bit.TBPHS               = 0;          // Phase offset register
     */
    EPwm5Regs.TBPHS.all = (EPwm5Regs.TBPHS.all & ~0xFFFF0000) | 0x0;

    // Time Base Counter Register
    EPwm5Regs.TBCTR = 0x0000;          /* Clear counter*/

    /*-- Setup Counter_Compare (CC) Submodule --*/
    /*	// Counter Compare Control Register

       EPwm5Regs.CMPCTL.bit.LOADASYNC           = 0U;          // Active Compare A Load SYNC Option
       EPwm5Regs.CMPCTL.bit.LOADBSYNC           = 0U;          // Active Compare B Load SYNC Option
       EPwm5Regs.CMPCTL.bit.LOADAMODE           = 0U;          // Active Compare A Load
       EPwm5Regs.CMPCTL.bit.LOADBMODE           = 0U;          // Active Compare B Load
       EPwm5Regs.CMPCTL.bit.SHDWAMODE           = 0;          // Compare A Register Block Operating Mode
       EPwm5Regs.CMPCTL.bit.SHDWBMODE           = 0;          // Compare B Register Block Operating Mode
     */
    EPwm5Regs.CMPCTL.all = (EPwm5Regs.CMPCTL.all & ~0x3C5F) | 0x0;

    /* EPwm5Regs.CMPCTL2.bit.SHDWCMODE           = 0;          // Compare C Register Block Operating Mode
       EPwm5Regs.CMPCTL2.bit.SHDWDMODE           = 0;          // Compare D Register Block Operating Mode
       EPwm5Regs.CMPCTL2.bit.LOADCSYNC           = 0U;          // Active Compare C Load SYNC Option
       EPwm5Regs.CMPCTL2.bit.LOADDSYNC           = 0U;          // Active Compare D Load SYNC Option
       EPwm5Regs.CMPCTL2.bit.LOADCMODE           = 0U;          // Active Compare C Load
       EPwm5Regs.CMPCTL2.bit.LOADDMODE           = 0U;          // Active Compare D Load
     */
    EPwm5Regs.CMPCTL2.all = (EPwm5Regs.CMPCTL2.all & ~0x3C5F) | 0x0;
    EPwm5Regs.CMPA.bit.CMPA = 32000;   // Counter Compare A Register
    EPwm5Regs.CMPB.bit.CMPB = 32000;   // Counter Compare B Register
    EPwm5Regs.CMPC = 32000;            // Counter Compare C Register
    EPwm5Regs.CMPD = 32000;            // Counter Compare D Register

    /*-- Setup Action-Qualifier (AQ) Submodule --*/
    EPwm5Regs.AQCTLA.all = 144;// Action Qualifier Control Register For Output A
    EPwm5Regs.AQCTLB.all = 96; // Action Qualifier Control Register For Output B

    /*	// Action Qualifier Software Force Register
       EPwm5Regs.AQSFRC.bit.RLDCSF              = 3;          // Reload from Shadow Options
     */
    EPwm5Regs.AQSFRC.all = (EPwm5Regs.AQSFRC.all & ~0xC0) | 0xC0;

    /*	// Action Qualifier Continuous S/W Force Register
       EPwm5Regs.AQCSFRC.bit.CSFA               = 0;          // Continuous Software Force on output A
       EPwm5Regs.AQCSFRC.bit.CSFB               = 0;          // Continuous Software Force on output B
     */
    EPwm5Regs.AQCSFRC.all = (EPwm5Regs.AQCSFRC.all & ~0xF) | 0x0;

    /*-- Setup Dead-Band Generator (DB) Submodule --*/
    /*	// Dead-Band Generator Control Register
       EPwm5Regs.DBCTL.bit.OUT_MODE             = 3;          // Dead Band Output Mode Control
       EPwm5Regs.DBCTL.bit.IN_MODE              = 0;          // Dead Band Input Select Mode Control
       EPwm5Regs.DBCTL.bit.POLSEL               = 2;          // Polarity Select Control
       EPwm5Regs.DBCTL.bit.HALFCYCLE            = 0;          // Half Cycle Clocking Enable
       EPwm5Regs.DBCTL.bit.SHDWDBREDMODE        = 0;          // DBRED shadow mode
       EPwm5Regs.DBCTL.bit.SHDWDBFEDMODE        = 0;          // DBFED shadow mode
       EPwm5Regs.DBCTL.bit.LOADREDMODE          = 4U;        // DBRED load
       EPwm5Regs.DBCTL.bit.LOADFEDMODE          = 4U;        // DBFED load
     */
    EPwm5Regs.DBCTL.all = (EPwm5Regs.DBCTL.all & ~0x8FFF) | 0xB;
    EPwm5Regs.DBRED.bit.DBRED = 400;
                         // Dead-Band Generator Rising Edge Delay Count Register
    EPwm5Regs.DBFED.bit.DBFED = 400;
                        // Dead-Band Generator Falling Edge Delay Count Register

    /*-- Setup Event-Trigger (ET) Submodule --*/
    /*	// Event Trigger Selection and Pre-Scale Register
       EPwm5Regs.ETSEL.bit.SOCAEN               = 0;          // Start of Conversion A Enable
       EPwm5Regs.ETSEL.bit.SOCASELCMP           = 0;
       EPwm5Regs.ETSEL.bit.SOCASEL              = 0;          // Start of Conversion A Select
       EPwm5Regs.ETPS.bit.SOCPSSEL              = 1;          // EPWM5SOC Period Select
       EPwm5Regs.ETSOCPS.bit.SOCAPRD2           = 1;
       EPwm5Regs.ETSEL.bit.SOCBEN               = 0;          // Start of Conversion B Enable
       EPwm5Regs.ETSEL.bit.SOCBSELCMP           = 0;
       EPwm5Regs.ETSEL.bit.SOCBSEL              = 1;          // Start of Conversion A Select
       EPwm5Regs.ETPS.bit.SOCPSSEL              = 1;          // EPWM5SOCB Period Select
       EPwm5Regs.ETSOCPS.bit.SOCBPRD2           = 1;
       EPwm5Regs.ETSEL.bit.INTEN                = 0;          // EPWM5INTn Enable
       EPwm5Regs.ETSEL.bit.INTSELCMP            = 0;
       EPwm5Regs.ETSEL.bit.INTSEL               = 1;          // Start of Conversion A Select
       EPwm5Regs.ETPS.bit.INTPSSEL              = 1;          // EPWM5INTn Period Select
       EPwm5Regs.ETINTPS.bit.INTPRD2            = 1;
     */
    EPwm5Regs.ETSEL.all = (EPwm5Regs.ETSEL.all & ~0xFF7F) | 0x1001;
    EPwm5Regs.ETPS.all = (EPwm5Regs.ETPS.all & ~0x30) | 0x30;
    EPwm5Regs.ETSOCPS.all = (EPwm5Regs.ETSOCPS.all & ~0xF0F) | 0x101;
    EPwm5Regs.ETINTPS.all = (EPwm5Regs.ETINTPS.all & ~0xF) | 0x1;

    /*-- Setup PWM-Chopper (PC) Submodule --*/
    /*	// PWM Chopper Control Register
       EPwm5Regs.PCCTL.bit.CHPEN                = 0;          // PWM chopping enable
       EPwm5Regs.PCCTL.bit.CHPFREQ              = 0;          // Chopping clock frequency
       EPwm5Regs.PCCTL.bit.OSHTWTH              = 0;          // One-shot pulse width
       EPwm5Regs.PCCTL.bit.CHPDUTY              = 0;          // Chopping clock Duty cycle
     */
    EPwm5Regs.PCCTL.all = (EPwm5Regs.PCCTL.all & ~0x7FF) | 0x0;

    /*-- Set up Trip-Zone (TZ) Submodule --*/
    EALLOW;
    EPwm5Regs.TZSEL.all = 0;           // Trip Zone Select Register

    /*	// Trip Zone Control Register
       EPwm5Regs.TZCTL.bit.TZA                  = 3;          // TZ1 to TZ6 Trip Action On EPWM5A
       EPwm5Regs.TZCTL.bit.TZB                  = 3;          // TZ1 to TZ6 Trip Action On EPWM5B
       EPwm5Regs.TZCTL.bit.DCAEVT1              = 3;          // EPWM5A action on DCAEVT1
       EPwm5Regs.TZCTL.bit.DCAEVT2              = 3;          // EPWM5A action on DCAEVT2
       EPwm5Regs.TZCTL.bit.DCBEVT1              = 3;          // EPWM5B action on DCBEVT1
       EPwm5Regs.TZCTL.bit.DCBEVT2              = 3;          // EPWM5B action on DCBEVT2
     */
    EPwm5Regs.TZCTL.all = (EPwm5Regs.TZCTL.all & ~0xFFF) | 0xFFF;

    /*	// Trip Zone Enable Interrupt Register
       EPwm5Regs.TZEINT.bit.OST                 = 0;          // Trip Zones One Shot Int Enable
       EPwm5Regs.TZEINT.bit.CBC                 = 0;          // Trip Zones Cycle By Cycle Int Enable
       EPwm5Regs.TZEINT.bit.DCAEVT1             = 0;          // Digital Compare A Event 1 Int Enable
       EPwm5Regs.TZEINT.bit.DCAEVT2             = 0;          // Digital Compare A Event 2 Int Enable
       EPwm5Regs.TZEINT.bit.DCBEVT1             = 0;          // Digital Compare B Event 1 Int Enable
       EPwm5Regs.TZEINT.bit.DCBEVT2             = 0;          // Digital Compare B Event 2 Int Enable
     */
    EPwm5Regs.TZEINT.all = (EPwm5Regs.TZEINT.all & ~0x7E) | 0x0;

    /*	// Digital Compare A Control Register
       EPwm5Regs.DCACTL.bit.EVT1SYNCE           = 0;          // DCAEVT1 SYNC Enable
       EPwm5Regs.DCACTL.bit.EVT1SOCE            = 1;          // DCAEVT1 SOC Enable
       EPwm5Regs.DCACTL.bit.EVT1FRCSYNCSEL      = 0;          // DCAEVT1 Force Sync Signal
       EPwm5Regs.DCACTL.bit.EVT1SRCSEL          = 0;          // DCAEVT1 Source Signal
       EPwm5Regs.DCACTL.bit.EVT2FRCSYNCSEL      = 0;          // DCAEVT2 Force Sync Signal
       EPwm5Regs.DCACTL.bit.EVT2SRCSEL          = 0;          // DCAEVT2 Source Signal
     */
    EPwm5Regs.DCACTL.all = (EPwm5Regs.DCACTL.all & ~0x30F) | 0x4;

    /*	// Digital Compare B Control Register
       EPwm5Regs.DCBCTL.bit.EVT1SYNCE           = 0;          // DCBEVT1 SYNC Enable
       EPwm5Regs.DCBCTL.bit.EVT1SOCE            = 0;          // DCBEVT1 SOC Enable
       EPwm5Regs.DCBCTL.bit.EVT1FRCSYNCSEL      = 0;          // DCBEVT1 Force Sync Signal
       EPwm5Regs.DCBCTL.bit.EVT1SRCSEL          = 0;          // DCBEVT1 Source Signal
       EPwm5Regs.DCBCTL.bit.EVT2FRCSYNCSEL      = 0;          // DCBEVT2 Force Sync Signal
       EPwm5Regs.DCBCTL.bit.EVT2SRCSEL          = 0;          // DCBEVT2 Source Signal
     */
    EPwm5Regs.DCBCTL.all = (EPwm5Regs.DCBCTL.all & ~0x30F) | 0x0;

    /*	// Digital Compare Trip Select Register
       EPwm5Regs.DCTRIPSEL.bit.DCAHCOMPSEL      = 0;          // Digital Compare A High COMP Input Select

       EPwm5Regs.DCTRIPSEL.bit.DCALCOMPSEL      = 1;          // Digital Compare A Low COMP Input Select
       EPwm5Regs.DCTRIPSEL.bit.DCBHCOMPSEL      = 0;          // Digital Compare B High COMP Input Select
       EPwm5Regs.DCTRIPSEL.bit.DCBLCOMPSEL      = 1;          // Digital Compare B Low COMP Input Select

     */
    EPwm5Regs.DCTRIPSEL.all = (EPwm5Regs.DCTRIPSEL.all & ~ 0xFFFF) | 0x1010;

    /*	// Trip Zone Digital Comparator Select Register
       EPwm5Regs.TZDCSEL.bit.DCAEVT1            = 0;          // Digital Compare Output A Event 1
       EPwm5Regs.TZDCSEL.bit.DCAEVT2            = 0;          // Digital Compare Output A Event 2
       EPwm5Regs.TZDCSEL.bit.DCBEVT1            = 0;          // Digital Compare Output B Event 1
       EPwm5Regs.TZDCSEL.bit.DCBEVT2            = 0;          // Digital Compare Output B Event 2
     */
    EPwm5Regs.TZDCSEL.all = (EPwm5Regs.TZDCSEL.all & ~0xFFF) | 0x0;

    /*	// Digital Compare Filter Control Register
       EPwm5Regs.DCFCTL.bit.BLANKE              = 0;          // Blanking Enable/Disable
       EPwm5Regs.DCFCTL.bit.PULSESEL            = 1;          // Pulse Select for Blanking & Capture Alignment
       EPwm5Regs.DCFCTL.bit.BLANKINV            = 0;          // Blanking Window Inversion
       EPwm5Regs.DCFCTL.bit.SRCSEL              = 0;          // Filter Block Signal Source Select
     */
    EPwm5Regs.DCFCTL.all = (EPwm5Regs.DCFCTL.all & ~0x3F) | 0x10;
    EPwm5Regs.DCFOFFSET = 0;           // Digital Compare Filter Offset Register
    EPwm5Regs.DCFWINDOW = 0;           // Digital Compare Filter Window Register

    /*	// Digital Compare Capture Control Register
       EPwm5Regs.DCCAPCTL.bit.CAPE              = 0;          // Counter Capture Enable
     */
    EPwm5Regs.DCCAPCTL.all = (EPwm5Regs.DCCAPCTL.all & ~0x1) | 0x0;

    /*	// HRPWM Configuration Register
       EPwm5Regs.HRCNFG.bit.SWAPAB              = 0;          // Swap EPWMA and EPWMB Outputs Bit
       EPwm5Regs.HRCNFG.bit.SELOUTB             = 0;          // EPWMB Output Selection Bit
     */
    EPwm5Regs.HRCNFG.all = (EPwm5Regs.HRCNFG.all & ~0xA0) | 0x0;

    /* Update the Link Registers with the link value for all the Compare values and TBPRD */
    /* No error is thrown if the ePWM register exists in the model or not */
    EPwm5Regs.EPWMXLINK.bit.TBPRDLINK = 4;
    EPwm5Regs.EPWMXLINK.bit.CMPALINK = 4;
    EPwm5Regs.EPWMXLINK.bit.CMPBLINK = 4;
    EPwm5Regs.EPWMXLINK.bit.CMPCLINK = 4;
    EPwm5Regs.EPWMXLINK.bit.CMPDLINK = 4;

    /* SYNCPER - Peripheral synchronization output event
       EPwm5Regs.HRPCTL.bit.PWMSYNCSEL            = 0;          // EPWMSYNCPER selection
       EPwm5Regs.HRPCTL.bit.PWMSYNCSELX           = 0;          //  EPWMSYNCPER selection
     */
    EPwm5Regs.HRPCTL.all = (EPwm5Regs.HRPCTL.all & ~0x72) | 0x0;
    EDIS;
  }

  /* Start for S-Function (c2802xpwm): '<S9>/F' */

  /*** Initialize ePWM6 modules ***/
  {
    /*  // Time Base Control Register
       EPwm6Regs.TBCTL.bit.CTRMODE              = 2;          // Counter Mode
       EPwm6Regs.TBCTL.bit.SYNCOSEL             = 3;          // Sync Output Select
       EPwm6Regs.TBCTL2.bit.SYNCOSELX           = 0;          // Sync Output Select - additional options

       EPwm6Regs.TBCTL.bit.PRDLD                = 0;          // Shadow select

       EPwm6Regs.TBCTL2.bit.PRDLDSYNC           = 0;          // Shadow select

       EPwm6Regs.TBCTL.bit.PHSEN                = 0;          // Phase Load Enable
       EPwm6Regs.TBCTL.bit.PHSDIR               = 0;          // Phase Direction Bit
       EPwm6Regs.TBCTL.bit.HSPCLKDIV            = 0;          // High Speed TBCLK Pre-scaler
       EPwm6Regs.TBCTL.bit.CLKDIV               = 0;          // Time Base Clock Pre-scaler
       EPwm6Regs.TBCTL.bit.SWFSYNC              = 0;          // Software Force Sync Pulse
     */
    EPwm6Regs.TBCTL.all = (EPwm6Regs.TBCTL.all & ~0x3FFF) | 0x32;
    EPwm6Regs.TBCTL2.all = (EPwm6Regs.TBCTL2.all & ~0xF000) | 0x0;

    /*-- Setup Time-Base (TB) Submodule --*/
    EPwm6Regs.TBPRD = 10000;           // Time Base Period Register

    /* // Time-Base Phase Register
       EPwm6Regs.TBPHS.bit.TBPHS               = 0;          // Phase offset register
     */
    EPwm6Regs.TBPHS.all = (EPwm6Regs.TBPHS.all & ~0xFFFF0000) | 0x0;

    // Time Base Counter Register
    EPwm6Regs.TBCTR = 0x0000;          /* Clear counter*/

    /*-- Setup Counter_Compare (CC) Submodule --*/
    /*	// Counter Compare Control Register

       EPwm6Regs.CMPCTL.bit.LOADASYNC           = 0U;          // Active Compare A Load SYNC Option
       EPwm6Regs.CMPCTL.bit.LOADBSYNC           = 0U;          // Active Compare B Load SYNC Option
       EPwm6Regs.CMPCTL.bit.LOADAMODE           = 0U;          // Active Compare A Load
       EPwm6Regs.CMPCTL.bit.LOADBMODE           = 0U;          // Active Compare B Load
       EPwm6Regs.CMPCTL.bit.SHDWAMODE           = 0;          // Compare A Register Block Operating Mode
       EPwm6Regs.CMPCTL.bit.SHDWBMODE           = 0;          // Compare B Register Block Operating Mode
     */
    EPwm6Regs.CMPCTL.all = (EPwm6Regs.CMPCTL.all & ~0x3C5F) | 0x0;

    /* EPwm6Regs.CMPCTL2.bit.SHDWCMODE           = 0;          // Compare C Register Block Operating Mode
       EPwm6Regs.CMPCTL2.bit.SHDWDMODE           = 0;          // Compare D Register Block Operating Mode
       EPwm6Regs.CMPCTL2.bit.LOADCSYNC           = 0U;          // Active Compare C Load SYNC Option
       EPwm6Regs.CMPCTL2.bit.LOADDSYNC           = 0U;          // Active Compare D Load SYNC Option
       EPwm6Regs.CMPCTL2.bit.LOADCMODE           = 0U;          // Active Compare C Load
       EPwm6Regs.CMPCTL2.bit.LOADDMODE           = 0U;          // Active Compare D Load
     */
    EPwm6Regs.CMPCTL2.all = (EPwm6Regs.CMPCTL2.all & ~0x3C5F) | 0x0;
    EPwm6Regs.CMPA.bit.CMPA = 32000;   // Counter Compare A Register
    EPwm6Regs.CMPB.bit.CMPB = 32000;   // Counter Compare B Register
    EPwm6Regs.CMPC = 32000;            // Counter Compare C Register
    EPwm6Regs.CMPD = 32000;            // Counter Compare D Register

    /*-- Setup Action-Qualifier (AQ) Submodule --*/
    EPwm6Regs.AQCTLA.all = 144;// Action Qualifier Control Register For Output A
    EPwm6Regs.AQCTLB.all = 96; // Action Qualifier Control Register For Output B

    /*	// Action Qualifier Software Force Register
       EPwm6Regs.AQSFRC.bit.RLDCSF              = 3;          // Reload from Shadow Options
     */
    EPwm6Regs.AQSFRC.all = (EPwm6Regs.AQSFRC.all & ~0xC0) | 0xC0;

    /*	// Action Qualifier Continuous S/W Force Register
       EPwm6Regs.AQCSFRC.bit.CSFA               = 0;          // Continuous Software Force on output A
       EPwm6Regs.AQCSFRC.bit.CSFB               = 0;          // Continuous Software Force on output B
     */
    EPwm6Regs.AQCSFRC.all = (EPwm6Regs.AQCSFRC.all & ~0xF) | 0x0;

    /*-- Setup Dead-Band Generator (DB) Submodule --*/
    /*	// Dead-Band Generator Control Register
       EPwm6Regs.DBCTL.bit.OUT_MODE             = 3;          // Dead Band Output Mode Control
       EPwm6Regs.DBCTL.bit.IN_MODE              = 0;          // Dead Band Input Select Mode Control
       EPwm6Regs.DBCTL.bit.POLSEL               = 2;          // Polarity Select Control
       EPwm6Regs.DBCTL.bit.HALFCYCLE            = 0;          // Half Cycle Clocking Enable
       EPwm6Regs.DBCTL.bit.SHDWDBREDMODE        = 0;          // DBRED shadow mode
       EPwm6Regs.DBCTL.bit.SHDWDBFEDMODE        = 0;          // DBFED shadow mode
       EPwm6Regs.DBCTL.bit.LOADREDMODE          = 4U;        // DBRED load
       EPwm6Regs.DBCTL.bit.LOADFEDMODE          = 4U;        // DBFED load
     */
    EPwm6Regs.DBCTL.all = (EPwm6Regs.DBCTL.all & ~0x8FFF) | 0xB;
    EPwm6Regs.DBRED.bit.DBRED = 400;
                         // Dead-Band Generator Rising Edge Delay Count Register
    EPwm6Regs.DBFED.bit.DBFED = 400;
                        // Dead-Band Generator Falling Edge Delay Count Register

    /*-- Setup Event-Trigger (ET) Submodule --*/
    /*	// Event Trigger Selection and Pre-Scale Register
       EPwm6Regs.ETSEL.bit.SOCAEN               = 0;          // Start of Conversion A Enable
       EPwm6Regs.ETSEL.bit.SOCASELCMP           = 0;
       EPwm6Regs.ETSEL.bit.SOCASEL              = 0;          // Start of Conversion A Select
       EPwm6Regs.ETPS.bit.SOCPSSEL              = 1;          // EPWM6SOC Period Select
       EPwm6Regs.ETSOCPS.bit.SOCAPRD2           = 1;
       EPwm6Regs.ETSEL.bit.SOCBEN               = 0;          // Start of Conversion B Enable
       EPwm6Regs.ETSEL.bit.SOCBSELCMP           = 0;
       EPwm6Regs.ETSEL.bit.SOCBSEL              = 1;          // Start of Conversion A Select
       EPwm6Regs.ETPS.bit.SOCPSSEL              = 1;          // EPWM6SOCB Period Select
       EPwm6Regs.ETSOCPS.bit.SOCBPRD2           = 1;
       EPwm6Regs.ETSEL.bit.INTEN                = 0;          // EPWM6INTn Enable
       EPwm6Regs.ETSEL.bit.INTSELCMP            = 0;
       EPwm6Regs.ETSEL.bit.INTSEL               = 1;          // Start of Conversion A Select
       EPwm6Regs.ETPS.bit.INTPSSEL              = 1;          // EPWM6INTn Period Select
       EPwm6Regs.ETINTPS.bit.INTPRD2            = 1;
     */
    EPwm6Regs.ETSEL.all = (EPwm6Regs.ETSEL.all & ~0xFF7F) | 0x1001;
    EPwm6Regs.ETPS.all = (EPwm6Regs.ETPS.all & ~0x30) | 0x30;
    EPwm6Regs.ETSOCPS.all = (EPwm6Regs.ETSOCPS.all & ~0xF0F) | 0x101;
    EPwm6Regs.ETINTPS.all = (EPwm6Regs.ETINTPS.all & ~0xF) | 0x1;

    /*-- Setup PWM-Chopper (PC) Submodule --*/
    /*	// PWM Chopper Control Register
       EPwm6Regs.PCCTL.bit.CHPEN                = 0;          // PWM chopping enable
       EPwm6Regs.PCCTL.bit.CHPFREQ              = 0;          // Chopping clock frequency
       EPwm6Regs.PCCTL.bit.OSHTWTH              = 0;          // One-shot pulse width
       EPwm6Regs.PCCTL.bit.CHPDUTY              = 0;          // Chopping clock Duty cycle
     */
    EPwm6Regs.PCCTL.all = (EPwm6Regs.PCCTL.all & ~0x7FF) | 0x0;

    /*-- Set up Trip-Zone (TZ) Submodule --*/
    EALLOW;
    EPwm6Regs.TZSEL.all = 0;           // Trip Zone Select Register

    /*	// Trip Zone Control Register
       EPwm6Regs.TZCTL.bit.TZA                  = 3;          // TZ1 to TZ6 Trip Action On EPWM6A
       EPwm6Regs.TZCTL.bit.TZB                  = 3;          // TZ1 to TZ6 Trip Action On EPWM6B
       EPwm6Regs.TZCTL.bit.DCAEVT1              = 3;          // EPWM6A action on DCAEVT1
       EPwm6Regs.TZCTL.bit.DCAEVT2              = 3;          // EPWM6A action on DCAEVT2
       EPwm6Regs.TZCTL.bit.DCBEVT1              = 3;          // EPWM6B action on DCBEVT1
       EPwm6Regs.TZCTL.bit.DCBEVT2              = 3;          // EPWM6B action on DCBEVT2
     */
    EPwm6Regs.TZCTL.all = (EPwm6Regs.TZCTL.all & ~0xFFF) | 0xFFF;

    /*	// Trip Zone Enable Interrupt Register
       EPwm6Regs.TZEINT.bit.OST                 = 0;          // Trip Zones One Shot Int Enable
       EPwm6Regs.TZEINT.bit.CBC                 = 0;          // Trip Zones Cycle By Cycle Int Enable
       EPwm6Regs.TZEINT.bit.DCAEVT1             = 0;          // Digital Compare A Event 1 Int Enable
       EPwm6Regs.TZEINT.bit.DCAEVT2             = 0;          // Digital Compare A Event 2 Int Enable
       EPwm6Regs.TZEINT.bit.DCBEVT1             = 0;          // Digital Compare B Event 1 Int Enable
       EPwm6Regs.TZEINT.bit.DCBEVT2             = 0;          // Digital Compare B Event 2 Int Enable
     */
    EPwm6Regs.TZEINT.all = (EPwm6Regs.TZEINT.all & ~0x7E) | 0x0;

    /*	// Digital Compare A Control Register
       EPwm6Regs.DCACTL.bit.EVT1SYNCE           = 0;          // DCAEVT1 SYNC Enable
       EPwm6Regs.DCACTL.bit.EVT1SOCE            = 1;          // DCAEVT1 SOC Enable
       EPwm6Regs.DCACTL.bit.EVT1FRCSYNCSEL      = 0;          // DCAEVT1 Force Sync Signal
       EPwm6Regs.DCACTL.bit.EVT1SRCSEL          = 0;          // DCAEVT1 Source Signal
       EPwm6Regs.DCACTL.bit.EVT2FRCSYNCSEL      = 0;          // DCAEVT2 Force Sync Signal
       EPwm6Regs.DCACTL.bit.EVT2SRCSEL          = 0;          // DCAEVT2 Source Signal
     */
    EPwm6Regs.DCACTL.all = (EPwm6Regs.DCACTL.all & ~0x30F) | 0x4;

    /*	// Digital Compare B Control Register
       EPwm6Regs.DCBCTL.bit.EVT1SYNCE           = 0;          // DCBEVT1 SYNC Enable
       EPwm6Regs.DCBCTL.bit.EVT1SOCE            = 0;          // DCBEVT1 SOC Enable
       EPwm6Regs.DCBCTL.bit.EVT1FRCSYNCSEL      = 0;          // DCBEVT1 Force Sync Signal
       EPwm6Regs.DCBCTL.bit.EVT1SRCSEL          = 0;          // DCBEVT1 Source Signal
       EPwm6Regs.DCBCTL.bit.EVT2FRCSYNCSEL      = 0;          // DCBEVT2 Force Sync Signal
       EPwm6Regs.DCBCTL.bit.EVT2SRCSEL          = 0;          // DCBEVT2 Source Signal
     */
    EPwm6Regs.DCBCTL.all = (EPwm6Regs.DCBCTL.all & ~0x30F) | 0x0;

    /*	// Digital Compare Trip Select Register
       EPwm6Regs.DCTRIPSEL.bit.DCAHCOMPSEL      = 0;          // Digital Compare A High COMP Input Select

       EPwm6Regs.DCTRIPSEL.bit.DCALCOMPSEL      = 1;          // Digital Compare A Low COMP Input Select
       EPwm6Regs.DCTRIPSEL.bit.DCBHCOMPSEL      = 0;          // Digital Compare B High COMP Input Select
       EPwm6Regs.DCTRIPSEL.bit.DCBLCOMPSEL      = 1;          // Digital Compare B Low COMP Input Select

     */
    EPwm6Regs.DCTRIPSEL.all = (EPwm6Regs.DCTRIPSEL.all & ~ 0xFFFF) | 0x1010;

    /*	// Trip Zone Digital Comparator Select Register
       EPwm6Regs.TZDCSEL.bit.DCAEVT1            = 0;          // Digital Compare Output A Event 1
       EPwm6Regs.TZDCSEL.bit.DCAEVT2            = 0;          // Digital Compare Output A Event 2
       EPwm6Regs.TZDCSEL.bit.DCBEVT1            = 0;          // Digital Compare Output B Event 1
       EPwm6Regs.TZDCSEL.bit.DCBEVT2            = 0;          // Digital Compare Output B Event 2
     */
    EPwm6Regs.TZDCSEL.all = (EPwm6Regs.TZDCSEL.all & ~0xFFF) | 0x0;

    /*	// Digital Compare Filter Control Register
       EPwm6Regs.DCFCTL.bit.BLANKE              = 0;          // Blanking Enable/Disable
       EPwm6Regs.DCFCTL.bit.PULSESEL            = 1;          // Pulse Select for Blanking & Capture Alignment
       EPwm6Regs.DCFCTL.bit.BLANKINV            = 0;          // Blanking Window Inversion
       EPwm6Regs.DCFCTL.bit.SRCSEL              = 0;          // Filter Block Signal Source Select
     */
    EPwm6Regs.DCFCTL.all = (EPwm6Regs.DCFCTL.all & ~0x3F) | 0x10;
    EPwm6Regs.DCFOFFSET = 0;           // Digital Compare Filter Offset Register
    EPwm6Regs.DCFWINDOW = 0;           // Digital Compare Filter Window Register

    /*	// Digital Compare Capture Control Register
       EPwm6Regs.DCCAPCTL.bit.CAPE              = 0;          // Counter Capture Enable
     */
    EPwm6Regs.DCCAPCTL.all = (EPwm6Regs.DCCAPCTL.all & ~0x1) | 0x0;

    /*	// HRPWM Configuration Register
       EPwm6Regs.HRCNFG.bit.SWAPAB              = 0;          // Swap EPWMA and EPWMB Outputs Bit
       EPwm6Regs.HRCNFG.bit.SELOUTB             = 0;          // EPWMB Output Selection Bit
     */
    EPwm6Regs.HRCNFG.all = (EPwm6Regs.HRCNFG.all & ~0xA0) | 0x0;

    /* Update the Link Registers with the link value for all the Compare values and TBPRD */
    /* No error is thrown if the ePWM register exists in the model or not */
    EPwm6Regs.EPWMXLINK.bit.TBPRDLINK = 5;
    EPwm6Regs.EPWMXLINK.bit.CMPALINK = 5;
    EPwm6Regs.EPWMXLINK.bit.CMPBLINK = 5;
    EPwm6Regs.EPWMXLINK.bit.CMPCLINK = 5;
    EPwm6Regs.EPWMXLINK.bit.CMPDLINK = 5;

    /* SYNCPER - Peripheral synchronization output event
       EPwm6Regs.HRPCTL.bit.PWMSYNCSEL            = 0;          // EPWMSYNCPER selection
       EPwm6Regs.HRPCTL.bit.PWMSYNCSELX           = 0;          //  EPWMSYNCPER selection
     */
    EPwm6Regs.HRPCTL.all = (EPwm6Regs.HRPCTL.all & ~0x72) | 0x0;
    EDIS;
  }

  /* Start for S-Function (c2802xpwm): '<S9>/ePWM' */

  /*** Initialize ePWM1 modules ***/
  {
    /*  // Time Base Control Register
       EPwm1Regs.TBCTL.bit.CTRMODE              = 2;          // Counter Mode
       EPwm1Regs.TBCTL.bit.SYNCOSEL             = 3;          // Sync Output Select
       EPwm1Regs.TBCTL2.bit.SYNCOSELX           = 0;          // Sync Output Select - additional options

       EPwm1Regs.TBCTL.bit.PRDLD                = 0;          // Shadow select

       EPwm1Regs.TBCTL2.bit.PRDLDSYNC           = 0;          // Shadow select

       EPwm1Regs.TBCTL.bit.PHSEN                = 0;          // Phase Load Enable
       EPwm1Regs.TBCTL.bit.PHSDIR               = 0;          // Phase Direction Bit
       EPwm1Regs.TBCTL.bit.HSPCLKDIV            = 0;          // High Speed TBCLK Pre-scaler
       EPwm1Regs.TBCTL.bit.CLKDIV               = 0;          // Time Base Clock Pre-scaler
       EPwm1Regs.TBCTL.bit.SWFSYNC              = 0;          // Software Force Sync Pulse
     */
    EPwm1Regs.TBCTL.all = (EPwm1Regs.TBCTL.all & ~0x3FFF) | 0x32;
    EPwm1Regs.TBCTL2.all = (EPwm1Regs.TBCTL2.all & ~0xF000) | 0x0;

    /*-- Setup Time-Base (TB) Submodule --*/
    EPwm1Regs.TBPRD = 10000;           // Time Base Period Register

    /* // Time-Base Phase Register
       EPwm1Regs.TBPHS.bit.TBPHS               = 0;          // Phase offset register
     */
    EPwm1Regs.TBPHS.all = (EPwm1Regs.TBPHS.all & ~0xFFFF0000) | 0x0;

    // Time Base Counter Register
    EPwm1Regs.TBCTR = 0x0000;          /* Clear counter*/

    /*-- Setup Counter_Compare (CC) Submodule --*/
    /*	// Counter Compare Control Register

       EPwm1Regs.CMPCTL.bit.LOADASYNC           = 0U;          // Active Compare A Load SYNC Option
       EPwm1Regs.CMPCTL.bit.LOADBSYNC           = 0U;          // Active Compare B Load SYNC Option
       EPwm1Regs.CMPCTL.bit.LOADAMODE           = 0U;          // Active Compare A Load
       EPwm1Regs.CMPCTL.bit.LOADBMODE           = 0U;          // Active Compare B Load
       EPwm1Regs.CMPCTL.bit.SHDWAMODE           = 0;          // Compare A Register Block Operating Mode
       EPwm1Regs.CMPCTL.bit.SHDWBMODE           = 0;          // Compare B Register Block Operating Mode
     */
    EPwm1Regs.CMPCTL.all = (EPwm1Regs.CMPCTL.all & ~0x3C5F) | 0x0;

    /* EPwm1Regs.CMPCTL2.bit.SHDWCMODE           = 0;          // Compare C Register Block Operating Mode
       EPwm1Regs.CMPCTL2.bit.SHDWDMODE           = 0;          // Compare D Register Block Operating Mode
       EPwm1Regs.CMPCTL2.bit.LOADCSYNC           = 0U;          // Active Compare C Load SYNC Option
       EPwm1Regs.CMPCTL2.bit.LOADDSYNC           = 0U;          // Active Compare D Load SYNC Option
       EPwm1Regs.CMPCTL2.bit.LOADCMODE           = 0U;          // Active Compare C Load
       EPwm1Regs.CMPCTL2.bit.LOADDMODE           = 0U;          // Active Compare D Load
     */
    EPwm1Regs.CMPCTL2.all = (EPwm1Regs.CMPCTL2.all & ~0x3C5F) | 0x0;
    EPwm1Regs.CMPA.bit.CMPA = 32000;   // Counter Compare A Register
    EPwm1Regs.CMPB.bit.CMPB = 32000;   // Counter Compare B Register
    EPwm1Regs.CMPC = 32000;            // Counter Compare C Register
    EPwm1Regs.CMPD = 32000;            // Counter Compare D Register

    /*-- Setup Action-Qualifier (AQ) Submodule --*/
    EPwm1Regs.AQCTLA.all = 150;// Action Qualifier Control Register For Output A
    EPwm1Regs.AQCTLB.all = 2310;
                               // Action Qualifier Control Register For Output B

    /*	// Action Qualifier Software Force Register
       EPwm1Regs.AQSFRC.bit.RLDCSF              = 0;          // Reload from Shadow Options
     */
    EPwm1Regs.AQSFRC.all = (EPwm1Regs.AQSFRC.all & ~0xC0) | 0x0;

    /*	// Action Qualifier Continuous S/W Force Register
       EPwm1Regs.AQCSFRC.bit.CSFA               = 0;          // Continuous Software Force on output A
       EPwm1Regs.AQCSFRC.bit.CSFB               = 0;          // Continuous Software Force on output B
     */
    EPwm1Regs.AQCSFRC.all = (EPwm1Regs.AQCSFRC.all & ~0xF) | 0x0;

    /*-- Setup Dead-Band Generator (DB) Submodule --*/
    /*	// Dead-Band Generator Control Register
       EPwm1Regs.DBCTL.bit.OUT_MODE             = 0;          // Dead Band Output Mode Control
       EPwm1Regs.DBCTL.bit.IN_MODE              = 0;          // Dead Band Input Select Mode Control
       EPwm1Regs.DBCTL.bit.POLSEL               = 0;          // Polarity Select Control
       EPwm1Regs.DBCTL.bit.HALFCYCLE            = 0;          // Half Cycle Clocking Enable
       EPwm1Regs.DBCTL.bit.SHDWDBREDMODE        = 0;          // DBRED shadow mode
       EPwm1Regs.DBCTL.bit.SHDWDBFEDMODE        = 0;          // DBFED shadow mode
       EPwm1Regs.DBCTL.bit.LOADREDMODE          = 4U;        // DBRED load
       EPwm1Regs.DBCTL.bit.LOADFEDMODE          = 4U;        // DBFED load
     */
    EPwm1Regs.DBCTL.all = (EPwm1Regs.DBCTL.all & ~0x8FFF) | 0x0;
    EPwm1Regs.DBRED.bit.DBRED = 0;
                         // Dead-Band Generator Rising Edge Delay Count Register
    EPwm1Regs.DBFED.bit.DBFED = 0;
                        // Dead-Band Generator Falling Edge Delay Count Register

    /*-- Setup Event-Trigger (ET) Submodule --*/
    /*	// Event Trigger Selection and Pre-Scale Register
       EPwm1Regs.ETSEL.bit.SOCAEN               = 1;          // Start of Conversion A Enable
       EPwm1Regs.ETSEL.bit.SOCASELCMP           = 0;
       EPwm1Regs.ETSEL.bit.SOCASEL              = 3;          // Start of Conversion A Select
       EPwm1Regs.ETPS.bit.SOCPSSEL              = 1;          // EPWM1SOC Period Select
       EPwm1Regs.ETSOCPS.bit.SOCAPRD2           = 1;
       EPwm1Regs.ETSEL.bit.SOCBEN               = 0;          // Start of Conversion B Enable
       EPwm1Regs.ETSEL.bit.SOCBSELCMP           = 0;
       EPwm1Regs.ETSEL.bit.SOCBSEL              = 1;          // Start of Conversion A Select
       EPwm1Regs.ETPS.bit.SOCPSSEL              = 1;          // EPWM1SOCB Period Select
       EPwm1Regs.ETSOCPS.bit.SOCBPRD2           = 1;
       EPwm1Regs.ETSEL.bit.INTEN                = 0;          // EPWM1INTn Enable
       EPwm1Regs.ETSEL.bit.INTSELCMP            = 0;
       EPwm1Regs.ETSEL.bit.INTSEL               = 1;          // Start of Conversion A Select
       EPwm1Regs.ETPS.bit.INTPSSEL              = 1;          // EPWM1INTn Period Select
       EPwm1Regs.ETINTPS.bit.INTPRD2            = 1;
     */
    EPwm1Regs.ETSEL.all = (EPwm1Regs.ETSEL.all & ~0xFF7F) | 0x1B01;
    EPwm1Regs.ETPS.all = (EPwm1Regs.ETPS.all & ~0x30) | 0x30;
    EPwm1Regs.ETSOCPS.all = (EPwm1Regs.ETSOCPS.all & ~0xF0F) | 0x101;
    EPwm1Regs.ETINTPS.all = (EPwm1Regs.ETINTPS.all & ~0xF) | 0x1;

    /*-- Setup PWM-Chopper (PC) Submodule --*/
    /*	// PWM Chopper Control Register
       EPwm1Regs.PCCTL.bit.CHPEN                = 0;          // PWM chopping enable
       EPwm1Regs.PCCTL.bit.CHPFREQ              = 0;          // Chopping clock frequency
       EPwm1Regs.PCCTL.bit.OSHTWTH              = 0;          // One-shot pulse width
       EPwm1Regs.PCCTL.bit.CHPDUTY              = 0;          // Chopping clock Duty cycle
     */
    EPwm1Regs.PCCTL.all = (EPwm1Regs.PCCTL.all & ~0x7FF) | 0x0;

    /*-- Set up Trip-Zone (TZ) Submodule --*/
    EALLOW;
    EPwm1Regs.TZSEL.all = 0;           // Trip Zone Select Register

    /*	// Trip Zone Control Register
       EPwm1Regs.TZCTL.bit.TZA                  = 3;          // TZ1 to TZ6 Trip Action On EPWM1A
       EPwm1Regs.TZCTL.bit.TZB                  = 3;          // TZ1 to TZ6 Trip Action On EPWM1B
       EPwm1Regs.TZCTL.bit.DCAEVT1              = 3;          // EPWM1A action on DCAEVT1
       EPwm1Regs.TZCTL.bit.DCAEVT2              = 3;          // EPWM1A action on DCAEVT2
       EPwm1Regs.TZCTL.bit.DCBEVT1              = 3;          // EPWM1B action on DCBEVT1
       EPwm1Regs.TZCTL.bit.DCBEVT2              = 3;          // EPWM1B action on DCBEVT2
     */
    EPwm1Regs.TZCTL.all = (EPwm1Regs.TZCTL.all & ~0xFFF) | 0xFFF;

    /*	// Trip Zone Enable Interrupt Register
       EPwm1Regs.TZEINT.bit.OST                 = 0;          // Trip Zones One Shot Int Enable
       EPwm1Regs.TZEINT.bit.CBC                 = 0;          // Trip Zones Cycle By Cycle Int Enable
       EPwm1Regs.TZEINT.bit.DCAEVT1             = 0;          // Digital Compare A Event 1 Int Enable
       EPwm1Regs.TZEINT.bit.DCAEVT2             = 0;          // Digital Compare A Event 2 Int Enable
       EPwm1Regs.TZEINT.bit.DCBEVT1             = 0;          // Digital Compare B Event 1 Int Enable
       EPwm1Regs.TZEINT.bit.DCBEVT2             = 0;          // Digital Compare B Event 2 Int Enable
     */
    EPwm1Regs.TZEINT.all = (EPwm1Regs.TZEINT.all & ~0x7E) | 0x0;

    /*	// Digital Compare A Control Register
       EPwm1Regs.DCACTL.bit.EVT1SYNCE           = 0;          // DCAEVT1 SYNC Enable
       EPwm1Regs.DCACTL.bit.EVT1SOCE            = 1;          // DCAEVT1 SOC Enable
       EPwm1Regs.DCACTL.bit.EVT1FRCSYNCSEL      = 0;          // DCAEVT1 Force Sync Signal
       EPwm1Regs.DCACTL.bit.EVT1SRCSEL          = 0;          // DCAEVT1 Source Signal
       EPwm1Regs.DCACTL.bit.EVT2FRCSYNCSEL      = 0;          // DCAEVT2 Force Sync Signal
       EPwm1Regs.DCACTL.bit.EVT2SRCSEL          = 0;          // DCAEVT2 Source Signal
     */
    EPwm1Regs.DCACTL.all = (EPwm1Regs.DCACTL.all & ~0x30F) | 0x4;

    /*	// Digital Compare B Control Register
       EPwm1Regs.DCBCTL.bit.EVT1SYNCE           = 0;          // DCBEVT1 SYNC Enable
       EPwm1Regs.DCBCTL.bit.EVT1SOCE            = 0;          // DCBEVT1 SOC Enable
       EPwm1Regs.DCBCTL.bit.EVT1FRCSYNCSEL      = 0;          // DCBEVT1 Force Sync Signal
       EPwm1Regs.DCBCTL.bit.EVT1SRCSEL          = 0;          // DCBEVT1 Source Signal
       EPwm1Regs.DCBCTL.bit.EVT2FRCSYNCSEL      = 0;          // DCBEVT2 Force Sync Signal
       EPwm1Regs.DCBCTL.bit.EVT2SRCSEL          = 0;          // DCBEVT2 Source Signal
     */
    EPwm1Regs.DCBCTL.all = (EPwm1Regs.DCBCTL.all & ~0x30F) | 0x0;

    /*	// Digital Compare Trip Select Register
       EPwm1Regs.DCTRIPSEL.bit.DCAHCOMPSEL      = 0;          // Digital Compare A High COMP Input Select

       EPwm1Regs.DCTRIPSEL.bit.DCALCOMPSEL      = 1;          // Digital Compare A Low COMP Input Select
       EPwm1Regs.DCTRIPSEL.bit.DCBHCOMPSEL      = 0;          // Digital Compare B High COMP Input Select
       EPwm1Regs.DCTRIPSEL.bit.DCBLCOMPSEL      = 1;          // Digital Compare B Low COMP Input Select

     */
    EPwm1Regs.DCTRIPSEL.all = (EPwm1Regs.DCTRIPSEL.all & ~ 0xFFFF) | 0x1010;

    /*	// Trip Zone Digital Comparator Select Register
       EPwm1Regs.TZDCSEL.bit.DCAEVT1            = 0;          // Digital Compare Output A Event 1
       EPwm1Regs.TZDCSEL.bit.DCAEVT2            = 0;          // Digital Compare Output A Event 2
       EPwm1Regs.TZDCSEL.bit.DCBEVT1            = 0;          // Digital Compare Output B Event 1
       EPwm1Regs.TZDCSEL.bit.DCBEVT2            = 0;          // Digital Compare Output B Event 2
     */
    EPwm1Regs.TZDCSEL.all = (EPwm1Regs.TZDCSEL.all & ~0xFFF) | 0x0;

    /*	// Digital Compare Filter Control Register
       EPwm1Regs.DCFCTL.bit.BLANKE              = 0;          // Blanking Enable/Disable
       EPwm1Regs.DCFCTL.bit.PULSESEL            = 1;          // Pulse Select for Blanking & Capture Alignment
       EPwm1Regs.DCFCTL.bit.BLANKINV            = 0;          // Blanking Window Inversion
       EPwm1Regs.DCFCTL.bit.SRCSEL              = 0;          // Filter Block Signal Source Select
     */
    EPwm1Regs.DCFCTL.all = (EPwm1Regs.DCFCTL.all & ~0x3F) | 0x10;
    EPwm1Regs.DCFOFFSET = 0;           // Digital Compare Filter Offset Register
    EPwm1Regs.DCFWINDOW = 0;           // Digital Compare Filter Window Register

    /*	// Digital Compare Capture Control Register
       EPwm1Regs.DCCAPCTL.bit.CAPE              = 0;          // Counter Capture Enable
     */
    EPwm1Regs.DCCAPCTL.all = (EPwm1Regs.DCCAPCTL.all & ~0x1) | 0x0;

    /*	// HRPWM Configuration Register
       EPwm1Regs.HRCNFG.bit.SWAPAB              = 0;          // Swap EPWMA and EPWMB Outputs Bit
       EPwm1Regs.HRCNFG.bit.SELOUTB             = 0;          // EPWMB Output Selection Bit
     */
    EPwm1Regs.HRCNFG.all = (EPwm1Regs.HRCNFG.all & ~0xA0) | 0x0;

    /* Update the Link Registers with the link value for all the Compare values and TBPRD */
    /* No error is thrown if the ePWM register exists in the model or not */
    EPwm1Regs.EPWMXLINK.bit.TBPRDLINK = 0;
    EPwm1Regs.EPWMXLINK.bit.CMPALINK = 0;
    EPwm1Regs.EPWMXLINK.bit.CMPBLINK = 0;
    EPwm1Regs.EPWMXLINK.bit.CMPCLINK = 0;
    EPwm1Regs.EPWMXLINK.bit.CMPDLINK = 0;

    /* SYNCPER - Peripheral synchronization output event
       EPwm1Regs.HRPCTL.bit.PWMSYNCSEL            = 0;          // EPWMSYNCPER selection
       EPwm1Regs.HRPCTL.bit.PWMSYNCSELX           = 0;          //  EPWMSYNCPER selection
     */
    EPwm1Regs.HRPCTL.all = (EPwm1Regs.HRPCTL.all & ~0x72) | 0x0;
    EDIS;
    EALLOW;

    /* Enable TBCLK within the EPWM*/
    CpuSysRegs.PCLKCR0.bit.TBCLKSYNC = 1;
    EDIS;
  }

  /* SystemInitialize for MATLAB Function: '<S1>/MATLAB Function2' incorporates:
   *  SubSystem: '<S1>/offset mode'
   */
  /* InitializeConditions for UnitDelay: '<S10>/Unit Delay1' */
  dzwcontrol3_0_DW.UnitDelay1_DSTATE =
    dzwcontrol3_0_P.UnitDelay1_InitialCondition_m;

  /* InitializeConditions for UnitDelay: '<S10>/Unit Delay2' */
  dzwcontrol3_0_DW.UnitDelay2_DSTATE =
    dzwcontrol3_0_P.UnitDelay2_InitialCondition_p;

  /* InitializeConditions for UnitDelay: '<S10>/Unit Delay3' */
  dzwcontrol3_0_DW.UnitDelay3_DSTATE =
    dzwcontrol3_0_P.UnitDelay3_InitialCondition;

  /* InitializeConditions for UnitDelay: '<S10>/Unit Delay6' */
  dzwcontrol3_0_DW.UnitDelay6_DSTATE =
    dzwcontrol3_0_P.UnitDelay6_InitialCondition;

  /* SystemInitialize for Atomic SubSystem: '<S1>/1-phase LPF2' */
  /* InitializeConditions for UnitDelay: '<S4>/Unit Delay1' */
  dzwcontrol3_0_DW.UnitDelay1_DSTATE_k =
    dzwcontrol3_0_P.UnitDelay1_InitialCondition_e;

  /* InitializeConditions for UnitDelay: '<S4>/Unit Delay' */
  dzwcontrol3_0_DW.UnitDelay_DSTATE =
    dzwcontrol3_0_P.UnitDelay_InitialCondition_c;

  /* End of SystemInitialize for SubSystem: '<S1>/1-phase LPF2' */

  /* End of SystemInitialize for S-Function (c28xisr_c2000): '<Root>/C28x Hardware Interrupt' */

  /* SystemInitialize for Atomic SubSystem: '<Root>/Initialize Function' */

  /* Start for S-Function (c280xgpio_do): '<S3>/Low EN' */
  EALLOW;
  GpioCtrlRegs.GPCMUX2.all &= 0xFFFCFFFF;
  GpioCtrlRegs.GPCDIR.all |= 0x1000000;
  EDIS;

  /* Start for S-Function (c280xgpio_do): '<S3>/Up EN' */
  EALLOW;
  GpioCtrlRegs.GPCMUX2.all &= 0xFFFFCFFF;
  GpioCtrlRegs.GPCDIR.all |= 0x400000;
  EDIS;

  /* Start for S-Function (c280xgpio_do): '<S3>/Low EN2' */
  EALLOW;
  GpioCtrlRegs.GPCMUX2.all &= 0xFCFFFFFF;
  GpioCtrlRegs.GPCDIR.all |= 0x10000000;
  EDIS;

  /* Start for S-Function (c280xgpio_do): '<S3>/Up EN2' */
  EALLOW;
  GpioCtrlRegs.GPCMUX2.all &= 0xFFCFFFFF;
  GpioCtrlRegs.GPCDIR.all |= 0x4000000;
  EDIS;

  /* Start for S-Function (c280xgpio_do): '<S3>/Low EN3' */
  EALLOW;
  GpioCtrlRegs.GPDMUX2.all &= 0x3FFFFFFF;
  GpioCtrlRegs.GPDDIR.all |= 0x80000000;
  EDIS;

  /* Start for S-Function (c280xgpio_do): '<S3>/Up EN3' */
  EALLOW;
  GpioCtrlRegs.GPCMUX2.all &= 0xCFFFFFFF;
  GpioCtrlRegs.GPCDIR.all |= 0x40000000;
  EDIS;

  /* End of SystemInitialize for SubSystem: '<Root>/Initialize Function' */

  /* Outputs for Atomic SubSystem: '<Root>/Initialize Function' */
  /* DataStoreWrite: '<S3>/Data Store Write' incorporates:
   *  Constant: '<S3>/Constant1'
   */
  Enable = dzwcontrol3_0_P.Constant1_Value_ec;

  /* DataStoreWrite: '<S3>/Data Store Write1' incorporates:
   *  Constant: '<S3>/Constant2'
   */
  RST = dzwcontrol3_0_P.Constant2_Value;

  /* DataStoreWrite: '<S3>/Data Store Write2' incorporates:
   *  Constant: '<S3>/Constant3'
   */
  STOP = dzwcontrol3_0_P.Constant3_Value;

  /* DataStoreRead: '<S3>/Data Store Read3' incorporates:
   *  DataStoreRead: '<S3>/Data Store Read1'
   */
  dzwcontrol3_0_B.DataStoreRead3 = Enable;

  /* S-Function (c280xgpio_do): '<S3>/Low EN' */
  {
    if (dzwcontrol3_0_B.DataStoreRead3)
      GpioDataRegs.GPCSET.bit.GPIO88 = 1;
    else
      GpioDataRegs.GPCCLEAR.bit.GPIO88 = 1;
  }

  /* S-Function (c280xgpio_do): '<S3>/Up EN' */
  {
    if (dzwcontrol3_0_B.DataStoreRead3)
      GpioDataRegs.GPCSET.bit.GPIO86 = 1;
    else
      GpioDataRegs.GPCCLEAR.bit.GPIO86 = 1;
  }

  /* DataStoreRead: '<S3>/Data Store Read3' incorporates:
   *  DataStoreRead: '<S3>/Data Store Read2'
   */
  dzwcontrol3_0_B.DataStoreRead3 = Enable;

  /* S-Function (c280xgpio_do): '<S3>/Low EN2' */
  {
    if (dzwcontrol3_0_B.DataStoreRead3)
      GpioDataRegs.GPCSET.bit.GPIO92 = 1;
    else
      GpioDataRegs.GPCCLEAR.bit.GPIO92 = 1;
  }

  /* S-Function (c280xgpio_do): '<S3>/Up EN2' */
  {
    if (dzwcontrol3_0_B.DataStoreRead3)
      GpioDataRegs.GPCSET.bit.GPIO90 = 1;
    else
      GpioDataRegs.GPCCLEAR.bit.GPIO90 = 1;
  }

  /* DataStoreRead: '<S3>/Data Store Read3' */
  dzwcontrol3_0_B.DataStoreRead3 = Enable;

  /* S-Function (c280xgpio_do): '<S3>/Low EN3' */
  {
    if (dzwcontrol3_0_B.DataStoreRead3)
      GpioDataRegs.GPDSET.bit.GPIO127 = 1;
    else
      GpioDataRegs.GPDCLEAR.bit.GPIO127 = 1;
  }

  /* S-Function (c280xgpio_do): '<S3>/Up EN3' */
  {
    if (dzwcontrol3_0_B.DataStoreRead3)
      GpioDataRegs.GPCSET.bit.GPIO94 = 1;
    else
      GpioDataRegs.GPCCLEAR.bit.GPIO94 = 1;
  }

  /* End of Outputs for SubSystem: '<Root>/Initialize Function' */
}

/* Model terminate function */
void dzwcontrol3_0_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
