/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: dzwcontrol3_0.h
 *
 * Code generated for Simulink model 'dzwcontrol3_0'.
 *
 * Model version                  : 1.41
 * Simulink Coder version         : 9.4 (R2020b) 29-Jul-2020
 * C/C++ source code generated on : Fri Feb  7 17:21:12 2025
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Texas Instruments->C2000
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_dzwcontrol3_0_h_
#define RTW_HEADER_dzwcontrol3_0_h_
#include <float.h>
#include <math.h>
#include <stddef.h>
#include <string.h>
#ifndef dzwcontrol3_0_COMMON_INCLUDES_
#define dzwcontrol3_0_COMMON_INCLUDES_
#include <IQmathLib.h>
#include "rtwtypes.h"
#include "c2000BoardSupport.h"
#include "F2837xD_device.h"
#include "F2837xD_gpio.h"
#include "F2837xD_Examples.h"
#include "IQmathLib.h"
#endif                                 /* dzwcontrol3_0_COMMON_INCLUDES_ */

#include "dzwcontrol3_0_types.h"
#include "MW_target_hardware_resources.h"
#include "IQmathLib.h"
#include "rt_nonfinite.h"
#include "rtGetInf.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

extern void config_ePWM_GPIO (void);

/* Block signals (default storage) */
typedef struct {
  real32_T Fcn;                        /* '<S34>/Fcn' */
  real32_T Fcn1;                       /* '<S34>/Fcn1' */
  real32_T Fcn_e;                      /* '<S33>/Fcn' */
  real32_T Fcn1_m;                     /* '<S33>/Fcn1' */
  real32_T Fcn_d;                      /* '<S27>/Fcn' */
  real32_T Fcn1_e;                     /* '<S27>/Fcn1' */
  real32_T Fcn_f;                      /* '<S26>/Fcn' */
  real32_T Fcn1_o;                     /* '<S26>/Fcn1' */
  real32_T Fcn_h;                      /* '<S52>/Fcn' */
  real32_T Fcn1_b;                     /* '<S52>/Fcn1' */
  real32_T Fcn_b;                      /* '<S51>/Fcn' */
  real32_T Fcn1_g;                     /* '<S51>/Fcn1' */
  real32_T Fcn_i;                      /* '<S43>/Fcn' */
  real32_T Fcn1_n;                     /* '<S43>/Fcn1' */
  real32_T Fcn_g;                      /* '<S42>/Fcn' */
  real32_T Fcn1_h;                     /* '<S42>/Fcn1' */
  real32_T Fcn_dz;                     /* '<S68>/Fcn' */
  real32_T Fcn1_d;                     /* '<S68>/Fcn1' */
  real32_T Fcn_c;                      /* '<S67>/Fcn' */
  real32_T Fcn1_ep;                    /* '<S67>/Fcn1' */
  real32_T Fcn_bd;                     /* '<S59>/Fcn' */
  real32_T Fcn1_j;                     /* '<S59>/Fcn1' */
  real32_T Fcn_i0;                     /* '<S58>/Fcn' */
  real32_T Fcn1_ng;                    /* '<S58>/Fcn1' */
  int32_T RampControl_o1;              /* '<S16>/Ramp Control' */
  int32_T RampControl_o1_h;            /* '<S17>/Ramp Control' */
  int32_T RampControl_o2;              /* '<S16>/Ramp Control' */
  int32_T RampControl_o2_a;            /* '<S17>/Ramp Control' */
  uint16_T ADC4;                       /* '<S1>/ADC4' */
  uint16_T ADC;                        /* '<S1>/ADC' */
  uint16_T ADC1;                       /* '<S1>/ADC1' */
  uint16_T ADC2;                       /* '<S1>/ADC2' */
  uint16_T ADC3;                       /* '<S1>/ADC3' */
  uint16_T ADC5;                       /* '<S1>/ADC5' */
  uint16_T ADC6;                       /* '<S1>/ADC6' */
  uint16_T ADC7;                       /* '<S1>/ADC7' */
  uint16_T DataStoreRead3;             /* '<S3>/Data Store Read3' */
  uint16_T DataStoreRead2;             /* '<S6>/Data Store Read2' */
} B_dzwcontrol3_0_T;

/* Block states (default storage) for system '<Root>' */
typedef struct {
  real_T UnitDelay1_DSTATE;            /* '<S10>/Unit Delay1' */
  real_T UnitDelay2_DSTATE;            /* '<S10>/Unit Delay2' */
  real_T UnitDelay3_DSTATE;            /* '<S10>/Unit Delay3' */
  real_T UnitDelay6_DSTATE;            /* '<S10>/Unit Delay6' */
  real_T UnitDelay2_DSTATE_c;          /* '<S30>/Unit Delay2' */
  real_T UnitDelay1_DSTATE_j;          /* '<S28>/Unit Delay1' */
  real_T count;                        /* '<S1>/MATLAB Function2' */
  real32_T UnitDelay1_DSTATE_e;        /* '<S21>/Unit Delay1' */
  real32_T UnitDelay1_DSTATE_o;        /* '<S30>/Unit Delay1' */
  real32_T UnitDelay2_DSTATE_k;        /* '<S28>/Unit Delay2' */
  real32_T UnitDelay1_DSTATE_k;        /* '<S4>/Unit Delay1' */
  real32_T UnitDelay_DSTATE;           /* '<S4>/Unit Delay' */
  int32_T UnitDelay_DSTATE_o;          /* '<S38>/Unit Delay' */
  int32_T UnitDelay_DSTATE_ot;         /* '<S54>/Unit Delay' */
  int32_T RampControl_RAMP_DLY_CNTL;   /* '<S16>/Ramp Control' */
  int32_T RampControl_PREV_SETPOINT;   /* '<S16>/Ramp Control' */
  int32_T RampControl_RAMP_DLY_CNTL_k; /* '<S17>/Ramp Control' */
  int32_T RampControl_PREV_SETPOINT_b; /* '<S17>/Ramp Control' */
} DW_dzwcontrol3_0_T;

/* Parameters for system: '<S53>/Subsystem - pi//2 delay' */
struct P_Subsystempi2delay_dzwcontro_T_ {
  real32_T dq_Y0[2];                   /* Computed Parameter: dq_Y0
                                        * Referenced by: '<S58>/dq'
                                        */
};

/* Parameters for system: '<S53>/Subsystem1' */
struct P_Subsystem1_dzwcontrol3_0_T_ {
  real32_T dq_Y0[2];                   /* Computed Parameter: dq_Y0
                                        * Referenced by: '<S59>/dq'
                                        */
};

/* Parameters for system: '<S55>/Subsystem - pi//2 delay' */
struct P_Subsystempi2delay_dzwcont_o_T_ {
  real32_T alpha_beta_Y0[2];           /* Computed Parameter: alpha_beta_Y0
                                        * Referenced by: '<S67>/alpha_beta'
                                        */
};

/* Parameters for system: '<S55>/Subsystem1' */
struct P_Subsystem1_dzwcontrol3_0_e_T_ {
  real32_T alpha_beta_Y0[2];           /* Computed Parameter: alpha_beta_Y0
                                        * Referenced by: '<S68>/alpha_beta'
                                        */
};

/* Parameters (default storage) */
struct P_dzwcontrol3_0_T_ {
  real_T sample;                       /* Variable: sample
                                        * Referenced by:
                                        *   '<S10>/Gain1'
                                        *   '<S10>/Gain12'
                                        *   '<S10>/Gain2'
                                        *   '<S10>/Gain3'
                                        *   '<S10>/Gain4'
                                        *   '<S10>/Gain5'
                                        *   '<S10>/Gain6'
                                        *   '<S10>/Gain7'
                                        */
  real32_T Ts;                         /* Variable: Ts
                                        * Referenced by:
                                        *   '<S19>/Gain'
                                        *   '<S20>/Gain'
                                        *   '<S36>/Gain'
                                        *   '<S37>/Gain'
                                        */
  real32_T Udc;                        /* Variable: Udc
                                        * Referenced by:
                                        *   '<S70>/Constant4'
                                        *   '<S19>/Saturation'
                                        *   '<S19>/Saturation1'
                                        *   '<S20>/Saturation'
                                        *   '<S20>/Saturation1'
                                        *   '<S36>/Saturation'
                                        *   '<S36>/Saturation1'
                                        *   '<S37>/Saturation'
                                        *   '<S37>/Saturation1'
                                        */
  real_T AlphaBetaZerotodq0_Alignment;
                                 /* Mask Parameter: AlphaBetaZerotodq0_Alignment
                                  * Referenced by: '<S53>/Constant'
                                  */
  real_T dq0toAlphaBetaZero_Alignment;
                                 /* Mask Parameter: dq0toAlphaBetaZero_Alignment
                                  * Referenced by: '<S55>/Constant'
                                  */
  real_T AlphaBetaZerotodq0_Alignment_j;
                               /* Mask Parameter: AlphaBetaZerotodq0_Alignment_j
                                * Referenced by: '<S35>/Constant'
                                */
  real_T dq0toAlphaBetaZero_Alignment_o;
                               /* Mask Parameter: dq0toAlphaBetaZero_Alignment_o
                                * Referenced by: '<S39>/Constant'
                                */
  real_T AlphaBetaZerotodq0_Alignment_m;
                               /* Mask Parameter: AlphaBetaZerotodq0_Alignment_m
                                * Referenced by: '<S18>/Constant'
                                */
  real_T dq0toAlphaBetaZero_Alignment_a;
                               /* Mask Parameter: dq0toAlphaBetaZero_Alignment_a
                                * Referenced by: '<S23>/Constant'
                                */
  real_T CompareToConstant_const;     /* Mask Parameter: CompareToConstant_const
                                       * Referenced by: '<S56>/Constant'
                                       */
  real_T CompareToConstant1_const;   /* Mask Parameter: CompareToConstant1_const
                                      * Referenced by: '<S57>/Constant'
                                      */
  real_T CompareToConstant_const_i; /* Mask Parameter: CompareToConstant_const_i
                                     * Referenced by: '<S65>/Constant'
                                     */
  real_T CompareToConstant1_const_c;
                                   /* Mask Parameter: CompareToConstant1_const_c
                                    * Referenced by: '<S66>/Constant'
                                    */
  real_T CompareToConstant_const_o; /* Mask Parameter: CompareToConstant_const_o
                                     * Referenced by: '<S40>/Constant'
                                     */
  real_T CompareToConstant1_const_d;
                                   /* Mask Parameter: CompareToConstant1_const_d
                                    * Referenced by: '<S41>/Constant'
                                    */
  real_T CompareToConstant_const_k; /* Mask Parameter: CompareToConstant_const_k
                                     * Referenced by: '<S49>/Constant'
                                     */
  real_T CompareToConstant1_const_g;
                                   /* Mask Parameter: CompareToConstant1_const_g
                                    * Referenced by: '<S50>/Constant'
                                    */
  real_T CompareToConstant_const_l; /* Mask Parameter: CompareToConstant_const_l
                                     * Referenced by: '<S24>/Constant'
                                     */
  real_T CompareToConstant1_const_cv;
                                  /* Mask Parameter: CompareToConstant1_const_cv
                                   * Referenced by: '<S25>/Constant'
                                   */
  real_T CompareToConstant_const_c; /* Mask Parameter: CompareToConstant_const_c
                                     * Referenced by: '<S31>/Constant'
                                     */
  real_T CompareToConstant1_const_l;
                                   /* Mask Parameter: CompareToConstant1_const_l
                                    * Referenced by: '<S32>/Constant'
                                    */
  real_T Constant_Value;               /* Expression: 2
                                        * Referenced by: '<S4>/Constant'
                                        */
  real_T Constant1_Value;              /* Expression: 1
                                        * Referenced by: '<S4>/Constant1'
                                        */
  real_T Constant_Value_n;             /* Expression: 3
                                        * Referenced by: '<S5>/Constant'
                                        */
  real_T Gain_Gain;                    /* Expression: 2
                                        * Referenced by: '<S30>/Gain'
                                        */
  real_T Gain2_Gain;                   /* Expression: 1e-6
                                        * Referenced by: '<S30>/Gain2'
                                        */
  real_T UnitDelay2_InitialCondition;  /* Expression: 0
                                        * Referenced by: '<S30>/Unit Delay2'
                                        */
  real_T Gain3_Gain;                   /* Expression: 2
                                        * Referenced by: '<S30>/Gain3'
                                        */
  real_T Gain4_Gain;                   /* Expression: 1/2
                                        * Referenced by: '<S30>/Gain4'
                                        */
  real_T Saturation3_UpperSat;         /* Expression: 12000
                                        * Referenced by: '<S30>/Saturation3'
                                        */
  real_T Saturation3_LowerSat;         /* Expression: -12000
                                        * Referenced by: '<S30>/Saturation3'
                                        */
  real_T Saturation1_UpperSat;         /* Expression: 12000
                                        * Referenced by: '<S30>/Saturation1'
                                        */
  real_T Saturation1_LowerSat;         /* Expression: -12000
                                        * Referenced by: '<S30>/Saturation1'
                                        */
  real_T Gain_Gain_d;                  /* Expression: 1/(2*pi)
                                        * Referenced by: '<S14>/Gain'
                                        */
  real_T Gain1_Gain;                   /* Expression: 1e-6
                                        * Referenced by: '<S28>/Gain1'
                                        */
  real_T UnitDelay1_InitialCondition;  /* Expression: 0
                                        * Referenced by: '<S28>/Unit Delay1'
                                        */
  real_T Gain2_Gain_m;                 /* Expression: 1e-6
                                        * Referenced by: '<S28>/Gain2'
                                        */
  real_T UnitDelay1_InitialCondition_m;/* Expression: 0
                                        * Referenced by: '<S10>/Unit Delay1'
                                        */
  real_T UnitDelay2_InitialCondition_p;/* Expression: 0
                                        * Referenced by: '<S10>/Unit Delay2'
                                        */
  real_T UnitDelay3_InitialCondition;  /* Expression: 0
                                        * Referenced by: '<S10>/Unit Delay3'
                                        */
  real_T UnitDelay6_InitialCondition;  /* Expression: 0
                                        * Referenced by: '<S10>/Unit Delay6'
                                        */
  real_T Constant_Value_l;             /* Expression: 2
                                        * Referenced by: '<S10>/Constant'
                                        */
  real_T Constant_Value_m;             /* Expression: 1
                                        * Referenced by: '<S11>/Constant'
                                        */
  real_T Constant2_Value;              /* Expression: 1
                                        * Referenced by: '<S3>/Constant2'
                                        */
  real_T Constant3_Value;              /* Expression: 0
                                        * Referenced by: '<S3>/Constant3'
                                        */
  real_T DataStoreMemory_InitialValue; /* Expression: 0
                                        * Referenced by: '<Root>/Data Store Memory'
                                        */
  real_T DataStoreMemory14_InitialValue;/* Expression: 5000
                                         * Referenced by: '<Root>/Data Store Memory14'
                                         */
  real_T DataStoreMemory3_InitialValue;/* Expression: 0
                                        * Referenced by: '<Root>/Data Store Memory3'
                                        */
  real_T DataStoreMemory1_InitialValue;/* Expression: 0
                                        * Referenced by: '<Root>/Data Store Memory1'
                                        */
  real_T DataStoreMemory13_InitialValue;/* Expression: 0
                                         * Referenced by: '<Root>/Data Store Memory13'
                                         */
  real_T DataStoreMemory23_InitialValue;/* Expression: 0
                                         * Referenced by: '<Root>/Data Store Memory23'
                                         */
  int32_T UnitDelay_InitialCondition;
                               /* Computed Parameter: UnitDelay_InitialCondition
                                * Referenced by: '<S54>/Unit Delay'
                                */
  int32_T u_Value;                     /* Computed Parameter: u_Value
                                        * Referenced by: '<S61>/1'
                                        */
  int32_T u_Value_j;                   /* Computed Parameter: u_Value_j
                                        * Referenced by: '<S61>/-1'
                                        */
  int32_T Constant_Value_f;            /* Computed Parameter: Constant_Value_f
                                        * Referenced by: '<S17>/Constant'
                                        */
  int32_T Constant1_Value_f;           /* Computed Parameter: Constant1_Value_f
                                        * Referenced by: '<S17>/Constant1'
                                        */
  int32_T u_Value_a;                   /* Computed Parameter: u_Value_a
                                        * Referenced by: '<S62>/1'
                                        */
  int32_T u_Value_g;                   /* Computed Parameter: u_Value_g
                                        * Referenced by: '<S62>/-1'
                                        */
  int32_T UnitDelay_InitialCondition_i;
                             /* Computed Parameter: UnitDelay_InitialCondition_i
                              * Referenced by: '<S38>/Unit Delay'
                              */
  int32_T u_Value_n;                   /* Computed Parameter: u_Value_n
                                        * Referenced by: '<S45>/1'
                                        */
  int32_T u_Value_e;                   /* Computed Parameter: u_Value_e
                                        * Referenced by: '<S45>/-1'
                                        */
  int32_T Constant_Value_b;            /* Computed Parameter: Constant_Value_b
                                        * Referenced by: '<S16>/Constant'
                                        */
  int32_T Constant1_Value_e;           /* Computed Parameter: Constant1_Value_e
                                        * Referenced by: '<S16>/Constant1'
                                        */
  int32_T u_Value_i;                   /* Computed Parameter: u_Value_i
                                        * Referenced by: '<S46>/1'
                                        */
  int32_T u_Value_nq;                  /* Computed Parameter: u_Value_nq
                                        * Referenced by: '<S46>/-1'
                                        */
  real32_T UnitDelay1_InitialCondition_e;
                            /* Computed Parameter: UnitDelay1_InitialCondition_e
                             * Referenced by: '<S4>/Unit Delay1'
                             */
  real32_T UnitDelay_InitialCondition_c;
                             /* Computed Parameter: UnitDelay_InitialCondition_c
                              * Referenced by: '<S4>/Unit Delay'
                              */
  real32_T Constant1_Value_g;          /* Computed Parameter: Constant1_Value_g
                                        * Referenced by: '<S5>/Constant1'
                                        */
  real32_T Constant3_Value_n;          /* Computed Parameter: Constant3_Value_n
                                        * Referenced by: '<S5>/Constant3'
                                        */
  real32_T Constant2_Value_o;          /* Computed Parameter: Constant2_Value_o
                                        * Referenced by: '<S5>/Constant2'
                                        */
  real32_T Gain3_Gain_m[9];            /* Computed Parameter: Gain3_Gain_m
                                        * Referenced by: '<S13>/Gain3'
                                        */
  real32_T Gain1_Gain_d;               /* Computed Parameter: Gain1_Gain_d
                                        * Referenced by: '<S13>/Gain1'
                                        */
  real32_T Constant4_Value;            /* Computed Parameter: Constant4_Value
                                        * Referenced by: '<S5>/Constant4'
                                        */
  real32_T Gain_Gain_e;                /* Computed Parameter: Gain_Gain_e
                                        * Referenced by: '<S17>/Gain'
                                        */
  real32_T Gain_Gain_f;                /* Computed Parameter: Gain_Gain_f
                                        * Referenced by: '<S16>/Gain'
                                        */
  real32_T Saturation_LowerSat;       /* Computed Parameter: Saturation_LowerSat
                                       * Referenced by: '<S36>/Saturation'
                                       */
  real32_T Saturation1_LowerSat_p; /* Computed Parameter: Saturation1_LowerSat_p
                                    * Referenced by: '<S36>/Saturation1'
                                    */
  real32_T Saturation_LowerSat_n;   /* Computed Parameter: Saturation_LowerSat_n
                                     * Referenced by: '<S37>/Saturation'
                                     */
  real32_T Saturation1_LowerSat_a; /* Computed Parameter: Saturation1_LowerSat_a
                                    * Referenced by: '<S37>/Saturation1'
                                    */
  real32_T UnitDelay1_InitialCondition_f;
                            /* Computed Parameter: UnitDelay1_InitialCondition_f
                             * Referenced by: '<S21>/Unit Delay1'
                             */
  real32_T Gain3_Gain_g[9];            /* Computed Parameter: Gain3_Gain_g
                                        * Referenced by: '<S22>/Gain3'
                                        */
  real32_T Gain1_Gain_h;               /* Computed Parameter: Gain1_Gain_h
                                        * Referenced by: '<S22>/Gain1'
                                        */
  real32_T Gain1_Gain_p;               /* Computed Parameter: Gain1_Gain_p
                                        * Referenced by: '<S30>/Gain1'
                                        */
  real32_T UnitDelay1_InitialCondition_fb;
                           /* Computed Parameter: UnitDelay1_InitialCondition_fb
                            * Referenced by: '<S30>/Unit Delay1'
                            */
  real32_T UnitDelay2_InitialCondition_j;
                            /* Computed Parameter: UnitDelay2_InitialCondition_j
                             * Referenced by: '<S28>/Unit Delay2'
                             */
  real32_T Gain3_Gain_c;               /* Computed Parameter: Gain3_Gain_c
                                        * Referenced by: '<S28>/Gain3'
                                        */
  real32_T Gain4_Gain_b;               /* Computed Parameter: Gain4_Gain_b
                                        * Referenced by: '<S28>/Gain4'
                                        */
  real32_T Constant1_Value_n;          /* Computed Parameter: Constant1_Value_n
                                        * Referenced by: '<S28>/Constant1'
                                        */
  real32_T Saturation_LowerSat_e;   /* Computed Parameter: Saturation_LowerSat_e
                                     * Referenced by: '<S19>/Saturation'
                                     */
  real32_T Saturation1_LowerSat_k; /* Computed Parameter: Saturation1_LowerSat_k
                                    * Referenced by: '<S19>/Saturation1'
                                    */
  real32_T Saturation_LowerSat_o;   /* Computed Parameter: Saturation_LowerSat_o
                                     * Referenced by: '<S20>/Saturation'
                                     */
  real32_T Saturation1_LowerSat_f; /* Computed Parameter: Saturation1_LowerSat_f
                                    * Referenced by: '<S20>/Saturation1'
                                    */
  real32_T Constant2_Value_b;          /* Computed Parameter: Constant2_Value_b
                                        * Referenced by: '<S73>/Constant2'
                                        */
  real32_T Constant3_Value_m;          /* Computed Parameter: Constant3_Value_m
                                        * Referenced by: '<S73>/Constant3'
                                        */
  real32_T A_Threshold;                /* Computed Parameter: A_Threshold
                                        * Referenced by: '<S75>/A'
                                        */
  real32_T Gain_Gain_fd;               /* Computed Parameter: Gain_Gain_fd
                                        * Referenced by: '<S75>/Gain'
                                        */
  real32_T Gain3_Gain_p;               /* Computed Parameter: Gain3_Gain_p
                                        * Referenced by: '<S75>/Gain3'
                                        */
  real32_T B_Threshold;                /* Computed Parameter: B_Threshold
                                        * Referenced by: '<S75>/B'
                                        */
  real32_T C_Threshold;                /* Computed Parameter: C_Threshold
                                        * Referenced by: '<S75>/C'
                                        */
  real32_T Constant_Value_i;           /* Computed Parameter: Constant_Value_i
                                        * Referenced by: '<S70>/Constant'
                                        */
  real32_T Gain_Gain_a;                /* Computed Parameter: Gain_Gain_a
                                        * Referenced by: '<S73>/Gain'
                                        */
  real32_T Gain2_Gain_n;               /* Computed Parameter: Gain2_Gain_n
                                        * Referenced by: '<S73>/Gain2'
                                        */
  real32_T Gain1_Gain_j;               /* Computed Parameter: Gain1_Gain_j
                                        * Referenced by: '<S73>/Gain1'
                                        */
  real32_T Switch3_Threshold;          /* Computed Parameter: Switch3_Threshold
                                        * Referenced by: '<S73>/Switch3'
                                        */
  real32_T Switch4_Threshold;          /* Computed Parameter: Switch4_Threshold
                                        * Referenced by: '<S73>/Switch4'
                                        */
  real32_T Switch5_Threshold;          /* Computed Parameter: Switch5_Threshold
                                        * Referenced by: '<S73>/Switch5'
                                        */
  real32_T Gain2_Gain_d;               /* Computed Parameter: Gain2_Gain_d
                                        * Referenced by: '<S72>/Gain2'
                                        */
  real32_T Gain_Gain_l;                /* Computed Parameter: Gain_Gain_l
                                        * Referenced by: '<S72>/Gain'
                                        */
  real32_T Gain1_Gain_jd;              /* Computed Parameter: Gain1_Gain_jd
                                        * Referenced by: '<S72>/Gain1'
                                        */
  real32_T Constant2_Value_a;          /* Computed Parameter: Constant2_Value_a
                                        * Referenced by: '<S1>/Constant2'
                                        */
  real32_T Constant1_Value_f1;         /* Computed Parameter: Constant1_Value_f1
                                        * Referenced by: '<S1>/Constant1'
                                        */
  real32_T Constant_Value_c;           /* Computed Parameter: Constant_Value_c
                                        * Referenced by: '<S1>/Constant'
                                        */
  real32_T DataStoreMemory16_InitialValue;
                           /* Computed Parameter: DataStoreMemory16_InitialValue
                            * Referenced by: '<Root>/Data Store Memory16'
                            */
  real32_T DataStoreMemory20_InitialValue;
                           /* Computed Parameter: DataStoreMemory20_InitialValue
                            * Referenced by: '<Root>/Data Store Memory20'
                            */
  real32_T DataStoreMemory26_InitialValue;
                           /* Computed Parameter: DataStoreMemory26_InitialValue
                            * Referenced by: '<Root>/Data Store Memory26'
                            */
  real32_T DataStoreMemory27_InitialValue;
                           /* Computed Parameter: DataStoreMemory27_InitialValue
                            * Referenced by: '<Root>/Data Store Memory27'
                            */
  real32_T DataStoreMemory52_InitialValue;
                           /* Computed Parameter: DataStoreMemory52_InitialValue
                            * Referenced by: '<Root>/Data Store Memory52'
                            */
  real32_T DataStoreMemory15_InitialValue;
                           /* Computed Parameter: DataStoreMemory15_InitialValue
                            * Referenced by: '<Root>/Data Store Memory15'
                            */
  real32_T DataStoreMemory17_InitialValue;
                           /* Computed Parameter: DataStoreMemory17_InitialValue
                            * Referenced by: '<Root>/Data Store Memory17'
                            */
  real32_T DataStoreMemory18_InitialValue;
                           /* Computed Parameter: DataStoreMemory18_InitialValue
                            * Referenced by: '<Root>/Data Store Memory18'
                            */
  real32_T DataStoreMemory19_InitialValue;
                           /* Computed Parameter: DataStoreMemory19_InitialValue
                            * Referenced by: '<Root>/Data Store Memory19'
                            */
  real32_T DataStoreMemory24_InitialValue;
                           /* Computed Parameter: DataStoreMemory24_InitialValue
                            * Referenced by: '<Root>/Data Store Memory24'
                            */
  real32_T DataStoreMemory25_InitialValue;
                           /* Computed Parameter: DataStoreMemory25_InitialValue
                            * Referenced by: '<Root>/Data Store Memory25'
                            */
  real32_T DataStoreMemory28_InitialValue;
                           /* Computed Parameter: DataStoreMemory28_InitialValue
                            * Referenced by: '<Root>/Data Store Memory28'
                            */
  real32_T DataStoreMemory29_InitialValue;
                           /* Computed Parameter: DataStoreMemory29_InitialValue
                            * Referenced by: '<Root>/Data Store Memory29'
                            */
  real32_T DataStoreMemory30_InitialValue;
                           /* Computed Parameter: DataStoreMemory30_InitialValue
                            * Referenced by: '<Root>/Data Store Memory30'
                            */
  real32_T DataStoreMemory31_InitialValue;
                           /* Computed Parameter: DataStoreMemory31_InitialValue
                            * Referenced by: '<Root>/Data Store Memory31'
                            */
  real32_T DataStoreMemory32_InitialValue;
                           /* Computed Parameter: DataStoreMemory32_InitialValue
                            * Referenced by: '<Root>/Data Store Memory32'
                            */
  real32_T DataStoreMemory33_InitialValue;
                           /* Computed Parameter: DataStoreMemory33_InitialValue
                            * Referenced by: '<Root>/Data Store Memory33'
                            */
  real32_T DataStoreMemory34_InitialValue;
                           /* Computed Parameter: DataStoreMemory34_InitialValue
                            * Referenced by: '<Root>/Data Store Memory34'
                            */
  real32_T DataStoreMemory35_InitialValue;
                           /* Computed Parameter: DataStoreMemory35_InitialValue
                            * Referenced by: '<Root>/Data Store Memory35'
                            */
  real32_T DataStoreMemory36_InitialValue;
                           /* Computed Parameter: DataStoreMemory36_InitialValue
                            * Referenced by: '<Root>/Data Store Memory36'
                            */
  real32_T DataStoreMemory37_InitialValue;
                           /* Computed Parameter: DataStoreMemory37_InitialValue
                            * Referenced by: '<Root>/Data Store Memory37'
                            */
  real32_T DataStoreMemory38_InitialValue;
                           /* Computed Parameter: DataStoreMemory38_InitialValue
                            * Referenced by: '<Root>/Data Store Memory38'
                            */
  real32_T DataStoreMemory39_InitialValue;
                           /* Computed Parameter: DataStoreMemory39_InitialValue
                            * Referenced by: '<Root>/Data Store Memory39'
                            */
  real32_T DataStoreMemory40_InitialValue;
                           /* Computed Parameter: DataStoreMemory40_InitialValue
                            * Referenced by: '<Root>/Data Store Memory40'
                            */
  real32_T DataStoreMemory41_InitialValue;
                           /* Computed Parameter: DataStoreMemory41_InitialValue
                            * Referenced by: '<Root>/Data Store Memory41'
                            */
  real32_T DataStoreMemory42_InitialValue;
                           /* Computed Parameter: DataStoreMemory42_InitialValue
                            * Referenced by: '<Root>/Data Store Memory42'
                            */
  real32_T DataStoreMemory43_InitialValue;
                           /* Computed Parameter: DataStoreMemory43_InitialValue
                            * Referenced by: '<Root>/Data Store Memory43'
                            */
  real32_T DataStoreMemory44_InitialValue;
                           /* Computed Parameter: DataStoreMemory44_InitialValue
                            * Referenced by: '<Root>/Data Store Memory44'
                            */
  real32_T DataStoreMemory45_InitialValue;
                           /* Computed Parameter: DataStoreMemory45_InitialValue
                            * Referenced by: '<Root>/Data Store Memory45'
                            */
  real32_T DataStoreMemory46_InitialValue;
                           /* Computed Parameter: DataStoreMemory46_InitialValue
                            * Referenced by: '<Root>/Data Store Memory46'
                            */
  real32_T DataStoreMemory50_InitialValue;
                           /* Computed Parameter: DataStoreMemory50_InitialValue
                            * Referenced by: '<Root>/Data Store Memory50'
                            */
  real32_T DataStoreMemory51_InitialValue;
                           /* Computed Parameter: DataStoreMemory51_InitialValue
                            * Referenced by: '<Root>/Data Store Memory51'
                            */
  real32_T DataStoreMemory8_InitialValue;
                            /* Computed Parameter: DataStoreMemory8_InitialValue
                             * Referenced by: '<Root>/Data Store Memory8'
                             */
  uint32_T Saturation_UpperSat;       /* Computed Parameter: Saturation_UpperSat
                                       * Referenced by: '<S75>/Saturation'
                                       */
  uint32_T Saturation_LowerSat_ov; /* Computed Parameter: Saturation_LowerSat_ov
                                    * Referenced by: '<S75>/Saturation'
                                    */
  uint16_T Gain2_Gain_a;               /* Computed Parameter: Gain2_Gain_a
                                        * Referenced by: '<S75>/Gain2'
                                        */
  uint16_T Gain1_Gain_l;               /* Computed Parameter: Gain1_Gain_l
                                        * Referenced by: '<S75>/Gain1'
                                        */
  uint16_T Constant_Value_by;          /* Computed Parameter: Constant_Value_by
                                        * Referenced by: '<S15>/Constant'
                                        */
  uint16_T Constant2_Value_d;          /* Computed Parameter: Constant2_Value_d
                                        * Referenced by: '<S17>/Constant2'
                                        */
  uint16_T Constant2_Value_l;          /* Computed Parameter: Constant2_Value_l
                                        * Referenced by: '<S16>/Constant2'
                                        */
  uint16_T Constant2_Value_f;          /* Computed Parameter: Constant2_Value_f
                                        * Referenced by: '<S14>/Constant2'
                                        */
  uint16_T Constant2_Value_m;          /* Computed Parameter: Constant2_Value_m
                                        * Referenced by: '<S75>/Constant2'
                                        */
  uint16_T Constant3_Value_h;          /* Computed Parameter: Constant3_Value_h
                                        * Referenced by: '<S75>/Constant3'
                                        */
  uint16_T Constant4_Value_d;          /* Computed Parameter: Constant4_Value_d
                                        * Referenced by: '<S75>/Constant4'
                                        */
  uint16_T Constant5_Value;            /* Computed Parameter: Constant5_Value
                                        * Referenced by: '<S75>/Constant5'
                                        */
  uint16_T Constant6_Value;            /* Computed Parameter: Constant6_Value
                                        * Referenced by: '<S75>/Constant6'
                                        */
  uint16_T Constant7_Value;            /* Computed Parameter: Constant7_Value
                                        * Referenced by: '<S75>/Constant7'
                                        */
  uint16_T Constant_Value_h;           /* Computed Parameter: Constant_Value_h
                                        * Referenced by: '<S75>/Constant'
                                        */
  uint16_T Constant1_Value_i;          /* Computed Parameter: Constant1_Value_i
                                        * Referenced by: '<S75>/Constant1'
                                        */
  uint16_T Constant1_Value_ec;         /* Computed Parameter: Constant1_Value_ec
                                        * Referenced by: '<S3>/Constant1'
                                        */
  uint16_T DataStoreMemory10_InitialValue;
                           /* Computed Parameter: DataStoreMemory10_InitialValue
                            * Referenced by: '<Root>/Data Store Memory10'
                            */
  uint16_T DataStoreMemory11_InitialValue;
                           /* Computed Parameter: DataStoreMemory11_InitialValue
                            * Referenced by: '<Root>/Data Store Memory11'
                            */
  uint16_T DataStoreMemory12_InitialValue;
                           /* Computed Parameter: DataStoreMemory12_InitialValue
                            * Referenced by: '<Root>/Data Store Memory12'
                            */
  uint16_T DataStoreMemory2_InitialValue;
                            /* Computed Parameter: DataStoreMemory2_InitialValue
                             * Referenced by: '<Root>/Data Store Memory2'
                             */
  uint16_T DataStoreMemory21_InitialValue;
                           /* Computed Parameter: DataStoreMemory21_InitialValue
                            * Referenced by: '<Root>/Data Store Memory21'
                            */
  uint16_T DataStoreMemory22_InitialValue;
                           /* Computed Parameter: DataStoreMemory22_InitialValue
                            * Referenced by: '<Root>/Data Store Memory22'
                            */
  uint16_T DataStoreMemory4_InitialValue;
                            /* Computed Parameter: DataStoreMemory4_InitialValue
                             * Referenced by: '<Root>/Data Store Memory4'
                             */
  uint16_T DataStoreMemory47_InitialValue;
                           /* Computed Parameter: DataStoreMemory47_InitialValue
                            * Referenced by: '<Root>/Data Store Memory47'
                            */
  uint16_T DataStoreMemory48_InitialValue;
                           /* Computed Parameter: DataStoreMemory48_InitialValue
                            * Referenced by: '<Root>/Data Store Memory48'
                            */
  uint16_T DataStoreMemory49_InitialValue;
                           /* Computed Parameter: DataStoreMemory49_InitialValue
                            * Referenced by: '<Root>/Data Store Memory49'
                            */
  uint16_T DataStoreMemory5_InitialValue;
                            /* Computed Parameter: DataStoreMemory5_InitialValue
                             * Referenced by: '<Root>/Data Store Memory5'
                             */
  uint16_T DataStoreMemory6_InitialValue;
                            /* Computed Parameter: DataStoreMemory6_InitialValue
                             * Referenced by: '<Root>/Data Store Memory6'
                             */
  uint16_T DataStoreMemory7_InitialValue;
                            /* Computed Parameter: DataStoreMemory7_InitialValue
                             * Referenced by: '<Root>/Data Store Memory7'
                             */
  uint16_T DataStoreMemory9_InitialValue;
                            /* Computed Parameter: DataStoreMemory9_InitialValue
                             * Referenced by: '<Root>/Data Store Memory9'
                             */
  P_Subsystem1_dzwcontrol3_0_e_T Subsystem1_f;/* '<S23>/Subsystem1' */
  P_Subsystempi2delay_dzwcont_o_T Subsystempi2delay_b;/* '<S23>/Subsystem - pi//2 delay' */
  P_Subsystem1_dzwcontrol3_0_T Subsystem1_c;/* '<S18>/Subsystem1' */
  P_Subsystempi2delay_dzwcontro_T Subsystempi2delay_m;/* '<S18>/Subsystem - pi//2 delay' */
  P_Subsystem1_dzwcontrol3_0_e_T Subsystem1_m;/* '<S39>/Subsystem1' */
  P_Subsystempi2delay_dzwcont_o_T Subsystempi2delay_i;/* '<S39>/Subsystem - pi//2 delay' */
  P_Subsystem1_dzwcontrol3_0_T Subsystem1_n;/* '<S35>/Subsystem1' */
  P_Subsystempi2delay_dzwcontro_T Subsystempi2delay_p;/* '<S35>/Subsystem - pi//2 delay' */
  P_Subsystem1_dzwcontrol3_0_e_T Subsystem1_l;/* '<S55>/Subsystem1' */
  P_Subsystempi2delay_dzwcont_o_T Subsystempi2delay_l;/* '<S55>/Subsystem - pi//2 delay' */
  P_Subsystem1_dzwcontrol3_0_T Subsystem1;/* '<S53>/Subsystem1' */
  P_Subsystempi2delay_dzwcontro_T Subsystempi2delay;/* '<S53>/Subsystem - pi//2 delay' */
};

/* Real-time Model Data Structure */
struct tag_RTM_dzwcontrol3_0_T {
  const char_T *errorStatus;
};

/* Block parameters (default storage) */
extern P_dzwcontrol3_0_T dzwcontrol3_0_P;

/* Block signals (default storage) */
extern B_dzwcontrol3_0_T dzwcontrol3_0_B;

/* Block states (default storage) */
extern DW_dzwcontrol3_0_T dzwcontrol3_0_DW;

/*
 * Exported States
 *
 * Note: Exported states are block states with an exported global
 * storage class designation.  Code generation will declare the memory for these
 * states and exports their symbols.
 *
 */
extern real_T B;                       /* '<Root>/Data Store Memory' */
extern real_T dutycycle;               /* '<Root>/Data Store Memory14' */
extern real_T C;                       /* '<Root>/Data Store Memory3' */
extern real_T A;                       /* '<Root>/Data Store Memory1' */
extern real_T STOP;                    /* '<Root>/Data Store Memory13' */
extern real_T RST;                     /* '<Root>/Data Store Memory23' */
extern real32_T tran_parameter;        /* '<Root>/Data Store Memory16' */
extern real32_T IE_ref;                /* '<Root>/Data Store Memory20' */
extern real32_T IntegralE;             /* '<Root>/Data Store Memory26' */
extern real32_T UE;                    /* '<Root>/Data Store Memory27' */
extern real32_T PLL_rou;               /* '<Root>/Data Store Memory52' */
extern real32_T DC_Bus;                /* '<Root>/Data Store Memory15' */
extern real32_T Current_F;             /* '<Root>/Data Store Memory17' */
extern real32_T Current_E;             /* '<Root>/Data Store Memory18' */
extern real32_T Current_D;             /* '<Root>/Data Store Memory19' */
extern real32_T KpE;                   /* '<Root>/Data Store Memory24' */
extern real32_T KiE;                   /* '<Root>/Data Store Memory25' */
extern real32_T Current_alpha;         /* '<Root>/Data Store Memory28' */
extern real32_T Current_beta;          /* '<Root>/Data Store Memory29' */
extern real32_T VF_Frq;                /* '<Root>/Data Store Memory30' */
extern real32_T Theta;                 /* '<Root>/Data Store Memory31' */
extern real32_T Idfbk;                 /* '<Root>/Data Store Memory32' */
extern real32_T Iqfbk;                 /* '<Root>/Data Store Memory33' */
extern real32_T Idref;                 /* '<Root>/Data Store Memory34' */
extern real32_T Iqref;                 /* '<Root>/Data Store Memory35' */
extern real32_T Integrald;             /* '<Root>/Data Store Memory36' */
extern real32_T Integralq;             /* '<Root>/Data Store Memory37' */
extern real32_T Uq;                    /* '<Root>/Data Store Memory38' */
extern real32_T Ud;                    /* '<Root>/Data Store Memory39' */
extern real32_T Ubeta;                 /* '<Root>/Data Store Memory40' */
extern real32_T Ualpha;                /* '<Root>/Data Store Memory41' */
extern real32_T Uqref;                 /* '<Root>/Data Store Memory42' */
extern real32_T Udref;                 /* '<Root>/Data Store Memory43' */
extern real32_T T2;                    /* '<Root>/Data Store Memory44' */
extern real32_T T1;                    /* '<Root>/Data Store Memory45' */
extern real32_T T3;                    /* '<Root>/Data Store Memory46' */
extern real32_T threephase_Theta;      /* '<Root>/Data Store Memory50' */
extern real32_T threephase_Frq;        /* '<Root>/Data Store Memory51' */
extern real32_T Bus_Data;              /* '<Root>/Data Store Memory8' */
extern uint16_T E_offset;              /* '<Root>/Data Store Memory10' */
extern uint16_T F_offset;              /* '<Root>/Data Store Memory11' */
extern uint16_T A_Data;                /* '<Root>/Data Store Memory12' */
extern uint16_T Enable;                /* '<Root>/Data Store Memory2' */
extern uint16_T ControlMode;           /* '<Root>/Data Store Memory21' */
extern uint16_T Stop;                  /* '<Root>/Data Store Memory22' */
extern uint16_T D_Data;                /* '<Root>/Data Store Memory4' */
extern uint16_T D_V_Data;              /* '<Root>/Data Store Memory47' */
extern uint16_T E_V_Data;              /* '<Root>/Data Store Memory48' */
extern uint16_T F_V_Data;              /* '<Root>/Data Store Memory49' */
extern uint16_T E_Data;                /* '<Root>/Data Store Memory5' */
extern uint16_T F_Data;                /* '<Root>/Data Store Memory6' */
extern uint16_T Bus_offset;            /* '<Root>/Data Store Memory7' */
extern uint16_T D_offset;              /* '<Root>/Data Store Memory9' */

/* Model entry point functions */
extern void dzwcontrol3_0_initialize(void);
extern void dzwcontrol3_0_terminate(void);
extern volatile boolean_T runModel;

/* Real-time Model object */
extern RT_MODEL_dzwcontrol3_0_T *const dzwcontrol3_0_M;
extern volatile boolean_T stopRequested;
extern volatile boolean_T runModel;

/*-
 * These blocks were eliminated from the model due to optimizations:
 *
 * Block '<S48>/Data Type Duplicate' : Unused code path elimination
 * Block '<S64>/Data Type Duplicate' : Unused code path elimination
 * Block '<S48>/Conversion' : Eliminate redundant data type conversion
 * Block '<S64>/Conversion' : Eliminate redundant data type conversion
 * Block '<S9>/Data Type Conversion7' : Eliminate redundant data type conversion
 */

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'dzwcontrol3_0'
 * '<S1>'   : 'dzwcontrol3_0/ADC interrupt'
 * '<S2>'   : 'dzwcontrol3_0/Function-Call Subsystem'
 * '<S3>'   : 'dzwcontrol3_0/Initialize Function'
 * '<S4>'   : 'dzwcontrol3_0/ADC interrupt/1-phase LPF2'
 * '<S5>'   : 'dzwcontrol3_0/ADC interrupt/Adctransfer_and_protect'
 * '<S6>'   : 'dzwcontrol3_0/ADC interrupt/Enable'
 * '<S7>'   : 'dzwcontrol3_0/ADC interrupt/MATLAB Function2'
 * '<S8>'   : 'dzwcontrol3_0/ADC interrupt/Mode control'
 * '<S9>'   : 'dzwcontrol3_0/ADC interrupt/Triggered Subsystem'
 * '<S10>'  : 'dzwcontrol3_0/ADC interrupt/offset mode'
 * '<S11>'  : 'dzwcontrol3_0/ADC interrupt/pwm=0'
 * '<S12>'  : 'dzwcontrol3_0/ADC interrupt/Adctransfer_and_protect/MATLAB Function1'
 * '<S13>'  : 'dzwcontrol3_0/ADC interrupt/Adctransfer_and_protect/abc to Alpha-Beta-Zero1'
 * '<S14>'  : 'dzwcontrol3_0/ADC interrupt/Mode control/DC-bus control mode'
 * '<S15>'  : 'dzwcontrol3_0/ADC interrupt/Mode control/Standby&Protect'
 * '<S16>'  : 'dzwcontrol3_0/ADC interrupt/Mode control/Three-phase current loop test'
 * '<S17>'  : 'dzwcontrol3_0/ADC interrupt/Mode control/VF-mode'
 * '<S18>'  : 'dzwcontrol3_0/ADC interrupt/Mode control/DC-bus control mode/Alpha-Beta-Zero to dq0'
 * '<S19>'  : 'dzwcontrol3_0/ADC interrupt/Mode control/DC-bus control mode/PID_Id '
 * '<S20>'  : 'dzwcontrol3_0/ADC interrupt/Mode control/DC-bus control mode/PID_Iq 1'
 * '<S21>'  : 'dzwcontrol3_0/ADC interrupt/Mode control/DC-bus control mode/PLL'
 * '<S22>'  : 'dzwcontrol3_0/ADC interrupt/Mode control/DC-bus control mode/abc to Alpha-Beta-Zero'
 * '<S23>'  : 'dzwcontrol3_0/ADC interrupt/Mode control/DC-bus control mode/dq0 to Alpha-Beta-Zero'
 * '<S24>'  : 'dzwcontrol3_0/ADC interrupt/Mode control/DC-bus control mode/Alpha-Beta-Zero to dq0/Compare To Constant'
 * '<S25>'  : 'dzwcontrol3_0/ADC interrupt/Mode control/DC-bus control mode/Alpha-Beta-Zero to dq0/Compare To Constant1'
 * '<S26>'  : 'dzwcontrol3_0/ADC interrupt/Mode control/DC-bus control mode/Alpha-Beta-Zero to dq0/Subsystem - pi//2 delay'
 * '<S27>'  : 'dzwcontrol3_0/ADC interrupt/Mode control/DC-bus control mode/Alpha-Beta-Zero to dq0/Subsystem1'
 * '<S28>'  : 'dzwcontrol3_0/ADC interrupt/Mode control/DC-bus control mode/PLL/Integrator'
 * '<S29>'  : 'dzwcontrol3_0/ADC interrupt/Mode control/DC-bus control mode/PLL/MATLAB Function'
 * '<S30>'  : 'dzwcontrol3_0/ADC interrupt/Mode control/DC-bus control mode/PLL/PI '
 * '<S31>'  : 'dzwcontrol3_0/ADC interrupt/Mode control/DC-bus control mode/dq0 to Alpha-Beta-Zero/Compare To Constant'
 * '<S32>'  : 'dzwcontrol3_0/ADC interrupt/Mode control/DC-bus control mode/dq0 to Alpha-Beta-Zero/Compare To Constant1'
 * '<S33>'  : 'dzwcontrol3_0/ADC interrupt/Mode control/DC-bus control mode/dq0 to Alpha-Beta-Zero/Subsystem - pi//2 delay'
 * '<S34>'  : 'dzwcontrol3_0/ADC interrupt/Mode control/DC-bus control mode/dq0 to Alpha-Beta-Zero/Subsystem1'
 * '<S35>'  : 'dzwcontrol3_0/ADC interrupt/Mode control/Three-phase current loop test/Alpha-Beta-Zero to dq0'
 * '<S36>'  : 'dzwcontrol3_0/ADC interrupt/Mode control/Three-phase current loop test/PID_Id '
 * '<S37>'  : 'dzwcontrol3_0/ADC interrupt/Mode control/Three-phase current loop test/PID_Iq 1'
 * '<S38>'  : 'dzwcontrol3_0/ADC interrupt/Mode control/Three-phase current loop test/Ramp Generator'
 * '<S39>'  : 'dzwcontrol3_0/ADC interrupt/Mode control/Three-phase current loop test/dq0 to Alpha-Beta-Zero'
 * '<S40>'  : 'dzwcontrol3_0/ADC interrupt/Mode control/Three-phase current loop test/Alpha-Beta-Zero to dq0/Compare To Constant'
 * '<S41>'  : 'dzwcontrol3_0/ADC interrupt/Mode control/Three-phase current loop test/Alpha-Beta-Zero to dq0/Compare To Constant1'
 * '<S42>'  : 'dzwcontrol3_0/ADC interrupt/Mode control/Three-phase current loop test/Alpha-Beta-Zero to dq0/Subsystem - pi//2 delay'
 * '<S43>'  : 'dzwcontrol3_0/ADC interrupt/Mode control/Three-phase current loop test/Alpha-Beta-Zero to dq0/Subsystem1'
 * '<S44>'  : 'dzwcontrol3_0/ADC interrupt/Mode control/Three-phase current loop test/Ramp Generator/Convert Param To fix-pt with floor  rounding mode'
 * '<S45>'  : 'dzwcontrol3_0/ADC interrupt/Mode control/Three-phase current loop test/Ramp Generator/Subsystem'
 * '<S46>'  : 'dzwcontrol3_0/ADC interrupt/Mode control/Three-phase current loop test/Ramp Generator/Subsystem1'
 * '<S47>'  : 'dzwcontrol3_0/ADC interrupt/Mode control/Three-phase current loop test/Ramp Generator/Convert Param To fix-pt with floor  rounding mode/Embedded MATLAB Function'
 * '<S48>'  : 'dzwcontrol3_0/ADC interrupt/Mode control/Three-phase current loop test/Ramp Generator/Subsystem/Data Type Conversion Inherited'
 * '<S49>'  : 'dzwcontrol3_0/ADC interrupt/Mode control/Three-phase current loop test/dq0 to Alpha-Beta-Zero/Compare To Constant'
 * '<S50>'  : 'dzwcontrol3_0/ADC interrupt/Mode control/Three-phase current loop test/dq0 to Alpha-Beta-Zero/Compare To Constant1'
 * '<S51>'  : 'dzwcontrol3_0/ADC interrupt/Mode control/Three-phase current loop test/dq0 to Alpha-Beta-Zero/Subsystem - pi//2 delay'
 * '<S52>'  : 'dzwcontrol3_0/ADC interrupt/Mode control/Three-phase current loop test/dq0 to Alpha-Beta-Zero/Subsystem1'
 * '<S53>'  : 'dzwcontrol3_0/ADC interrupt/Mode control/VF-mode/Alpha-Beta-Zero to dq0'
 * '<S54>'  : 'dzwcontrol3_0/ADC interrupt/Mode control/VF-mode/Ramp Generator'
 * '<S55>'  : 'dzwcontrol3_0/ADC interrupt/Mode control/VF-mode/dq0 to Alpha-Beta-Zero'
 * '<S56>'  : 'dzwcontrol3_0/ADC interrupt/Mode control/VF-mode/Alpha-Beta-Zero to dq0/Compare To Constant'
 * '<S57>'  : 'dzwcontrol3_0/ADC interrupt/Mode control/VF-mode/Alpha-Beta-Zero to dq0/Compare To Constant1'
 * '<S58>'  : 'dzwcontrol3_0/ADC interrupt/Mode control/VF-mode/Alpha-Beta-Zero to dq0/Subsystem - pi//2 delay'
 * '<S59>'  : 'dzwcontrol3_0/ADC interrupt/Mode control/VF-mode/Alpha-Beta-Zero to dq0/Subsystem1'
 * '<S60>'  : 'dzwcontrol3_0/ADC interrupt/Mode control/VF-mode/Ramp Generator/Convert Param To fix-pt with floor  rounding mode'
 * '<S61>'  : 'dzwcontrol3_0/ADC interrupt/Mode control/VF-mode/Ramp Generator/Subsystem'
 * '<S62>'  : 'dzwcontrol3_0/ADC interrupt/Mode control/VF-mode/Ramp Generator/Subsystem1'
 * '<S63>'  : 'dzwcontrol3_0/ADC interrupt/Mode control/VF-mode/Ramp Generator/Convert Param To fix-pt with floor  rounding mode/Embedded MATLAB Function'
 * '<S64>'  : 'dzwcontrol3_0/ADC interrupt/Mode control/VF-mode/Ramp Generator/Subsystem/Data Type Conversion Inherited'
 * '<S65>'  : 'dzwcontrol3_0/ADC interrupt/Mode control/VF-mode/dq0 to Alpha-Beta-Zero/Compare To Constant'
 * '<S66>'  : 'dzwcontrol3_0/ADC interrupt/Mode control/VF-mode/dq0 to Alpha-Beta-Zero/Compare To Constant1'
 * '<S67>'  : 'dzwcontrol3_0/ADC interrupt/Mode control/VF-mode/dq0 to Alpha-Beta-Zero/Subsystem - pi//2 delay'
 * '<S68>'  : 'dzwcontrol3_0/ADC interrupt/Mode control/VF-mode/dq0 to Alpha-Beta-Zero/Subsystem1'
 * '<S69>'  : 'dzwcontrol3_0/ADC interrupt/Triggered Subsystem/MATLAB Function1'
 * '<S70>'  : 'dzwcontrol3_0/ADC interrupt/Triggered Subsystem/SVPWM2'
 * '<S71>'  : 'dzwcontrol3_0/ADC interrupt/Triggered Subsystem/SVPWM2/Subsystem'
 * '<S72>'  : 'dzwcontrol3_0/ADC interrupt/Triggered Subsystem/SVPWM2/TaTbTc'
 * '<S73>'  : 'dzwcontrol3_0/ADC interrupt/Triggered Subsystem/SVPWM2/Tx Ty1'
 * '<S74>'  : 'dzwcontrol3_0/ADC interrupt/Triggered Subsystem/SVPWM2/XYZ'
 * '<S75>'  : 'dzwcontrol3_0/ADC interrupt/Triggered Subsystem/SVPWM2/&#x3B1;&#x3B2; // N'
 */
#endif                                 /* RTW_HEADER_dzwcontrol3_0_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
