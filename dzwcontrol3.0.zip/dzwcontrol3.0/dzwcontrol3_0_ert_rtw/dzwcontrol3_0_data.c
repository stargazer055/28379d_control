/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: dzwcontrol3_0_data.c
 *
 * Code generated for Simulink model 'dzwcontrol3_0'.
 *
 * Model version                  : 1.41
 * Simulink Coder version         : 9.4 (R2020b) 29-Jul-2020
 * C/C++ source code generated on : Fri Feb  7 17:21:12 2025
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Texas Instruments->C2000
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "dzwcontrol3_0.h"
#include "dzwcontrol3_0_private.h"

/* Block parameters (default storage) */
P_dzwcontrol3_0_T dzwcontrol3_0_P = {
  /* Variable: sample
   * Referenced by:
   *   '<S10>/Gain1'
   *   '<S10>/Gain12'
   *   '<S10>/Gain2'
   *   '<S10>/Gain3'
   *   '<S10>/Gain4'
   *   '<S10>/Gain5'
   *   '<S10>/Gain6'
   *   '<S10>/Gain7'
   */
  0.0001,

  /* Variable: Ts
   * Referenced by:
   *   '<S19>/Gain'
   *   '<S20>/Gain'
   *   '<S36>/Gain'
   *   '<S37>/Gain'
   */
  0.0001F,

  /* Variable: Udc
   * Referenced by:
   *   '<S70>/Constant4'
   *   '<S19>/Saturation'
   *   '<S19>/Saturation1'
   *   '<S20>/Saturation'
   *   '<S20>/Saturation1'
   *   '<S36>/Saturation'
   *   '<S36>/Saturation1'
   *   '<S37>/Saturation'
   *   '<S37>/Saturation1'
   */
  30.0F,

  /* Mask Parameter: AlphaBetaZerotodq0_Alignment
   * Referenced by: '<S53>/Constant'
   */
  1.0,

  /* Mask Parameter: dq0toAlphaBetaZero_Alignment
   * Referenced by: '<S55>/Constant'
   */
  1.0,

  /* Mask Parameter: AlphaBetaZerotodq0_Alignment_j
   * Referenced by: '<S35>/Constant'
   */
  1.0,

  /* Mask Parameter: dq0toAlphaBetaZero_Alignment_o
   * Referenced by: '<S39>/Constant'
   */
  1.0,

  /* Mask Parameter: AlphaBetaZerotodq0_Alignment_m
   * Referenced by: '<S18>/Constant'
   */
  1.0,

  /* Mask Parameter: dq0toAlphaBetaZero_Alignment_a
   * Referenced by: '<S23>/Constant'
   */
  1.0,

  /* Mask Parameter: CompareToConstant_const
   * Referenced by: '<S56>/Constant'
   */
  1.0,

  /* Mask Parameter: CompareToConstant1_const
   * Referenced by: '<S57>/Constant'
   */
  2.0,

  /* Mask Parameter: CompareToConstant_const_i
   * Referenced by: '<S65>/Constant'
   */
  1.0,

  /* Mask Parameter: CompareToConstant1_const_c
   * Referenced by: '<S66>/Constant'
   */
  2.0,

  /* Mask Parameter: CompareToConstant_const_o
   * Referenced by: '<S40>/Constant'
   */
  1.0,

  /* Mask Parameter: CompareToConstant1_const_d
   * Referenced by: '<S41>/Constant'
   */
  2.0,

  /* Mask Parameter: CompareToConstant_const_k
   * Referenced by: '<S49>/Constant'
   */
  1.0,

  /* Mask Parameter: CompareToConstant1_const_g
   * Referenced by: '<S50>/Constant'
   */
  2.0,

  /* Mask Parameter: CompareToConstant_const_l
   * Referenced by: '<S24>/Constant'
   */
  1.0,

  /* Mask Parameter: CompareToConstant1_const_cv
   * Referenced by: '<S25>/Constant'
   */
  2.0,

  /* Mask Parameter: CompareToConstant_const_c
   * Referenced by: '<S31>/Constant'
   */
  1.0,

  /* Mask Parameter: CompareToConstant1_const_l
   * Referenced by: '<S32>/Constant'
   */
  2.0,

  /* Expression: 2
   * Referenced by: '<S4>/Constant'
   */
  2.0,

  /* Expression: 1
   * Referenced by: '<S4>/Constant1'
   */
  1.0,

  /* Expression: 3
   * Referenced by: '<S5>/Constant'
   */
  3.0,

  /* Expression: 2
   * Referenced by: '<S30>/Gain'
   */
  2.0,

  /* Expression: 1e-6
   * Referenced by: '<S30>/Gain2'
   */
  1.0E-6,

  /* Expression: 0
   * Referenced by: '<S30>/Unit Delay2'
   */
  0.0,

  /* Expression: 2
   * Referenced by: '<S30>/Gain3'
   */
  2.0,

  /* Expression: 1/2
   * Referenced by: '<S30>/Gain4'
   */
  0.5,

  /* Expression: 12000
   * Referenced by: '<S30>/Saturation3'
   */
  12000.0,

  /* Expression: -12000
   * Referenced by: '<S30>/Saturation3'
   */
  -12000.0,

  /* Expression: 12000
   * Referenced by: '<S30>/Saturation1'
   */
  12000.0,

  /* Expression: -12000
   * Referenced by: '<S30>/Saturation1'
   */
  -12000.0,

  /* Expression: 1/(2*pi)
   * Referenced by: '<S14>/Gain'
   */
  0.15915494309189535,

  /* Expression: 1e-6
   * Referenced by: '<S28>/Gain1'
   */
  1.0E-6,

  /* Expression: 0
   * Referenced by: '<S28>/Unit Delay1'
   */
  0.0,

  /* Expression: 1e-6
   * Referenced by: '<S28>/Gain2'
   */
  1.0E-6,

  /* Expression: 0
   * Referenced by: '<S10>/Unit Delay1'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S10>/Unit Delay2'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S10>/Unit Delay3'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S10>/Unit Delay6'
   */
  0.0,

  /* Expression: 2
   * Referenced by: '<S10>/Constant'
   */
  2.0,

  /* Expression: 1
   * Referenced by: '<S11>/Constant'
   */
  1.0,

  /* Expression: 1
   * Referenced by: '<S3>/Constant2'
   */
  1.0,

  /* Expression: 0
   * Referenced by: '<S3>/Constant3'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<Root>/Data Store Memory'
   */
  0.0,

  /* Expression: 5000
   * Referenced by: '<Root>/Data Store Memory14'
   */
  5000.0,

  /* Expression: 0
   * Referenced by: '<Root>/Data Store Memory3'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<Root>/Data Store Memory1'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<Root>/Data Store Memory13'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<Root>/Data Store Memory23'
   */
  0.0,

  /* Computed Parameter: UnitDelay_InitialCondition
   * Referenced by: '<S54>/Unit Delay'
   */
  0,

  /* Computed Parameter: u_Value
   * Referenced by: '<S61>/1'
   */
  536870912,

  /* Computed Parameter: u_Value_j
   * Referenced by: '<S61>/-1'
   */
  -536870912,

  /* Computed Parameter: Constant_Value_f
   * Referenced by: '<S17>/Constant'
   */
  536870912,

  /* Computed Parameter: Constant1_Value_f
   * Referenced by: '<S17>/Constant1'
   */
  0,

  /* Computed Parameter: u_Value_a
   * Referenced by: '<S62>/1'
   */
  536870912,

  /* Computed Parameter: u_Value_g
   * Referenced by: '<S62>/-1'
   */
  -536870912,

  /* Computed Parameter: UnitDelay_InitialCondition_i
   * Referenced by: '<S38>/Unit Delay'
   */
  0,

  /* Computed Parameter: u_Value_n
   * Referenced by: '<S45>/1'
   */
  536870912,

  /* Computed Parameter: u_Value_e
   * Referenced by: '<S45>/-1'
   */
  -536870912,

  /* Computed Parameter: Constant_Value_b
   * Referenced by: '<S16>/Constant'
   */
  536870912,

  /* Computed Parameter: Constant1_Value_e
   * Referenced by: '<S16>/Constant1'
   */
  0,

  /* Computed Parameter: u_Value_i
   * Referenced by: '<S46>/1'
   */
  536870912,

  /* Computed Parameter: u_Value_nq
   * Referenced by: '<S46>/-1'
   */
  -536870912,

  /* Computed Parameter: UnitDelay1_InitialCondition_e
   * Referenced by: '<S4>/Unit Delay1'
   */
  0.0F,

  /* Computed Parameter: UnitDelay_InitialCondition_c
   * Referenced by: '<S4>/Unit Delay'
   */
  0.0F,

  /* Computed Parameter: Constant1_Value_g
   * Referenced by: '<S5>/Constant1'
   */
  -0.1109F,

  /* Computed Parameter: Constant3_Value_n
   * Referenced by: '<S5>/Constant3'
   */
  -0.1109F,

  /* Computed Parameter: Constant2_Value_o
   * Referenced by: '<S5>/Constant2'
   */
  -0.1109F,

  /* Computed Parameter: Gain3_Gain_m
   * Referenced by: '<S13>/Gain3'
   */
  { 1.0F, 0.0F, 0.5F, -0.5F, 0.866025388F, 0.5F, -0.5F, -0.866025388F, 0.5F },

  /* Computed Parameter: Gain1_Gain_d
   * Referenced by: '<S13>/Gain1'
   */
  0.666666687F,

  /* Computed Parameter: Constant4_Value
   * Referenced by: '<S5>/Constant4'
   */
  0.3375F,

  /* Computed Parameter: Gain_Gain_e
   * Referenced by: '<S17>/Gain'
   */
  6.28318548F,

  /* Computed Parameter: Gain_Gain_f
   * Referenced by: '<S16>/Gain'
   */
  6.28318548F,

  /* Computed Parameter: Saturation_LowerSat
   * Referenced by: '<S36>/Saturation'
   */
  -30.0F,

  /* Computed Parameter: Saturation1_LowerSat_p
   * Referenced by: '<S36>/Saturation1'
   */
  -30.0F,

  /* Computed Parameter: Saturation_LowerSat_n
   * Referenced by: '<S37>/Saturation'
   */
  -30.0F,

  /* Computed Parameter: Saturation1_LowerSat_a
   * Referenced by: '<S37>/Saturation1'
   */
  -30.0F,

  /* Computed Parameter: UnitDelay1_InitialCondition_f
   * Referenced by: '<S21>/Unit Delay1'
   */
  0.0F,

  /* Computed Parameter: Gain3_Gain_g
   * Referenced by: '<S22>/Gain3'
   */
  { 1.0F, 0.0F, 0.5F, -0.5F, 0.866025388F, 0.5F, -0.5F, -0.866025388F, 0.5F },

  /* Computed Parameter: Gain1_Gain_h
   * Referenced by: '<S22>/Gain1'
   */
  0.666666687F,

  /* Computed Parameter: Gain1_Gain_p
   * Referenced by: '<S30>/Gain1'
   */
  1.0E-6F,

  /* Computed Parameter: UnitDelay1_InitialCondition_fb
   * Referenced by: '<S30>/Unit Delay1'
   */
  0.0F,

  /* Computed Parameter: UnitDelay2_InitialCondition_j
   * Referenced by: '<S28>/Unit Delay2'
   */
  0.0F,

  /* Computed Parameter: Gain3_Gain_c
   * Referenced by: '<S28>/Gain3'
   */
  2.0F,

  /* Computed Parameter: Gain4_Gain_b
   * Referenced by: '<S28>/Gain4'
   */
  0.5F,

  /* Computed Parameter: Constant1_Value_n
   * Referenced by: '<S28>/Constant1'
   */
  6.28318548F,

  /* Computed Parameter: Saturation_LowerSat_e
   * Referenced by: '<S19>/Saturation'
   */
  -30.0F,

  /* Computed Parameter: Saturation1_LowerSat_k
   * Referenced by: '<S19>/Saturation1'
   */
  -30.0F,

  /* Computed Parameter: Saturation_LowerSat_o
   * Referenced by: '<S20>/Saturation'
   */
  -30.0F,

  /* Computed Parameter: Saturation1_LowerSat_f
   * Referenced by: '<S20>/Saturation1'
   */
  -30.0F,

  /* Computed Parameter: Constant2_Value_b
   * Referenced by: '<S73>/Constant2'
   */
  1.0F,

  /* Computed Parameter: Constant3_Value_m
   * Referenced by: '<S73>/Constant3'
   */
  0.0F,

  /* Computed Parameter: A_Threshold
   * Referenced by: '<S75>/A'
   */
  0.0F,

  /* Computed Parameter: Gain_Gain_fd
   * Referenced by: '<S75>/Gain'
   */
  0.866025388F,

  /* Computed Parameter: Gain3_Gain_p
   * Referenced by: '<S75>/Gain3'
   */
  0.5F,

  /* Computed Parameter: B_Threshold
   * Referenced by: '<S75>/B'
   */
  0.0F,

  /* Computed Parameter: C_Threshold
   * Referenced by: '<S75>/C'
   */
  0.0F,

  /* Computed Parameter: Constant_Value_i
   * Referenced by: '<S70>/Constant'
   */
  20000.0F,

  /* Computed Parameter: Gain_Gain_a
   * Referenced by: '<S73>/Gain'
   */
  -1.0F,

  /* Computed Parameter: Gain2_Gain_n
   * Referenced by: '<S73>/Gain2'
   */
  -1.0F,

  /* Computed Parameter: Gain1_Gain_j
   * Referenced by: '<S73>/Gain1'
   */
  -1.0F,

  /* Computed Parameter: Switch3_Threshold
   * Referenced by: '<S73>/Switch3'
   */
  0.0F,

  /* Computed Parameter: Switch4_Threshold
   * Referenced by: '<S73>/Switch4'
   */
  0.0F,

  /* Computed Parameter: Switch5_Threshold
   * Referenced by: '<S73>/Switch5'
   */
  0.0F,

  /* Computed Parameter: Gain2_Gain_d
   * Referenced by: '<S72>/Gain2'
   */
  0.25F,

  /* Computed Parameter: Gain_Gain_l
   * Referenced by: '<S72>/Gain'
   */
  0.5F,

  /* Computed Parameter: Gain1_Gain_jd
   * Referenced by: '<S72>/Gain1'
   */
  0.5F,

  /* Computed Parameter: Constant2_Value_a
   * Referenced by: '<S1>/Constant2'
   */
  20000.0F,

  /* Computed Parameter: Constant1_Value_f1
   * Referenced by: '<S1>/Constant1'
   */
  10.0F,

  /* Computed Parameter: Constant_Value_c
   * Referenced by: '<S1>/Constant'
   */
  0.0001F,

  /* Computed Parameter: DataStoreMemory16_InitialValue
   * Referenced by: '<Root>/Data Store Memory16'
   */
  1.0F,

  /* Computed Parameter: DataStoreMemory20_InitialValue
   * Referenced by: '<Root>/Data Store Memory20'
   */
  0.0F,

  /* Computed Parameter: DataStoreMemory26_InitialValue
   * Referenced by: '<Root>/Data Store Memory26'
   */
  1.0F,

  /* Computed Parameter: DataStoreMemory27_InitialValue
   * Referenced by: '<Root>/Data Store Memory27'
   */
  1.0F,

  /* Computed Parameter: DataStoreMemory52_InitialValue
   * Referenced by: '<Root>/Data Store Memory52'
   */
  100.0F,

  /* Computed Parameter: DataStoreMemory15_InitialValue
   * Referenced by: '<Root>/Data Store Memory15'
   */
  0.0F,

  /* Computed Parameter: DataStoreMemory17_InitialValue
   * Referenced by: '<Root>/Data Store Memory17'
   */
  0.0F,

  /* Computed Parameter: DataStoreMemory18_InitialValue
   * Referenced by: '<Root>/Data Store Memory18'
   */
  0.0F,

  /* Computed Parameter: DataStoreMemory19_InitialValue
   * Referenced by: '<Root>/Data Store Memory19'
   */
  0.0F,

  /* Computed Parameter: DataStoreMemory24_InitialValue
   * Referenced by: '<Root>/Data Store Memory24'
   */
  0.1F,

  /* Computed Parameter: DataStoreMemory25_InitialValue
   * Referenced by: '<Root>/Data Store Memory25'
   */
  100.0F,

  /* Computed Parameter: DataStoreMemory28_InitialValue
   * Referenced by: '<Root>/Data Store Memory28'
   */
  0.0F,

  /* Computed Parameter: DataStoreMemory29_InitialValue
   * Referenced by: '<Root>/Data Store Memory29'
   */
  0.0F,

  /* Computed Parameter: DataStoreMemory30_InitialValue
   * Referenced by: '<Root>/Data Store Memory30'
   */
  0.0F,

  /* Computed Parameter: DataStoreMemory31_InitialValue
   * Referenced by: '<Root>/Data Store Memory31'
   */
  0.0F,

  /* Computed Parameter: DataStoreMemory32_InitialValue
   * Referenced by: '<Root>/Data Store Memory32'
   */
  0.0F,

  /* Computed Parameter: DataStoreMemory33_InitialValue
   * Referenced by: '<Root>/Data Store Memory33'
   */
  0.0F,

  /* Computed Parameter: DataStoreMemory34_InitialValue
   * Referenced by: '<Root>/Data Store Memory34'
   */
  0.0F,

  /* Computed Parameter: DataStoreMemory35_InitialValue
   * Referenced by: '<Root>/Data Store Memory35'
   */
  0.0F,

  /* Computed Parameter: DataStoreMemory36_InitialValue
   * Referenced by: '<Root>/Data Store Memory36'
   */
  1.0F,

  /* Computed Parameter: DataStoreMemory37_InitialValue
   * Referenced by: '<Root>/Data Store Memory37'
   */
  1.0F,

  /* Computed Parameter: DataStoreMemory38_InitialValue
   * Referenced by: '<Root>/Data Store Memory38'
   */
  0.0F,

  /* Computed Parameter: DataStoreMemory39_InitialValue
   * Referenced by: '<Root>/Data Store Memory39'
   */
  0.0F,

  /* Computed Parameter: DataStoreMemory40_InitialValue
   * Referenced by: '<Root>/Data Store Memory40'
   */
  1.0F,

  /* Computed Parameter: DataStoreMemory41_InitialValue
   * Referenced by: '<Root>/Data Store Memory41'
   */
  1.0F,

  /* Computed Parameter: DataStoreMemory42_InitialValue
   * Referenced by: '<Root>/Data Store Memory42'
   */
  0.0F,

  /* Computed Parameter: DataStoreMemory43_InitialValue
   * Referenced by: '<Root>/Data Store Memory43'
   */
  0.0F,

  /* Computed Parameter: DataStoreMemory44_InitialValue
   * Referenced by: '<Root>/Data Store Memory44'
   */
  1.0F,

  /* Computed Parameter: DataStoreMemory45_InitialValue
   * Referenced by: '<Root>/Data Store Memory45'
   */
  1.0F,

  /* Computed Parameter: DataStoreMemory46_InitialValue
   * Referenced by: '<Root>/Data Store Memory46'
   */
  1.0F,

  /* Computed Parameter: DataStoreMemory50_InitialValue
   * Referenced by: '<Root>/Data Store Memory50'
   */
  0.0F,

  /* Computed Parameter: DataStoreMemory51_InitialValue
   * Referenced by: '<Root>/Data Store Memory51'
   */
  0.0F,

  /* Computed Parameter: DataStoreMemory8_InitialValue
   * Referenced by: '<Root>/Data Store Memory8'
   */
  0.0F,

  /* Computed Parameter: Saturation_UpperSat
   * Referenced by: '<S75>/Saturation'
   */
  49152U,

  /* Computed Parameter: Saturation_LowerSat_ov
   * Referenced by: '<S75>/Saturation'
   */
  8192U,

  /* Computed Parameter: Gain2_Gain_a
   * Referenced by: '<S75>/Gain2'
   */
  32768U,

  /* Computed Parameter: Gain1_Gain_l
   * Referenced by: '<S75>/Gain1'
   */
  32768U,

  /* Computed Parameter: Constant_Value_by
   * Referenced by: '<S15>/Constant'
   */
  1U,

  /* Computed Parameter: Constant2_Value_d
   * Referenced by: '<S17>/Constant2'
   */
  0U,

  /* Computed Parameter: Constant2_Value_l
   * Referenced by: '<S16>/Constant2'
   */
  0U,

  /* Computed Parameter: Constant2_Value_f
   * Referenced by: '<S14>/Constant2'
   */
  0U,

  /* Computed Parameter: Constant2_Value_m
   * Referenced by: '<S75>/Constant2'
   */
  2U,

  /* Computed Parameter: Constant3_Value_h
   * Referenced by: '<S75>/Constant3'
   */
  6U,

  /* Computed Parameter: Constant4_Value_d
   * Referenced by: '<S75>/Constant4'
   */
  1U,

  /* Computed Parameter: Constant5_Value
   * Referenced by: '<S75>/Constant5'
   */
  4U,

  /* Computed Parameter: Constant6_Value
   * Referenced by: '<S75>/Constant6'
   */
  3U,

  /* Computed Parameter: Constant7_Value
   * Referenced by: '<S75>/Constant7'
   */
  5U,

  /* Computed Parameter: Constant_Value_h
   * Referenced by: '<S75>/Constant'
   */
  1U,

  /* Computed Parameter: Constant1_Value_i
   * Referenced by: '<S75>/Constant1'
   */
  0U,

  /* Computed Parameter: Constant1_Value_ec
   * Referenced by: '<S3>/Constant1'
   */
  1U,

  /* Computed Parameter: DataStoreMemory10_InitialValue
   * Referenced by: '<Root>/Data Store Memory10'
   */
  0U,

  /* Computed Parameter: DataStoreMemory11_InitialValue
   * Referenced by: '<Root>/Data Store Memory11'
   */
  0U,

  /* Computed Parameter: DataStoreMemory12_InitialValue
   * Referenced by: '<Root>/Data Store Memory12'
   */
  0U,

  /* Computed Parameter: DataStoreMemory2_InitialValue
   * Referenced by: '<Root>/Data Store Memory2'
   */
  0U,

  /* Computed Parameter: DataStoreMemory21_InitialValue
   * Referenced by: '<Root>/Data Store Memory21'
   */
  0U,

  /* Computed Parameter: DataStoreMemory22_InitialValue
   * Referenced by: '<Root>/Data Store Memory22'
   */
  0U,

  /* Computed Parameter: DataStoreMemory4_InitialValue
   * Referenced by: '<Root>/Data Store Memory4'
   */
  0U,

  /* Computed Parameter: DataStoreMemory47_InitialValue
   * Referenced by: '<Root>/Data Store Memory47'
   */
  0U,

  /* Computed Parameter: DataStoreMemory48_InitialValue
   * Referenced by: '<Root>/Data Store Memory48'
   */
  0U,

  /* Computed Parameter: DataStoreMemory49_InitialValue
   * Referenced by: '<Root>/Data Store Memory49'
   */
  0U,

  /* Computed Parameter: DataStoreMemory5_InitialValue
   * Referenced by: '<Root>/Data Store Memory5'
   */
  0U,

  /* Computed Parameter: DataStoreMemory6_InitialValue
   * Referenced by: '<Root>/Data Store Memory6'
   */
  0U,

  /* Computed Parameter: DataStoreMemory7_InitialValue
   * Referenced by: '<Root>/Data Store Memory7'
   */
  0U,

  /* Computed Parameter: DataStoreMemory9_InitialValue
   * Referenced by: '<Root>/Data Store Memory9'
   */
  0U,

  /* Start of '<S23>/Subsystem1' */
  {
    /* Computed Parameter: alpha_beta_Y0
     * Referenced by: '<S34>/alpha_beta'
     */
    { 0.0F, 0.0F }
  }
  ,

  /* End of '<S23>/Subsystem1' */

  /* Start of '<S23>/Subsystem - pi//2 delay' */
  {
    /* Computed Parameter: alpha_beta_Y0
     * Referenced by: '<S33>/alpha_beta'
     */
    { 0.0F, 0.0F }
  }
  ,

  /* End of '<S23>/Subsystem - pi//2 delay' */

  /* Start of '<S18>/Subsystem1' */
  {
    /* Computed Parameter: dq_Y0
     * Referenced by: '<S27>/dq'
     */
    { 0.0F, 0.0F }
  }
  ,

  /* End of '<S18>/Subsystem1' */

  /* Start of '<S18>/Subsystem - pi//2 delay' */
  {
    /* Computed Parameter: dq_Y0
     * Referenced by: '<S26>/dq'
     */
    { 0.0F, 0.0F }
  }
  ,

  /* End of '<S18>/Subsystem - pi//2 delay' */

  /* Start of '<S39>/Subsystem1' */
  {
    /* Computed Parameter: alpha_beta_Y0
     * Referenced by: '<S52>/alpha_beta'
     */
    { 0.0F, 0.0F }
  }
  ,

  /* End of '<S39>/Subsystem1' */

  /* Start of '<S39>/Subsystem - pi//2 delay' */
  {
    /* Computed Parameter: alpha_beta_Y0
     * Referenced by: '<S51>/alpha_beta'
     */
    { 0.0F, 0.0F }
  }
  ,

  /* End of '<S39>/Subsystem - pi//2 delay' */

  /* Start of '<S35>/Subsystem1' */
  {
    /* Computed Parameter: dq_Y0
     * Referenced by: '<S43>/dq'
     */
    { 0.0F, 0.0F }
  }
  ,

  /* End of '<S35>/Subsystem1' */

  /* Start of '<S35>/Subsystem - pi//2 delay' */
  {
    /* Computed Parameter: dq_Y0
     * Referenced by: '<S42>/dq'
     */
    { 0.0F, 0.0F }
  }
  ,

  /* End of '<S35>/Subsystem - pi//2 delay' */

  /* Start of '<S55>/Subsystem1' */
  {
    /* Computed Parameter: alpha_beta_Y0
     * Referenced by: '<S68>/alpha_beta'
     */
    { 0.0F, 0.0F }
  }
  ,

  /* End of '<S55>/Subsystem1' */

  /* Start of '<S55>/Subsystem - pi//2 delay' */
  {
    /* Computed Parameter: alpha_beta_Y0
     * Referenced by: '<S67>/alpha_beta'
     */
    { 0.0F, 0.0F }
  }
  ,

  /* End of '<S55>/Subsystem - pi//2 delay' */

  /* Start of '<S53>/Subsystem1' */
  {
    /* Computed Parameter: dq_Y0
     * Referenced by: '<S59>/dq'
     */
    { 0.0F, 0.0F }
  }
  ,

  /* End of '<S53>/Subsystem1' */

  /* Start of '<S53>/Subsystem - pi//2 delay' */
  {
    /* Computed Parameter: dq_Y0
     * Referenced by: '<S58>/dq'
     */
    { 0.0F, 0.0F }
  }
  /* End of '<S53>/Subsystem - pi//2 delay' */
};

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
